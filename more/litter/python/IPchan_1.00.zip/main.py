# -*- coding: UTF-8 -*-

from flask import Flask,Response,request,redirect,render_template,session,send_file
from time import strftime,localtime
from codecs import open
from json import dumps,loads
from random import choice,sample
from requests import get

def save(path_,mode,text):
    open(path_,mode,"UTF-8-sig").write(text)

def load(path_):
    return open(path_,"r","UTF-8-sig").read()

app=Flask("ips")
ips=loads(load("ips.json").replace("'",'"'))

@app.route("/favicon.ico")
def favicon():
    return Response(dumps(ips,ensure_ascii=False),mimetype="application/json")

@app.route("/<path:filename>")
def theft(filename):
    ip=request.headers.get("X-Forwarded-For",request.remote_addr)
    path_="files/"+filename

    if ip not in ips:
        data=get("https://api.vvhan.com/api/getIpInfo",{"ip":ip}).json().get("info")
        ips[ip]={"from":f"{data['country']} {data['prov']} {data['city']} {data['lsp']}"}

    path_="files/"+filename
    save("ips.json","w",str(ips))

    try:
        return send_file(path_,as_attachment=False,attachment_filename=filename)

    except:
        return send_file(path_,as_attachment=False,download_name=filename)

if __name__=="__main__":
    app.run(host="0.0.0.0",port=10221,debug=True,threaded=True)
