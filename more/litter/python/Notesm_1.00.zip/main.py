'''
绝无BUG且高效的note.ms防删程序

Author.paperee
Thanks.Mr_Zhang & Maggie
'''

# 导入库：pip install selenium
from selenium import webdriver
import codecs
import time

# 留言板名称
note='yournote'

# 开头内容
head='Name: paperee (ee)\nHome: https://paperee.guru'

# 主体内容
text=codecs.open('text.txt','r',"UTF-8-sig").read()

# 浏览器驱动
driver=webdriver.Chrome('chromedriver.exe')

'''
根据自用浏览器情况修改驱动
驱动自行到网上下载

webdriver.Firefox() => Firefox
webdriver.Chrome() => Chrome
webdriver.Ie() => Internet Explorer
webdriver.Edge() => Edge
webdriver.Opera() => Opera
webdriver.PhantomJS() => PhantomJS
'''

# 打开指定留言板
driver.get(f'https://note.ms/{note}')

# 定位textarea
html=driver.find_element('xpath',"/html/body/div[1]/div[1]/div/div/textarea")

# 等待响应2s
time.sleep(2)

# 循环执行
while True:

    # 每2s同步本地
    time.sleep(2)

    # 修改留言板内容
    driver.execute_script("arguments[0].value=arguments[1];",html,f"{head}\n\n\n{text}")

    # 写入时间并保存
    html.send_keys(f'\n\n\n{time.ctime()}')