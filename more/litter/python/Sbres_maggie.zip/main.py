import sb

a=sb.sb()
b=sb.showall()
c=b.replace("\ufeff","")

print(f"随机傻逼句子:{a}")
print(f"全部傻逼句子:{b}")

fp=open("test.txt","w")
fp.write(c)
