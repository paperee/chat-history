Hi! ee
使用示例:
import sb
print(f"随机傻逼句子:{sb.sb()}")
print(f"全部傻逼句子:{sb.showall()}")

在真正投入使用前，请修改sbres.txt！