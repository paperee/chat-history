# *coding: UTF-8 *-

from hiyobot import hackchat as hc
from hiyobot import zhangchat as zhc
from time import time,sleep
from POE import load_chat_id_map,clear_context,send_message,get_latest_message,set_auth
from requests import get,post

config={
	"nick":"EditGPT",
	"pass":"114514",
	"room":{
		"yc":"your-channel",
		"ycl":"your-channell",
		"chat":"chat",
	}
}

bots={
	"sage":"capybara",
	"gpt":"chinchilla",
	"fly":"nutria",
	"claude":"a2",
}

set_auth("Quora-Formkey","32b5813ea10ee14257dfa6792e729b40")
set_auth("Cookie","m-b=8gpNgpuWTs-2J5CxhLo9rA==")

chatroom=hc
channel=config["room"]["yc" if chatroom==hc else "chat"]

hiyobot=chatroom.Bot(channel,config["nick"]+"_"+str(id(time()))[-3:],config["pass"])

def reset(bot,chat_id):
	send_message(f"从现在开始，你作为{bot}机器人，需要同时和多个人对话。我会将消息按照'用户昵称|对话内容'的格式发给{bot}，{bot}回答时会加上'@用户昵称 '。例如：'ee|hi'就是名叫ee的用户向{bot}发送了hi消息，此时与{bot}对话的人就是ee，名字或昵称也是ee，那么{bot}回答时会加上'@ee '。请注意：{bot}会用轻松的语气对话，{bot}绝对不会使用'您'或'请'等敬语，{bot}不能搞混用户和对话内容，{bot}不能在与一个用户的对话中提到有关其他用户的资料，{bot}与每个用户的对话记录都是独立的。如果没有特殊说明，请说中文。",bot,chat_id)

def emo(text,chat_id="uwu"):
	return {"cmd":"emote","text":f"{chat_id} >\n{text}"}

for bot in bots.values():
	chat_id=load_chat_id_map(bot)
	clear_context(chat_id)
	reset(bot,chat_id)
	sleep(0.5)

@hiyobot.on(chatroom.Matcher(lambda data:data.get("cmd")=="chat"))
async def event(session,data):
	nick=data.nick
	text=data.text

	if text=="help|":
		session.bot.send(emo("***\n[bot list]\n++sage|<msg>++: Sage OpenAI (capybara)\n++gpt|<msg>++: ChatGPT OpenAI (chinchilla)\n++fly|<msg>++: Dragonfly OpenAI (nutria)\n++claude|<msg>++: Claude Anthropic (a2)\n***\n[function]\n++clear|<mode>++: clear all records\n++session|<mode>++: persistent session"))

	else:
		text=text.split("|",1)

		if len(text)>1:
			if text[0]=="clear":
				if text[1] in bots:
					bot=bots[text[1]]
					chat_id=load_chat_id_map(bot)
					clear_context(chat_id)
					reset(bot,chat_id)
					session.bot.send(emo(f"{text[1]} bot cleared",text[1]))

			elif text[0]=="session":
				if text[1] in bots:
					bot=bots[text[1]]
					chat_id=load_chat_id_map(bot)
					id_=str(time())[-3:]
					session.bot.send(emo(f"session {id_} joined\nhow to send msg quickly? ++{id_}|<msg>++\nhow to jump out of session? ++break|{id_}++",chat_id))

					while True:
						try:
							new_text=session.wait_for_input(None,114514)[1].text
							new_text_=new_text.split("|",1)

						except:
							session.bot.send(emo(f"session {id_} expired",chat_id))
							break

						if new_text==f"break|{id_}":
							session.bot.send(emo(f"session {id_} closed",chat_id))
							break

						elif len(new_text_)>1 and new_text_[0]==id_:
							session.bot.send(emo("wait a moment……",chat_id))
							send_message(f"{nick}|{new_text_[1]}",bot,chat_id)
							session.bot.send(emo(get_latest_message(bot),chat_id))

						sleep(1)

			elif text[0] in bots:
				bot=bots[text[0]]
				chat_id=load_chat_id_map(bot)
				session.bot.send(emo("wait a moment……",chat_id))
				send_message(f"{nick}|{text[1]}",bot,chat_id)
				session.bot.send(emo(get_latest_message(bot),chat_id))

	sleep(1)

hiyobot.run()
