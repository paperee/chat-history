# *coding: UTF-8 *-

from websocket import WebSocket
from json import dumps,loads
from time import sleep
from POE import load_chat_id_map,clear_context,send_message,get_latest_message,set_auth

address="wss://chat.zhangsoft.cf/ws"

config={
	"channel":"chat",
	"nick":"EditGPT",
	"password":"114514",
	"head":"https://chat.zhangsoft.cf/imgs/head.png",
	"client":"papereescomputer",
}

bots={
	"-sage-":"capybara",
	"-gpt4-":"beaver",
	"-claude+-":"a2_2",
	"-claude-":"a2",
	"-gpt-":"chinchilla",
	"-fly-":"nutria",
}

set_auth("Quora-Formkey","32b5813ea10ee14257dfa6792e729b40")
set_auth("Cookie","m-b=8gpNgpuWTs-2J5CxhLo9rA==")

class uwuBot():
	def __init__(uwu,address,config,bots):
		uwu.goto=address
		uwu.pack=config
		uwu.bots=bots
		uwu.connect()

	def join(uwu):
		uwu.ws.send(dumps({"cmd":"join",**uwu.pack}))

	def chat(uwu,text,chat_id=""):
		uwu.ws.send(dumps({"cmd":"emote","text":f"{chat_id or 'uwu'} >\n{text}"}))

	def loop(uwu):
		while True:
			data=loads(uwu.ws.recv())
			cmd=data.get("cmd")

			if cmd=="chat":
				text=data.get("text")

				if text=="-help-":
					uwu.chat("[bot list]\n++-sage- <msg>++: Sage OpenAI (capybara)\n++-gpt4- <msg>++: GPT-4 OpenAI (beaver)\n++-claude+- <msg>++: Claude+ Anthropic (a2_2)\n++-claude- <msg>++: Claude Anthropic (a2)\n++-gpt- <msg>++: ChatGPT OpenAI (chinchilla)\n++-fly- <msg>++: Dragonfly OpenAI (nutria)\n[function]\n++-clear- <id>++: clear all records\n++-session- <mod>++: persistent session")

				else:
					text=text.split(" ",1)

					if len(text)>1:
						if text[0]=="-clear-":
							clear_context(text[1])
							uwu.chat(f"context is now cleared",text[1])

						elif text[0] in bots:
							bot=uwu.bots[text[0]]
							chat_id=load_chat_id_map(bot)
							send_message(text[1],bot,chat_id)
							uwu.chat(get_latest_message(bot),chat_id)

			sleep(1)

	def error(uwu):
		sleep(30)
		print("error")

		uwu.connect()

	def connect(uwu):
		uwu.ws=WebSocket()
		uwu.ws.connect(uwu.goto)

		print("success")

		uwu.join()
		uwu.loop()

if __name__=="__main__":
	uwuBot(address,config,bots)
