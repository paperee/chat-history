# *coding: UTF-8 *-

from websocket import WebSocket
from json import dumps,loads
from time import sleep

address="wss://chat.zhangsoft.link/ws"

config={
	"channel":"bot",
	"nick":"eebot",
	"password":"13ee",
	"head":"https://chat.zhangsoft.cf/imgs/head.png",
	"client":"papereescomputer",
}

class uwuBot():
	def __init__(uwu,address,config):
		uwu.goto=address
		uwu.pack=config
		uwu.connect()

	def join(uwu):
		uwu.ws.send(dumps({"cmd":"join",**uwu.pack}))

	def chat(uwu,text,chat_id=""):
		uwu.ws.send(dumps({"cmd":"emote","text":f">\n{text}"}))

	def loop(uwu):
		while True:
			data=loads(uwu.ws.recv())
			cmd=data.get("cmd")

			if cmd=="chat":
				text=data.get("text")
				nick=data.get("nick")

				print(f"{nick}｜{text}")

			sleep(1)

	def error(uwu):
		sleep(30)
		print("error")

		uwu.connect()

	def connect(uwu):
		uwu.ws=WebSocket()
		uwu.ws.connect(uwu.goto)

		print("[success]")

		uwu.join()
		uwu.loop()

if __name__=="__main__":
	uwuBot(address,config)