﻿import codecs
import random

room='软件室'
nick='ee'
nick_='eebot'

def sbres():
	text=codecs.open("sbres.txt","r","UTF-8-sig").read().split("\n·")
	sb=text[0].split("\n")
	sw=text[1].split("\n")
	sth=text[2].split("\n")
	ra=random.choice(sb)
	rb=random.choice(sw)
	rc=random.choice(sth)
	
	sbres=f"{ra}在{rb}{rc}".replace('c—',room).replace('e—',nick).replace('你',nick_)
	return sbres

print("按回车键——")

while True:
        input()
        print(sbres())
