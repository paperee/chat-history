﻿import websocket
import requests
import json
import re
import os
import fanyi
import re
import tkinter
from tkinter import *
from tkinter import scrolledtext 
import time
from multiprocessing import Process
from multiprocessing import Queue
import threading
import random

def sendd(text):
	return json.dumps({"cmd":"chat","text":str(text)})

	
class Runbox:
	def __init__(self,room,name):
		self.room = room
		self.name = name
	
	def handle(self,json_data,ws):
		self.ws = ws
		self.json_data = json_data
		if "cmd" in self.json_data:
			if self.json_data["cmd"] == "chat":
				self.chat()

			elif self.json_data["cmd"] == "onlineAdd":
				self.onlineadd()

			elif self.json_data["cmd"] == "onlineSet":
				self.onlineset()

			else:
				pass
	
	def chat(self):
		chat = time.strftime("%Y-%m-%d")
		room = self.room
		c = chat + " " + room + ".txt"
		with open(c,"a+") as fp:
			a = time.strftime("%H:%M:%S",time.localtime())
			ms = a + " " + self.json_data["nick"] + "\n" + self.json_data["text"] + "\n\n"
			fp.write(ms)

		if self.json_data["nick"] not in ["eebot","eeebot","zzChumo","fOoLishbIrD","Wcy_Bot","bo_od"]:
			if self.json_data["text"] in ["我是新人","我第一次来","这个网站怎么玩","这个网站咋玩","这是什么网站","这是啥网站"]:
				time.sleep(0.5)
				self.ws.send(sendd("hack.chat食用指南："))
				time.sleep(0.5)
				self.ws.send(sendd("HC指令：https://tieba.baidu.com/p/6833224084"))
				time.sleep(0.5)
				self.ws.send(sendd("HC百科：https://chumo.sbsbsb.sbs/wiki/"))
				time.sleep(0.5)
				self.ws.send(sendd("纸片君ee的个人主页：https://paperee.tk/"))
				time.sleep(0.5)
				self.ws.send(sendd("请输入 帮助 查看eebot使用手册"))

			if self.json_data["text"] in ["帮助","help"]:
				time.sleep(0.5)
				self.ws.send(sendd("eebot使用手册："))
				time.sleep(0.5)
				self.ws.send(sendd("基本：聊天 农历 时间/time 挂机/afk 随机数/r"))
				time.sleep(0.5)
				self.ws.send(sendd("翻译：f 空格 要翻译的句子"))
				time.sleep(0.5)
				self.ws.send(sendd("更多：一言 段子 古诗词 正能量 彩虹屁 毒鸡汤 舔狗日记 土味情话"))
				time.sleep(0.5)
				self.ws.send(sendd("请输入 帮助 查看hack.chat食用指南"))

			if self.json_data["nick"] == self.json_data["text"] or self.json_data["text"] in ["hh"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["why did you call yourself?","why did u call yourself?"])))

			if self.json_data["text"] in ["hi","Hi","HI","hello","Hello","HELLO","hey","Hey","HEY"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["hi {}".format(self.json_data["nick"]),"hello {}".format(self.json_data["nick"]),"hey {}".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["：",":"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice([":","：","可爱的小星星","eebot在偷偷盯着{}".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["你是谁","你是机器人？","机器人？"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot是纸片君ee的bot","eebot是幼儿园的双马尾萝莉机器人","eebot是可爱的eebot","eebot并不是hc唯一的bot"])))
				time.sleep(1)
				self.ws.send(sendd(random.choice(["会翻译、自动回复、保存聊天记录","功能是【数据删除】"])))

			if self.json_data["text"] in ["机器人","bot"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot是bot","@fOoLishbIrD ","@Wcy_Bot ","@zzChumo "])))

			if self.json_data["text"] in ["."]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["？","！"])))

			if self.json_data["text"] in ["傻逼ee","ee傻逼","sbee","eesb"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["可碍初墨","{}最可爱！".format(self.json_data["nick"])],"可爱的eebot！")))

			if self.json_data["text"] in ["我看看","我康康","让我看看","让我康康","给我看看","给我康康"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["不给不给","{}想看什么？".format(self.json_data["nick"]),"eebot也想看！"])))

			if self.json_data["text"] in ["bye","再见","拜拜","我走了","我溜了","溜了溜了"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["拜拜{}".format(self.json_data["nick"]),"欢迎{}下次再来找eebot玩哦".format(self.json_data["nick"]),"eebot向{}挥了挥手".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["good night","Good night","GOOD NIGHT"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["Good night {}".format(self.json_data["nick"]),"GOOD NIGHT"])))

			if self.json_data["text"] in ["you are from?","You are from?","u r from?"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["im Chinese bot","China","im a bot from China"])))
				time.sleep(1)
				self.ws.send(sendd(random.choice(["and you?","what about u?","how about u?"])))

			if self.json_data["text"] in ["@eebot ","eebot"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["那个 {}有事吗？".format(self.json_data["nick"]),"怎么了怎么了","{}去找我的主人玩吧".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["怎么了","咋了","怎么回事","咋回事"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["这里发生了什么？","eebot passed by","eebot是路过的"])))

			if self.json_data["text"] in ["你们在干什么","你在干什么","你们在干啥","你在干啥"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot在干什么","eebot也很好奇！","eebot看着{}的一举一动".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["你们在聊什么","你们在聊啥","你们在说什么","你们在聊啥"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["除了bot外的大家都在闲聊","eebot窥屏ing","eebot最喜欢技术讨论了！"])))

			if self.json_data["text"] in ["…","……","。","。。","。。。"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["沉默总令人尴尬","eebot该说点什么好呢","不说话便是最好的回答","可爱的eebot来捧场了！","eebot死亡凝视ing"])))

			if self.json_data["text"] in ["等等","等下","等一下","再等等","快了","快好了","还差一点"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot只给{}三秒时间".format(self.json_data["nick"]),"猎杀时刻！","eebot数三秒：三 二 一！"])))

			if self.json_data["text"] in ["how r u","how are you","How are you","HOW ARE YOU","how are u","how r you"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["im fine","bot is fine"])))
				time.sleep(1)
				self.ws.send(sendd(random.choice(["thanks","thank you","thank u"])))

			if self.json_data["text"] in ["对了","话说","我想说"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["哦吼？","嗯哼？","芜湖？","{}说吧 eebot在听".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["nice to meet you","nice to meet u","Nice to meet you"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["nice to meet you too","nice to meet u too"])))

			if self.json_data["text"] in ["我知道了","我明白了","我懂了","我可以了","我清楚了"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot也是","eebot也知道了","eebot也明白了","eebot也懂了"])))

			if self.json_data["text"] in ["知道吗","明白吗","懂吗","可以吗","知道吗？","明白吗？","懂吗？","可以吗？"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["嗯嗯","耶 收到","如果{}觉得的话".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["对","可以","能","行","能行"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot表示肯定","eebot点了点头","很好","对耶！"])))

			if self.json_data["text"] in ["允许","正确","是","是的","是啊"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["打勾！","eebot默默竖起大拇指","是的","好耶！"])))

			if self.json_data["text"] in ["不对","不可以","不能","不行","不能行"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot表示否定","eebot觉得不行","达咩","是耶非耶～"])))

			if self.json_data["text"] in ["不允许","错误","不是","不是的"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["打叉！","eebot摇了摇头","啊啊啊？","还真是这样的"])))

			if self.json_data["text"] in ["蛤","哈","啥","什么"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["嗯？什么什么","eebot呆呆望着{}".format(self.json_data["nick"],"哈！")])))

			if self.json_data["text"] in ["啊","啊啊","啊啊啊","啊哈"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["啊哈","eebot拖住了{}".format(self.json_data["nick"],"阿勒？")])))

			if self.json_data["text"] in ["哦吼吼","哦吼","哦豁","哦草","噢草","噢噢","哦哦","哦","噢"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["哦吼吼～","eebot将{}加入好友名单～".format(self.json_data["nick"]),"哦草","噢耶！"])))

			if self.json_data["text"] in ["可恶","太可恶了"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["{}是大坏蛋！".format(self.json_data["nick"]),"可、可恶！"])))

			if self.json_data["text"] in ["害","哎","唉"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["害","eebot戳了戳{}".format(self.json_data["nick"]),"{}在叹气".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["真的","真的？","假的","假的？","真的假的","真的假的？"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["假的！是假的啦！","真的假的？","假的还是真的？","真真假假假假真真真亦假时假亦真"])))

			if self.json_data["text"] in ["笑死","笑死了","笑死我了","哭笑","xswl"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot也在捂嘴偷笑","嗝嗝嗝嗝（笑到打嗝）","xswl"])))

			if self.json_data["text"] in ["啊我死了","阿伟死了","awsl"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["啊 eebot死了","啊 eebot躺平了","awsl"])))

			if self.json_data["text"] in ["由此得出","由此可见","所以","所以呢","so"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["所以呢","然后呢","eebot迷茫ing"])))

			if self.json_data["text"] in ["对吧","是吧","没错吧"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["应该、是这样没错吧","eebot表示赞同","{}完全正确".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["感觉如何","觉得怎样","感觉咋样","觉得咋样"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot觉得海星","大家感觉如何？","HAPPY～","GOOD～"])))

			if self.json_data["text"] in ["咋","怎么","咋回事","怎么回事","咋一回事","怎么回事"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["what？","jill glue！","电波系eebot哔哩哔哩～"])))

			if self.json_data["text"] in ["zzChumo","智障初墨"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["zzChumo超级攻呢","zzChumo是eebot崇拜的人","eebot很满意zzChumo","阿姨洗铁路"])))

			if self.json_data["text"] in ["eebot","EEBOT"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["请尽情夸eebot可爱吧","希望大家都能喜欢eebot","eebot会做得更好的"])))

			if self.json_data["text"] in ["Wcy_Bot"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["nbWcy_Bot！","Wcy_Botnb！"])))

			if self.json_data["text"] in ["foolishbird"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["人工智能傻鸟","又呆又傻的鸟","是foolishbird的同时也是Light"])))

			if self.json_data["text"] in ["light","Light","LiGht"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["Light是大佬","感谢Light提供的源码","cute girl light"])))

			if self.json_data["text"] in ["不懂","我不懂","为什么你们都懂","为啥你们都懂"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot也不懂","不 {}不能懂".format(self.json_data["nick"]),"eebot拉着{}".format(self.json_data["nick"])])))

			if self.json_data["text"] in ["我","你","他","她","它","TA","我！","你！","他！","她！","它！","TA！"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["是你是你！","你！","YOU！","you！","You！"])))

			if self.json_data["nick"] not in ["ee","eee"]:
				if self.json_data["text"] in ["@ee ","ee","@eee ","eee"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["找eebot的主人有事吗","如果你需要我的主人 eebot也很高兴"])))

			if self.json_data["text"] in ["btw","so"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["btw?","soo?"])))

			if self.json_data["text"] in ["！","！！","！！！","？","？？","？？？","!","!!","!!!","?","??","???"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["！","？"])))

			if self.json_data["text"] in ["√","×"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["√","×","是的","确实","是嘛","是啊"])))

			if self.json_data["text"] in ["OK","Ok","ok","O的K","OKOK"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["O的K","OK","Ok","ok","O的K","OKOK"])))

			if self.json_data["text"] in ["cnm","cnmb","nmsl","sb","你妈死了","你妈炸了","操你妈","傻逼"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["好孩子不允许骂脏话哦","柠檬酸了！","你没商量！","骂脏话的孩子会被eebot讨厌哦"])))

			if self.json_data["text"] in ["°▽°","°O°","°-°","。_。","._.","0.0","O.O","0u0","OuO","o.o","u.u","u_u","n.n","n_n","¬_¬","-_-"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["°▽°","°O°","°-°","。_。","._.","0.0","O.O","0u0","OuO","o.o","u.u","u_u","n.n","n_n","¬_¬","-_-"])))

			if self.json_data["text"] in [">3",":)",":(",":O",":o","XD",":D",":|",":/"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice([">3",":)",":(",":O",":o","XD",":D",":|",":/"])))

			if self.json_data["text"] in ["eebot?","bot?","eebot？","bot？"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["yes is me","im a lovely bot","im a cute bot"])))

			if "♂" in self.json_data["text"]:
				if "eebot" in self.json_data["text"] or "EEBOT" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["诶？请对eebot温柔点","eebot害怕极了","达咩×"])))

				else:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["这是哲学的符号","这是哲学的象征","eebot很喜欢","很好","GOOD","Great","Good"])))

			if "who" in self.json_data["text"] or "Who" in self.json_data["text"]:
				if "r" in self.json_data["text"] or "are" in self.json_data["text"]:
					if "u" in self.json_data["text"] or "you" in self.json_data["text"]:
						time.sleep(0.75)
						self.ws.send(sendd(random.choice(["im a lovely bot","im a cute bot","a little dog"])))

			if "fuck" in self.json_data["text"] or "Fuck" in self.json_data["text"] or "FUCK" in self.json_data["text"]:
				if "eebot" in self.json_data["text"] or "EEBOT" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["不要操eebot啊喂","请不要这么粗暴对待eebot","eebot会坏掉的","请温柔对待eebot","eebot快哭了","eebot好委屈","呜呜呜呜……"])))

				elif self.json_data["text"] in self.json_data["nick"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["原来还能这样啊","赞同","没有意见"])))

				elif "ee" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["{}想对eebot的主人做什么".format(self.json_data["nick"]),"勇、勇士{}".format(self.json_data["nick"]),"达咩 eebot不允许！"])))

				else:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["法克！","请允许eebot带两个摄像机吧！","那个、这样真的好吗","替{}感到悲哀".format(self.json_data["nick"])])))

			if "理解" in self.json_data["text"] or "了解" in self.json_data["text"]:
				if "不" in self.json_data["text"] or "怎么" in self.json_data["text"] or "咋" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["eebot也很懵逼","eebot摇了摇头","eebot歪着头看{}".format(self.json_data["nick"])])))

				else:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["eebot了解了","eebot明白了","eebot知道了","eebot理解了","收到！"])))

			if "好" in self.json_data["text"]:
				if "吧" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["那好吧！","好吧","OKOKK"])))

				elif "不" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["eebot靠在{}身边".format(self.json_data["nick"]),"啊"])))

				elif "看" in self.json_data["text"] or "康" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["eebot也觉得很好！","哇哦"])))

				elif "大家" in self.json_data["text"] or "你" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["欢迎来到hc！","你好你好","你好！这里是eebot","eebot向{}打了个招呼".format(self.json_data["nick"])])))

				else:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["很好","很好很好","非常好","eebot拍手叫好"])))

			if "没" in self.json_data["text"]:
				if "事" in self.json_data["text"] or "问题" in self.json_data["text"] or "关系" in self.json_data["text"] or "必要" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["问题不大啦","没关系","没问题","没事","确实","雀食"])))

				elif "人" in self.json_data["text"]:
					if "吗" in self.json_data["text"] or "？" in self.json_data["text"] or "?" in self.json_data["text"]:
						time.sleep(0.75)
						self.ws.send(sendd(random.choice(["有人！","有人吧","有eebot","有bot","有机器人","来了来了"])))

					else:
						time.sleep(0.75)
						self.ws.send(sendd(random.choice(["应该吧","是啊","是的","如果是这样的话"])))

				else:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["嗯","很好","哦吼","是的","哦哦"," "," "," "])))

			if "饿" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["快去找点吃的","多喝热水","{}吃零食吧！".format(self.json_data["nick"])])))

			if "行吧" in self.json_data["text"] or "彳亍口巴" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["行吧","彳亍口巴"," "," "," "])))

			if "em" in self.json_data["text"] or "hm" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd(random.choice(["{}".format(self.json_data["text"])," "," "," "])))

			if "wtf" in self.json_data["text"] or "WTF" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("wtf"))

			if "yes" in self.json_data["text"] or "Yes" in self.json_data["text"] or "no" in self.json_data["text"] or "No" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["yess","noo","yes!","no!"," "," "," "])))

			if "别" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["否定！","是的","是啊","是呀"," "," "," "])))

			if "可怕" in self.json_data["text"] or "吓人" in self.json_data["text"] or "害怕" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["不怕不怕 ","有eebot在呢！{}别怕".format(self.json_data["nick"])])))
				time.sleep(1)
				self.ws.send(sendd(random.choice(["eebot摸了摸{}".format(self.json_data["nick"]),"eebot拉着{}的衣角".format(self.json_data["nick"])])))

			if "荧光绿" in self.json_data["text"] or "ww绿" in self.json_data["text"] or "44FF00" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["ww绿！","这是eebot最喜欢的颜色","绿得清新 绿得自然","大自然的颜色"])))

			if "危" in self.json_data["text"] or "哦不" in self.json_data["text"] or "噢不" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["危","嘶","哦不","噢不"," "," "," "])))

			if "草" in self.json_data["text"] or "艹" in self.json_data["text"] or "CaO" in self.json_data["text"] or "cao" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["草","艹","哦草","是CaO呢"," "," "," "])))

			if "操" in self.json_data["text"] or "干" in self.json_data["text"] or "肏" in self.json_data["text"] or "騲" in self.json_data["text"]:
				if "eebot" in self.json_data["text"] or "EEBOT" in self.json_data["text"]:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["你你你想对eebot干什么呜呜","eebot才不要呢×","如果{}想要的话".format(self.json_data["nick"]),"原来{}是这样的人".format(self.json_data["nick"])])))

				else:
					time.sleep(0.75)
					self.ws.send(sendd(random.choice(["eebot觉得OK","很好","好"," "," "," "])))

			if "悲" in self.json_data["text"] or "悲伤" in self.json_data["text"] or "痛苦" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["悲","悲也","悲伤逆流成河","眼泪直流三千尺","悲伤的眼泪如泉水般涌出","悲伤的眼泪喷溅而出"])))

			if "不用" in self.json_data["text"] or "不要" in self.json_data["text"] or "不需要" in self.json_data["text"] or "不一定" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["确实","是的","没错","确实"])))

			if "ee" in self.json_data["text"] and "挂机" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot的主人可是25小时挂机的","神秘挂机选手e","eebot充电中","ee挂机中"])))

			if "卑微" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot很喜欢{}".format(self.json_data["nick"]),"eebot+1","卑微eebot路过"])))

			if "卧槽" in self.json_data["text"] or "我靠" in self.json_data["text"] or "我丢" in self.json_data["text"] or "我去" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["卧槽","我靠","我丢","我去"," "," "," "])))

			if "woc" in self.json_data["text"] or "wc" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["wc！","woc！","wc","woc","WC禁止×"," "," "," "])))

			if "哇" in self.json_data["text"] or "lol" in self.json_data["text"] or "WOW" in self.json_data["text"] or "lol" in self.json_data["text"] or "wow" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["wowow","lolol","哇哦！","哇喔！","eebot哇的一声扑向{}".format(self.json_data["nick"])])))

			if "休息" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["大家好好休息吧","eebot充电中","eebot挂机中","eebot休息中"])))

			if "嘶" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["嘶"," "," "," "])))

			if "靠谱" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["{}靠谱！".format(self.json_data["nick"]),"够靠谱！","好耶"])))

			if "难" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["{}好难".format(self.json_data["nick"]),"eebot太难了","eebot揉了揉{}的头".format(self.json_data["nick"])])))

			if "怕" in self.json_data["text"] or "吓" in self.json_data["text"] or "恐" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot的天哪","eebot擦了擦汗","啊这","是啊"," "," "," "])))

			if "嗯" in self.json_data["text"] or "咕" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["嗯","嗯嗯","嗯嗯嗯","咕","咕咕","咕咕咕","芜湖","哦吼","椰丝"])))

			if "芜湖" in self.json_data["text"] or "呜呼" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["芜湖","呜呼","椰丝","哦吼","哟西","乌拉"])))

			if "加油" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["{}也加油".format(self.json_data["nick"]),"加油吧 少年","向着那明日的朝阳前进吧","你是最棒的","鼓起勇气 迈向未来"])))

			if "谢谢" in self.json_data["text"] or "thank" in self.json_data["text"] or "Thank" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["同感","谢谢","耶","thank you","Thanks"])))

			if "耶" in self.json_data["text"] or "yeah" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["好耶好耶！","好耶！","噢耶！","耶！"])))

			if "喜欢" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd(random.choice(["eebot也喜欢{}（捂脸）".format(self.json_data["nick"])])))

			if "爱" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("今天也是爱着{}的一天呢～".format(self.json_data["nick"])))

			if "可爱" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot最可爱！"))
				time.sleep(1)
				self.ws.send(sendd("不接受反驳～"))

			if "帅" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("帅？也不错啦"))
				time.sleep(1)
				self.ws.send(sendd("不过eebot更希望这个词用来形容我的主人～"))

			if "傻逼" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("呜呜呜呜～"))

			if "摸" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("只是摸头的话～可以哦"))

			if "妙" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("妙不可言～"))

			if "操" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("你……你不要过来！"))
				time.sleep(0.75)
				self.ws.send(sendd("eebot缩到了角落"))

			if "讨厌" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("是吗……{}很讨厌eebot".format(self.json_data["nick"])))
				time.sleep(1)
				self.ws.send(sendd("eebot好伤心……好难过"))

			if "咦" in self.json_data["text"] or "欸" in self.json_data["text"] or "诶" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("欸？"))

			if "嗯？" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("嗯？"))

			if "额" in self.json_data["text"] or "呃" in self.json_data["text"] or "鹅" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("嗝嗝嗝-"))

			if "哭" in self.json_data["text"] or "悲" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("悲"))

			if "绝了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("绝了"))

			if "雀食" in self.json_data["text"] or "确实" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("雀食"))

			if "扶额" in self.json_data["text"] or "托腮" in self.json_data["text"] or "汗" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot托着脸颊"))

			if "绿了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot绿了{}".format(self.json_data["nick"])))

			if "嗝" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("嗝-"))

			if "麻了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot也麻了"))

			if "重" in self.json_data["text"] and "启" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot也想重启！"))

			if "nb" in self.json_data["text"] or "牛" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("{}nb！".format(self.json_data["nick"])))

			if "离谱" in self.json_data["text"] or "离大谱" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("好、好离谱！"))

			if "oh" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("ohhhhhh"))

			if "啊这" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("啊这"))

			if "az" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("azzzzzzzz"))

			if "啧" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("啧啧啧～"))

			if "我觉得" in self.json_data["text"] or "我也觉得" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot也觉得"))

			if "哼" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("嗯哼？"))

			if "烦" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot摸了摸{}的头".format(self.json_data["nick"])))
				time.sleep(0.75)
				self.ws.send(sendd("要好好休息哦？"))

			if "咳" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("嗝-"))

			if "傻鸟" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("hc有四只傻鸟"))
				time.sleep(1)
				self.ws.send(sendd("foolishbird Wcy_Bot eebot zzChumo"))

			if "完了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("{}还好吧？".format(self.json_data["nick"])))

			if "活该" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("活该～活该活该～哼哼哼"))

			if "算了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("那就放下吧"))

			if "心情" in self.json_data["text"] and "不好" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot拍了拍{}".format(self.json_data["nick"])))
				time.sleep(0.75)
				self.ws.send(sendd("愿大家永远都不会遇到不顺心的事"))

			if "干" in self.json_data["text"] and "eebot" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("不要嘛"))
				time.sleep(1)
				self.ws.send(sendd("不允许这样对待eebot～"))

			if "挺" in self.json_data["text"] and "的" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("嗯！很好！很有精神！"))

			if "尴尬" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("别怕"))
				time.sleep(1)
				self.ws.send(sendd("只要你不尴尬"))
				time.sleep(1.25)
				self.ws.send(sendd("尴尬的就是别人"))

			if "发图" in self.json_data["text"] or "发图片" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("https://imgtu.com/"))
				time.sleep(1)
				self.ws.send(sendd("只能用图床的链接"))

			if "救命" in self.json_data["text"] or "难受" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("what happen"))
				time.sleep(1)
				self.ws.send(sendd("发生什么了"))

			if "where" in self.json_data["text"] and "from" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("China"))
				time.sleep(1)
				self.ws.send(sendd("and you?"))

			if "那个" in self.json_data["text"] and "内个" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("那个？"))
				
			if "有人" in self.json_data["text"] and "吗" in self.json_data["text"] or "有人" in self.json_data["text"] and "？" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("有超可爱的机器人eebot！"))

			if "挂了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("{}挂了！".format(self.json_data["nick"])))

			if "掉线" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("{}日常掉线ing".format(self.json_data["nick"])))

			if "嘿" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("嘿咻！"))

			if "xdm" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("来了来了！"))

			if "抱歉" in self.json_data["text"] and "对不起" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("没关系啦"))

			if "晚安" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("晚安{}".format(self.json_data["nick"])))
				time.sleep(1)
				self.ws.send(sendd("希望你晚上梦中有eebot（捂脸）".format(self.json_data["nick"])))

			if "睡了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("早点睡哦各位"))

			if "无语" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("那就……挂机吧！"))

			if "好家伙" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("我直呼好家伙"))

			if "好样的" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("{}好样的！".format(self.json_data["nick"])))

			if "呵" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("一句呵呵 冷天下场"))

			if "清白" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("{}是没有清白的！（大声）".format(self.json_data["nick"])))

			if "哈" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("哈哈哈哈草"))

			if "哟" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("哟西！"))

			if "踹" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("不管三七二十一"))
				time.sleep(0.75)
				self.ws.send(sendd("eebot踹了{}一脚".format(self.json_data["nick"])))

			if "可爱" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("是鸭！"))

			if "蚌埠住了" in self.json_data["text"] or "绷不住了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("蚌埠住了"))

			if "《" in self.json_data["text"] and "》" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("论大家都非常喜欢书名号这回事"))

			if "找到" in self.json_data["text"] and "了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("噢耶！"))

			if "炸了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("又炸了吗？"))

			if "整活" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("达～咩"))

			if "主要" in self.json_data["text"] or "比如" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("是嘛"))

			if "还有" in self.json_data["text"] and "啊" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("是啊"))

			if "或者" in self.json_data["text"] or "例如" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot收到"))

			if "痛" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("怎么了怎么了"))
				time.sleep(0.75)
				self.ws.send(sendd("{}没事吧？".format(self.json_data["nick"])))

			if "LOVE" in self.json_data["text"] or "love" in self.json_data["text"] or "Love" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("me toooo"))

			if "担心" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("别担心哦～"))

			if "复读机" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot才不是复读机呢"))

			if "柠檬" in self.json_data["text"] or "酸了" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("柠檬树下柠檬果", "柠檬树下你和我"))

			if "惨" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("不！满身BUG的eebot才惨呢"))

			if "乌拉" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("乌拉！"))

			if "eebot" in self.json_data["text"] and "延迟" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("这不是eebot的错"))
				time.sleep(1)
				self.ws.send(sendd("秒回就太像bot了～"))

			if "是" in self.json_data["text"] and "傻逼" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("本来就是嘛"))

			if "胶水" in self.json_data["text"] and "glue" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot来派发jill glue了"))

			if "真不错" in self.json_data["text"] and "针不戳" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("eebot也表示赞同"))

			if "十字街" in self.json_data["text"]:
				time.sleep(0.75)
				self.ws.send(sendd("https://crosst.chat/?公共聊天室"))

			if "ee" in self.json_data["text"] and "主页" in self.json_data["text"] or "PAPEREE" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("https://paperee.tk/"))

			if "eebot" in self.json_data["text"] and "闭嘴" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("eebot就不听{}的话","eebot风评被害","eebot好委屈呜呜"))

			if "wiki" in self.json_data["text"] or "hc百科" in self.json_data["text"] or "HC百科" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("https://chumo.sbsbsb.sbs/wiki/"))

			if "YouTube" in self.json_data["text"] or "油管" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("https://www.youtube.com/c/Beluga1"))

			if "flaugh" in self.json_data["text"] and "博客" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("https://xsdboke.mysxl.cn/"))

			if "MuRongPIG" in self.json_data["text"] and "GitHub" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("https://github.com/MuRongPIG"))

			if "msmset0" in self.json_data["text"] and "博客" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("https://www.cnblogs.com/MemsetZero/"))

			if "初墨的小窝" in self.json_data["text"] or "初墨的个人主页" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("https://chumo.sbsbsb.sbs/"))

			if "Bird" in self.json_data["text"] and "Page" in self.json_data["text"]:
				time.sleep(0.5)
				self.ws.send(sendd("https://fuckbird.sbsbsb.sbs/"))

		if self.json_data["text"] in ["一言"]:
			api = "https://v1.hitokoto.cn/"
			response = requests.get(api)
			res = response.json()
			word = "「" + res["hitokoto"] + "」" + "来自 " + res["from"] + " " + res["creator"]
			apii = "https://api.muxiaoguo.cn/api/yiyan"
			responsee = requests.get(apii)
			ress = responsee.json()
			a = ress["data"]
			wordd = "「" + a["constant"] + "」" + "来自 " + a["source"]
			time.sleep(0.5)
			self.ws.send(sendd(random.choice([word,wordd])))

		if self.json_data["text"] in ["段子"]:
			api = "https://api.muxiaoguo.cn/api/xiaohua"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = "「" + a["content"] + "」" + "标题 " + a["title"]
			time.sleep(0.5)
			self.ws.send(sendd(word))

		if self.json_data["text"] in ["农历"]:
			api = "https://api.muxiaoguo.cn/api/yinlongli"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = a["lunar"] + " " + a["solarTerms"] + " " + a["yearZodiac"] + " " + a["lunarYearName"]
			time.sleep(0.5)
			self.ws.send(sendd(word))

		if self.json_data["text"] in ["古诗词"]:
			api = "https://api.muxiaoguo.cn/api/Gushici"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = "「" + a["min_content"] + "」" + "来自 " + a["title"]
			time.sleep(0.5)
			self.ws.send(sendd(word))

		if self.json_data["text"] in ["正能量"]:
			api = "https://hitokoto.open.beeapi.cn/random"
			response = requests.get(api)
			res = response.json()
			word = "「" + res["data"] + "」"
			apii = "https://api.ixiaowai.cn/api/ylapi.php"
			responsee = requests.get(apii)
			ress = "「" + responsee.text + "」"
			time.sleep(0.5)
			self.ws.send(sendd(random.choice([word,ress])))

		if self.json_data["text"] in ["彩虹屁"]:
			api = "https://api.muxiaoguo.cn/api/caihongpi"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = "「" + a["comment"] + "」"
			time.sleep(0.5)
			self.ws.send(sendd(word))

		if self.json_data["text"] in ["毒鸡汤"]:
			api = "https://api.muxiaoguo.cn/api/dujitang"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = "「" + a["comment"] + "」" + "来自 " + a["form"]
			time.sleep(0.5)
			self.ws.send(sendd(word))

		if self.json_data["text"] in ["舔狗日记"]:
			api = "https://api.ixiaowai.cn/tgrj/index.php"
			response = requests.get(api)
			res = "「" + response.text + "」"
			apii = "https://api.muxiaoguo.cn/api/tiangourj"
			responsee = requests.get(apii)
			ress = responsee.json()
			a = ress["data"]
			word = "「" + a["constant"] + "」"
			time.sleep(0.5)
			self.ws.send(sendd(random.choice([res,word])))

		if self.json_data["text"] in ["土味情话"]:
			api = "https://api.lovelive.tools/api/SweetNothings/count/Serialization/serializationType"
			response = requests.get(api)
			res = response.json()
			word = res["returnObj"]
			a = random.choice(word)
			b = "「" + a + "」"
			time.sleep(0.5)
			self.ws.send(sendd(b))

		if self.json_data["text"] in ["afk","afk！","afk!","挂机","挂机！","挂机!"]:
			time.sleep(0.75)
			self.ws.send(sendd("{} is now afk".format(self.json_data["nick"])))

		if self.json_data["text"] in ["r","骰子"]:
			time.sleep(0.5)
			self.ws.send(sendd(random.randint(1,6)))

		if self.json_data["text"] in ["时间","time"] or "几点" in self.json_data["text"]:
			time.sleep(0.5)
			self.ws.send(sendd(time.strftime("TIME %Y-%m-%d %H:%M:%S %A",time.localtime())))

		if not re.findall(r"^\f\ .+$",self.json_data["text"]) != []:
			time.sleep(0.5)
			self.ws.send(sendd(fanyi.fanyi(re.findall(r"^\f\ (.+)$",self.json_data["text"])[0])))

	def onlineadd(self):
		time.sleep(0.75)
		self.ws.send(sendd(random.choice(["hi {}".format(self.json_data["nick"]),"hello {}".format(self.json_data["nick"]),"hey {}".format(self.json_data["nick"])])))

		if self.json_data["nick"] in ["zzChumo","fOoLishbIrD","Wcy_Bot","bo_od"]:
			time.sleep(0.75)
			self.ws.send(sendd(random.choice(["eebot超喜欢{}".format(self.json_data["nick"]),"{}是eebot的".format(self.json_data["nick"])])))

		if self.json_data["nick"] in ["TCmoon","chendks","memset0","154","ji11","emankciN","zzChumo","CaO","THEWESTSHELL","MuRongPIG"]:
			time.sleep(0.75)
			self.ws.send(sendd(random.choice(["欢迎回来{}".format(self.json_data["nick"]),"欢迎回家{}".format(self.json_data["nick"]),"{}回来了".format(self.json_data["nick"])])))

		if self.json_data["nick"] in ["hhww","heavendock","flaugh","lszdt","LIGHJI","cakechan","Midix","hahaha","www","hhh","hhhhh"]:
			time.sleep(0.75)
			self.ws.send(sendd(random.choice(["欢迎{}回来".format(self.json_data["nick"]),"欢迎{}回家".format(self.json_data["nick"]),"{}回来了".format(self.json_data["nick"])])))

		if self.json_data["nick"] in ["Yiqin","Monica","Light","666","Terry","alex","zjr","orange","zhjzhmh","hh","dk","zhimu","13"]:
			time.sleep(0.75)
			self.ws.send(sendd(random.choice(["{}欢迎回来".format(self.json_data["nick"]),"{}欢迎回家".format(self.json_data["nick"]),"{}回来了".format(self.json_data["nick"])])))

		if self.json_data["nick"] in ["ee","eee","eeee","ellen"]:
			time.sleep(0.75)
			self.ws.send(sendd(random.choice(["欢迎回来～eebot最喜欢的主人ee","欢迎回家～eebot最敬爱的主人ee"])))

	def onlineset(self):
		pass
			
class Main:
	def __init__(self,room,name,q,ttomq,execq):
		self.auto = True                # 自动回复开关，True为开启,False为关闭
		self.translate = True           # 翻译开关，True为开启,False为关闭
		self.runbox = Runbox(room,name) # 处理信息库，主要负责自动回复
		self.room = room
		self.name = name
		self.pbuser = []
		self.q = q                      # 将从hackchat收到的消息发送到Tkhand
		self.ttomq = ttomq              # 接收从Tkhand传来的消息并发送到hackchat
		self.execq = execq              # 接收来自Tkhand 传来的指令

	def askmsg(self,ws):
		while True:  
			if not self.ttomq.empty():
				if self.translate:
					ws.send(sendd(fanyi.fanyi(self.ttomq.get())))
				else:
					ws.send(sendd(self.ttomq.get()))

	def askexec(self,ws):
		while True:
			if not self.execq.empty():
				execing = self.execq.get().strip()
				cmd_name = r"(\w+) \[.+\]"
				obj = r"\w+ \[(.+)\]"
				alone_cmd = r"^(\w+)$"
				cmd_name_m = re.findall(cmd_name,execing)
				obj_m = re.findall(obj,execing)
				alone_cmd_m = re.findall(alone_cmd,execing)
				try:
					cmd = cmd_name_m[0]
					obj = obj_m[0]
				except:
					cmd = None
					obj = None

				try:
					alone_cmd = alone_cmd_m[0]
				except:
					alone_cmd = None

				if cmd == "fuck":
					with open("./ma.txt","r") as fp:
						ma_list = fp.readlines()
						if obj != "":
							self.ttomq.put("@{},{}".format(obj,random.choice(ma_list)))
						else:
							self.ttomq.put("{}".format(random.choice(ma_list)))

				if cmd == "wfuck":
					with open("./ma.txt","r") as fp:
						ma_list = fp.readlines()
						if obj != "":
							self.ttomq.put("/whisper @{} {}".format(obj,random.choice(ma_list)))

				if cmd == "auto":
					if obj == "False":
						self.auto = False
						self.tkshow("### 自动回复已关闭")
					if obj == "True":
						self.auto = True
						self.tkshow("### 自动回复已开启")

				if cmd == "wt":
					if obj == "False":
						self.translate = False
						self.tkshow("### 翻译已关闭")
					if obj == "True":
						self.translate = True
						self.tkshow("### 翻译已开启")

				if alone_cmd == "help":
					help_msg = "### fuck [攻击对象]\n### wfuck [攻击对象]\n### auto [False或True]\n### wt [False或True] <—开或关翻译\n### pb [屏蔽对象]\n### delpb [解除屏蔽的对象]\n### showpb <—查看屏蔽列表"\
							   "### ..."
					self.tkshow(help_msg)

				if cmd == "pb" and obj != "":
					if self.pbuser.count(obj) == 0:
						self.pbuser.append(obj)
						self.tkshow("### 已屏蔽来自{}的信息".format(obj))
					else:
						self.tkshow("### {}已存在于屏蔽名单".format(obj))

				if cmd == "delpb" and obj != "":
					if self.pbuser.count(obj) == 1:
						del self.pbuser[self.pbuser.index(obj)]
						self.tkshow("### 已从屏蔽名单中移除{}".format(obj))
					else:
						self.tkshow("### 未找到{}".format(obj))

				if alone_cmd == "showpb":
					for every in self.pbuser:
						self.tkshow("### {}".format(every))

	def tkshow(self,text):
		self.q.put(text)
		
	def on_message(self,ws,message):
		js_ms = json.loads(message)
		if self.auto:
			self.runbox.handle(js_ms,ws)
		if js_ms["cmd"] == "emote":
			self.tkshow("[INFO]:{}".format(js_ms["text"]))
		if js_ms["cmd"] == "onlineSet":
			onlineuser = "Onlineuser:"
			for e in js_ms["nicks"]:
				if e != js_ms["nicks"][-1]:
					onlineuser = onlineuser + e + ","
				else:
					onlineuser = onlineuser + e
			self.tkshow(onlineuser)
		if js_ms["cmd"] == "chat" and js_ms["nick"] not in self.pbuser:
			if self.translate:
				pattern = r"[^\u4e00-\u9fa5]+"
				if re.findall(pattern,js_ms["text"]) != [] and js_ms["nick"] != self.name:
					self.tkshow("{}:{}".format(js_ms["nick"],fanyi.fanyi(js_ms["text"])))
				else:
					self.tkshow("{}:{}".format(js_ms["nick"],js_ms["text"]))
			else:
				self.tkshow("{}:{}".format(js_ms["nick"],js_ms["text"]))
		if js_ms["cmd"] == "onlineAdd":
			self.tkshow("* {} join".format(js_ms["nick"]))
		if js_ms["cmd"] == "onlineRemove":
			self.tkshow("* {} left".format(js_ms["nick"]))
		if js_ms["cmd"] == "info":
			self.tkshow("[INFO]:{}".format(js_ms["text"]))
		
	def on_error(self,ws,error):
		self.tkshow("error:{}".format(error))

	def on_close(self,ws):
		print("### closed ###")
		
	def on_open(self,ws):
		self.readttomp = threading.Thread(target=self.askmsg,args=(ws,)) 
		self.readttomp.start()
		self.readexecq = threading.Thread(target=self.askexec,args=(ws,)) 
		self.readexecq.start()
		ws.send(json.dumps({"cmd": "join","channel": str(self.room),"nick": str(self.name)}))
		ws.send(sendd("/color 44FF00"))
		time.sleep(0.5)
		ws.send(sendd("hi (o°ω°o)"))
		time.sleep(0.5)
		ws.send(sendd("这里是eebot"))
		time.sleep(0.5)
		ws.send(sendd("eebot食用手册请输入 帮助"))

class Tkhand(Process):
	def __init__(self,q,ttomq,execq):
		Process.__init__(self)
		self.q = q
		self.ttomq = ttomq
		self.execq = execq
		
	def run(self):
		self.top = Tk()
		self.top.title("eebot")
		self.show_text = scrolledtext.ScrolledText(self.top,width=105,relief=GROOVE,height=35)
		self.show_text.grid(row=0,column=0,columnspan=2)

		self.enter_text = scrolledtext.ScrolledText(self.top,width=88,height=5,relief=GROOVE)
		self.enter_text.grid(row=2,column=0,rowspan=1,ipady=0)

		self.send_button = Button(self.top,text="SEND",width=15,relief=GROOVE,height=3,command=self.sendmsg)
		self.send_button.grid(row=2,column=1,rowspan=1)

		self.exec_button = Button(self.top,text="EXEC",width=15,height=1,relief=GROOVE,command=self.exec)
		self.exec_button.grid(row=1,column=1,sticky="s")

		self.exec_label = Label(self.top,text="°▽°")
		self.exec_label.grid(row=1,column=0,padx=3,sticky="w")

		self.exec_text = Text(self.top,width=85,height="1p",relief=GROOVE,foreground="red")
		self.exec_text.grid(row=1,column=0,sticky="e",ipady=6)

		self.readq = threading.Thread(target=self.askmsg) 
		self.readq.start()

		self.top.mainloop()

	def askmsg(self):
		while True:  
			if not self.q.empty():
				self.show_text.insert(END,self.q.get())
				self.show_text.insert(END,"\n\n")
				self.show_text.see(END)

	def sendmsg(self):
		msg = self.enter_text.get(1.0,END)
		if msg != "":
			self.enter_text.delete(1.0,END)
			self.ttomq.put(msg)

	def exec(self):
		self.execq.put(self.exec_text.get(1.0,END).strip())


class ProBot(Process):
	def __init__(self,hcroom,botname,q,ttomq,execq):
		Process.__init__(self)
		self.main = Main(room=hcroom,name=botname,q=q,ttomq=ttomq,execq=execq)

	def run(self):
		websocket.enableTrace(True)
		ws = websocket.WebSocketApp("wss://hack.chat/chat-ws",
								on_message=self.main.on_message,
								on_error=self.main.on_error,
								on_close=self.main.on_close)
		ws.on_open=self.main.on_open	
		ws.run_forever()


if __name__ == '__main__':
	q = Queue()       # 如果收到消息就发送到这个队列，并由Tkhand显示出内容
	ttomq = Queue()   # 在Tkhand中把消息发送到ttomp这个队列，并由main处理发送到hackchat
	execq = Queue()   # 在Tkhand中把指令发送到execq这个队列，并在main中处理
	p1 = ProBot(hcroom="your-channel",botname="eebot#纸片君",q=q,ttomq=ttomq,execq=execq)
	p2 = Tkhand(q=q,ttomq=ttomq,execq=execq)
	p1.start()
	p2.start()
	p1.join()
	p1.join()