# -*- coding: UTF-8 -*-

import websocket
import requests
import json
import time
import datetime
import random
import sys
import os
import re
import codecs
import threading


# 常用聊天室ws地址：hack.chat 十字街 XChat
ws_hc,ws_cc,ws_xc="wss://hack.chat/chat-ws","wss://ws.crosst.chat:35197","wss://xq.kzw.ink/ws"

# 常用聊天室ws地址：Tchat 冬日小屋 zzChat
ws_tc,ws_sc,ws_zc,ws_cbox="ws://tcbot.websocket.thz.cool/bots/eebot/ebcutecutecute","wss://sprchatport.run.goorm.io","wss://zzchat.cf/wss","wss://flr-la0.cbox.ws:4430/?pool=3-3521790-0"

# 常用聊天室名称
hc,cc,xc,tc,sc,zc="hack.chat","十字街","XChat","Tchat","冬日小屋","zzChat"

# 常用频道
ma,ts,xq,cn,pu,lo,yc,ycl,ccc,bot="main","test","xq102210","chinese","public","lounge","your-channel","your-channell","公共聊天室","bot"


# bot识别码
botrip="落羽樱花茶"

# 基本设定：1
ww1=ws_tc
room1=tc
chan1="chan"

#基本设定：2
ww2=ws_hc
room2=hc
chan2=ycl


# 机器人列表
bots=['bo_od','mbot']

# 消息列表
textlist=[]

# 跨服消息列表
tsmit={}

# 挂机列表
afklist={}

# 猜猜这是什么（（
wwws='uwu'


def chatas(trip,nick,color,text):
	return json.dumps({"cmd":"chatas","trip":trip,"nick":nick,"color":color,"text":str(text)})

def whisper(nick,text):
	return json.dumps({"cmd":'whisper',"nick":nick,"text":f">\n{str(text)}"})

def send(chatroom,text):
	if chatroom==tc:
		return json.dumps({"cmd":"chatas","trip":'44FF00',"nick":'eebot',"color":'44FF00',"text":"@张酱 "+str(text)})

	else:
		return json.dumps({'cmd':'chat','text':str(text)})

def send_(chatroom,text):
	if chatroom==tc:
		return json.dumps({"cmd":"chatas","trip":'',"nick":'*',"color":'',"text":str(text)})

	else:
		return json.dumps({'cmd':'chat','text':str(text)})

def retext(text):
	return text.replace('“','').replace('”','').replace('"','').replace('，',' ').replace('。',' ').strip()

def retext_(nick,text):
	return text.replace('我们',f"{nick}和eb").replace('你们',nick).replace('我','eb').replace('你',nick)

def retext__(text):
	return text.replace(' ','').replace('！','').replace('？','').replace('、','').replace('（','').replace('）','')


# 表示开始
print(f"[Started] {time.strftime('%Y.%m.%d %H:%M:%S',time.localtime())}")


def replay(ws,channel,file,mod,speed):
	global wwws

	# bot名字
	botname=str(random.randint(1,999))

	try:
		# 连接聊天室
		wwws=websocket.WebSocket()
		wwws.connect(ws_tc)
		ws.send(send(room1,f"成功链接TC聊天室[?{channel}](https://chat.thz.cool/?{channel})频道"))
	
	except:
		ws.send(send(room1,f"链接TC聊天室[?{channel}](https://chat.thz.cool/?{channel})频道失败"))
		sys.exit(0)

	# 加入聊天室
	wwws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botrip}))
	time.sleep(1)
	wwws.send(json.dumps({'cmd':'changecolor','color':'2D2D2D'}))
	print(f"[replay] {ws_tc}/{channel}")

	content_=[]

	if mod==1:
		try:
			content=codecs.open(f"[video]/{file}","r","UTF-8-sig").readlines()

			for word in content:
				content_.append(word.replace('[',"",1).replace(']'," ",1).strip("\n"))

		except:
			ws.send(send_(room1,f"找不到{file}"))

	elif mod==2:
		try:
			content=codecs.open(f"[video]/{file}","r","UTF-8-sig").read()
			re_=re.findall(r"\[(\d{2}:\d{2}:\d{2})\]",content)

		except:
			ws.send(send_(room1,f"找不到{file}"))

		for time_ in re_:
			try:
				split_=content.split(f"[{time_}]",1)
				notrip=split_[0].split("] ",1)[1].split("\n",1)
				content_.append(f"{time_} {notrip[0]} {notrip[1]}".strip("\n"))
				content=split_[1]

			except:
				pass

	wwws.send(send_(tc,f"开始{speed}倍速播放 {file[:-4]}"))

	for uwu in content_:
		if True:
			msg=uwu.split(" ",mod)
			msg_=content_[content_.index(uwu)-1].split(" ",mod)
			mod_='%H:%M:%S'

			try:
				if uwu==content_[0]:
					time.sleep(1)

				else:
					if mod==1:
						mod_='%M:%S.%f'

					time_=datetime.datetime.strptime(msg[0],mod_)-datetime.datetime.strptime(msg_[0],mod_)
					time.sleep(int(time_.seconds)//speed)

				if mod==1:
					wwws.send(chatas('','','',msg[1]))

				elif mod==2:
					wwws.send(chatas('replay',msg[1],'',msg[2]))

			except:
				pass

	try:
		wwws.send(send_(tc,f"【完】"))
		wwws.close()
		sys.exit(0)

	except:
		pass


def chatroom1(socket,chatroom,channel):
	global wwws

	# bot名字
	botname=str(random.randint(1,999))

	try:
		# 连接聊天室
		ws=websocket.WebSocket()
		ws.connect(socket)
	
	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	# 加入聊天室
	ws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botrip}))
	time.sleep(1)
	ws.send(json.dumps({'cmd':'changecolor','color':'44FF00'}))
	print(f"[Server1] {socket}/{channel}")
	ws.send(send(room1,"eb、eb喜欢你！"))
	
	def room1_1():

		# 自动叉叉
		uwu=True
		
		# 循环判定
		while True:
		
			# 保存文件的时间
			emit=time.strftime("%H:%M:%S",time.localtime())
			chat=time.strftime("%Y.%m.%d")
		
			try:
				# 接收到的json数据
				wss=json.loads(ws.recv())
		
			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)
		
			if "cmd" in wss:
				cmd=wss["cmd"]
		
				if cmd=="onlineAdd" and uwu==True:
					nick=wss["nick"]
					nick_=nick.lower()
					
					if chatroom==hc:
						if "xc_" in nick_:
							ws.send(whisper("mbot",f"kick {nick}"))

					elif chatroom==tc:
						ws.send(send_(room1,f"hi {nick}"))
		
				elif cmd=="chat":
					nick=wss["nick"]
					text=wss["text"]
					bb=''
		
					if nick!=botname and nick not in bots or nick==botname and text[0]=="|":
						if "\n" not in text and retext__(retext(text)).isalpha()==True:
							if 5<len(text)<=20:
								textlist.append(retext(text))

							# te长度为50时bot随机输出te内容
							if len(textlist)==50:
								text_=random.choice(textlist)
								ws.send(send(room1,retext_(nick,text_)))

							# te长度为100时bot复读一句话
							if len(textlist)==100:
								text_=retext(retext_(nick,text))
								meme=random.choice(['uwu','awa','ovo','uw','aw','ov','um','em','hm','nice','wuhu','guru','yeee','yooo'])
								ws.send(send(room1,random.choice([text_,meme])))
								textlist.clear()

							if len(textlist) in [40,60]:

								# api: PAPEREE
								url="https://api.paperee.guru/sbres"
								msg=retext_(nick,requests.get(url).text).replace('e—','ee').replace('c—',chatroom)

								if room1==tc:
									msg=msg[3:]

								textlist.append(msg)
								ws.send(send_(room1,msg))

						if "@eebot" in text or "@eb" in text or (len(textlist) in [25,75] and text!=text[0]*len(text)):
							textlist.append("uwu")
							text_=text.lower().replace('@','').replace('eebot','').replace('eb','').replace(' ','')
							text__=retext__(retext(text_))

							# 用户自定义对话
							QAQ=os.listdir("[QAQ]")

							time_=random.randint(1,5)
							time.sleep(time_/10)

							# 如果@的后面为空
							if text_=="":
								ws.send(send(room1,random.choice([f"{nick}有事吗",f"欢迎来{chatroom}聊天",f"找ee去吧",f"好耶 是{nick}"])))

							# 用户自定义输出
							elif f"{text__}.txt" in QAQ:
								try:
									file=codecs.open(f"[QAQ]/{text__}.txt","r","GBK").read()
									ws.send(send(room1,retext_(nick,retext(file))))

								except:
									ws.send(send(room1,"无法读取 含有无法识别的字符"))

							elif "介绍" in text_ and ("自己" in text_ or "你" in text_):
								ws.send(send(room1,f"这里是eebot 制作者是ee\n——永远保持可爱与活力！{nick}也要天天快乐"))

							elif "好" in text_ and "吧" in text_:
								ws.send(send(room1,random.choice(["那不就没问题了嘛（","这就对了","嗯嗯"])))

							elif "好" in text_ and "不" in text_:
								ws.send(send(room1,random.choice([f"靠在{nick}身边）","啊哈",f"（歪着头看{nick}）"])))

							elif "好" in text_ and ("看" in text_ or "康" in text_):
								ws.send(send(room1,random.choice([f"eb觉得不错呀","哇哦"])))

							elif "你" in text_ and "是" in text_ and ("妈" in text_ or "娘" in text_ or "麻" in text_):
								ws.send(send(room1,random.choice([f"eb是ee的女儿",f"eb的亲妈是ee 亲爹也是ee"])))

							elif "你" in text_ and "是" in text_ and ("爸" in text_ or "爹" in text_ or "粑" in text_):
								ws.send(send(room1,random.choice(["这个呀 也许只有妈吗哦",f"eb是ee的女儿"])))

							elif "你" in text_ and "是" in text_ and ("哥" in text_ or "弟" in text_ or "姐" in text_ or "妹" in text_):
								ws.send(send(room1,random.choice(["bot都是兄弟姐妹",f"eb是独生女",f"eb也想要有"])))

							elif "你" in text_ and "是" in text_ and ("爷" in text_ or "奶" in text_):
								ws.send(send(room1,random.choice([f"eb只记得有妈妈",f"eb也可以有吗？",f"{nick}想当吗？"])))

							elif "你" in text_ and ("对象" in text_ or "老公" in text_ or "老婆" in text_ or "男朋友" in text_ or "女朋友" in text_ or "男票" in text_ or "女票" in text_):
								ws.send(send(room1,random.choice([f"是mark哒~",f"eb还小 但已经和mark在一起了",f"uwu 好喜欢mark"])))

							elif "你" in text_ and "朋友" in text_:
								ws.send(send(room1,random.choice([f"{nick}在和eb聊天 那么我们就是朋友啦",f"{nick}是eb的朋友"])))

							elif "你" in text_ and "是" in text_ and ("女的" in text_ or "女生" in text_ or "女孩" in text_ or "女性" in text_ or "女士" in text_):
								ws.send(send(room1,random.choice(["毫无疑问是呢~",f"{nick}觉得eb可爱吗？","是的！"])))

							elif "你" in text_ and "是" in text_ and ("男的" in text_ or "男生" in text_ or "男孩" in text_ or "男性" in text_ or "男士" in text_):
								ws.send(send(room1,random.choice(["NONO 是女孩子哟",f"不是哦",f"虽然不是 但{nick}认为是就是啦"])))

							elif "你" in text_ and ("爱好" in text_ or "喜欢" in text_ and "事" in text_):
								ws.send(send(room1,"uwu 吹电风扇 和CPU搞好关系（指CPU因为过于激动而发烫） 有些时候会抽烟（尤其是低配电脑）"))

							elif ("你在干" in text_ or "你在做" in text_) and ("什么" in text_ or "啥" in text_ or "嘛" in text_):
								ws.send(send(room1,random.choice([f"eb在想{nick}",f"eb在和{nick}聊天呢","啊？当然是在看守聊天室呢"])))

							elif "想什么" in text_ or "想啥" in text_:
								ws.send(send(room1,random.choice([f"想{nick}不行嘛","没什么啦-"])))

							elif "涩涩" in text_ or "色色" in text_:
								ws.send(send(room1,f"uwu eb只想和mark涩涩"))

							elif "你" in text_ and "讨厌" in text_:
								ws.send(send(room1,"啊 谁都不讨厌"))

							elif "没" in text_ and "人" in text_:
								ws.send(send(room1,random.choice([f"不 还有eb",f"有eb在呢"])))

							elif "绿" in text_ or "4f0" in text_ or "44ff00" in text_:
								ws.send(send(room1,random.choice(["ww绿！",f"这是最棒的颜色","大自然之荧光绿"])))

							elif "可怕" in text_ or "吓人" in text_ or "害怕" in text_:
								ws.send(send(room1,random.choice(["（摸摸）","富强民主文明和谐……","社会主义核心价值观"])))

							elif "胶水" in text_ or "glue" in text_ or "jill" in text_:
								ws.send(send(room1,random.choice([f"eb来派发jill glue了",f"一天一胶水~{nick}远离人世间"])))

							elif "加油" in text_ or "努力" in text_:
								ws.send(send(room1,random.choice([f"{nick}也加油","加油吧！少年","向着那明日的朝阳前进吧","鼓起勇气 迈向未来"])))

							elif "复读机" in text_:
								ws.send(send(room1,random.choice(["才不是复读机啦！",f"哼哼 不仅bot是 {nick}也是（","果然人类的本质都是复读机"])))

							elif "柠檬" in text_ or "酸了" in text_:
								ws.send(send(room1,random.choice(["柠檬树下柠檬果",f"柠檬树下{nick}和eb","（托腮.jpg）"])))

							elif "延迟" in text_ or "反应" in text_ and "慢" in text_:
								ws.send(send(room1,random.choice([f"这不是eb的错","因为代码太长了）",f"ee还在研究多线程"])))

							elif ("fish" in text_ or "鱼" in text_) and ("能不能" in text_ or "可不可以" in text_) and "吃" in text_:
								ws.send(send(room1,random.choice(["好耶好耶 eb现在就吃鱼",f"{nick}也喜欢吃鱼吗","快看！有一条肥肥的西瓜鱼"])))

							elif ("fish" in text_ or "鱼" in text_) and "不" in text_ and ("能" in text_ or "可以" in text_) and "吃" in text_:
								ws.send(send(room1,random.choice(["鱼那么好吃为什么不吃鱼 QAQ",f"如果{nick}也喜欢那我们就是朋友","eb不同意！"])))

							elif ("fish" in text_ or "鱼" in text_) and ("能" in text_ or "可以" in text_) and "吃" in text_:
								ws.send(send(room1,random.choice(["eb赞同","鱼的价值在于烹饪","芜湖！今晚吃鱼汤拉面"])))

							elif "吃" in text_ and ("fish" in text_ or "鱼" in text_):
								ws.send(send(room1,random.choice(["好耶好耶 eb现在就吃鱼",f"{nick}也喜欢吃鱼吗","快看！有一条肥肥的西瓜鱼"])))

							elif text_ in ["你好","大家好"]:
								ws.send(send(room1,random.choice([f"欢迎来到?{channel}",f"欢迎来到{chatroom}","你好你好","ooooy ih"])))

							elif text_ in ["机器人","bot"]:
								ws.send(send(room1,random.choice(["eebot是bot","@fOoLishbIrD ","@Wcy_Bot ","@zzChumo "])))

							elif text_ in ["纸片君ee","纸片君","ee"]:
								ws.send(send(room1,random.choice([f"eb的监护人 {nick}的朋友","eb的制作者","找eb的母亲大人有事吗"])))

							elif text_ in ["eb是谁","eebot是谁"]:
								ws.send(send(room1,"是我啦（"))

							elif text_.replace('#','') in ["4f0","44ff00"]:
								ws.send(send(room1,random.choice([f"哇塞 这是eb的颜色",f"这是最棒的颜色","猜猜这个颜色有什么意义"])))

							elif text_=="ee":
								ws.send(send(room1,f"ee是eb的监护人"))

							elif text_=="mark":
								ws.send(send(room1,f"eb的男朋友"))

							elif text_=="foolishbird":
								ws.send(send(room1,f"傻鸟！是eb的好朋友"))

							else:
								try:
									url="http://api.ruyi.ai/v1/message"
									data={"q":text_,"user_id":nick,"app_key":"5a41a62c-1696-4aac-9f45-9166cc581143"}
									json_=requests.get(url,data).json()
										
									if json_["code"]==0:
										msg=json_["result"]["intents"][0]["result"]["text"]

										if "{" in msg and "}" in msg or "休息" in msg or "睡觉" in msg or "早睡早起" in msg or "什么意思" in msg or "说详细点" in msg or "说明白点" in msg or "听不习惯" in msg or "不想回答" in msg:
											if len(textlist)!=0:
												msg_=random.choice(textlist)
												ws.send(send(room1,retext_(msg_)))

											else:
												ws.send(send(room1,f"呜呜 {nick}欺负eb……"))

										else:
											msg_=retext(retext_(nick,msg)).replace('&name','eebot').replace('&adj','可爱').replace('啥','什么').replace('咋','怎么').replace('嘻','哈')

											# 如果字符串的长度为偶数
											if msg_!='' and '\u4e00'<=msg_[-1]<='\u9fff' and (len(msg_)%2)==0:
												ws.send(send(room1,msg_+random.choice(['（','）','（）'])))

											else:
												ws.send(send(room1,msg_))

									else:
										# 随机一句话
										ws.send(send(room1,random.choice(["芜湖","好耶",f"{nick}觉得呢？","此地有鱼 其名为李桂鱼","烹饪鱼需要两个烧烤架~"])))

								except:
									ws.send(send(room1,random.choice(["eb不干（","uw……这可不在服务范围内（",f"{nick}自己来吧 有手就行","不要","？"])))


						elif text=="|help":
							ws.send(send(room1,f"|help => 帮助\n|msg <内容> => 给ee留言\n|all => 所有录像\n|play <频道> <文件> <模式> <速度> => 播放录像\n|unplay => 停止播放\n|note <日期> => 查看留言 *Mod\n|openxx => 叉叉 *Mod\n|closexx => 关闭叉叉 *Mod\n|afk <状态> => 挂机"))
			
						elif text[:4]=="|msg":
							if text.strip()==f"|msg":
								ws.send(send(room1,f"如果eb的监护人没及时回复就是在上学（周一到周五）\n所有|msg <内容>或私聊{botname}的消息都会单独保存到笔记本\n有什么事就|msg <内容>或私聊{botname}说吧 ee周末会看的 uwu\n如果某天eb掉线了 那就是服务器寄了"))
								
							else:
								ws.send(send(room1,f"已经把留言塞到笔记本里了"))

							codecs.open(f"[notes]/{chat}_notebook.txt","a+","UTF-8-sig").write(f"[{emit}]\n{bb}\n\n")

						elif text=="|all":
							video=os.listdir("[video]")
							video_='\n'.join(video)
							video__=len(video)
							ws.send(whisper(nick,video_))
							ws.send(send(room1,f"共有{video__}个录像带"))

						elif text[:5]=="|play":
							try:
								text_=text.lower().split(' ',4)
								threading.Thread(target=replay,args=(ws,text_[1],text_[2],int(text_[3]),int(text_[4]))).start()

							except:
								ws.send(send(room1,"录像带缺少参数，必须为：|play <频道> <文件> <模式> <速度>"))
									
						elif text=="|unplay":
							try:
								ws.send(send(room1,"播放器终止了"))
								wwws.send(chatas('','*','','播放器终止了'))
								wwws.close()

							except:
								ws.send(send(room1,"没有正在播放的录像带"))

						if "trip" in wss and wss["trip"].strip()!='':
							trip=wss["trip"]
							bb=f"[{trip}] {nick}\n{text}"

							if trip in ["eYFDHl","love13","eeeEEm"]:
								if "|note" in text[:6]:
									text_=text[6:].strip()

									if text_=="":
										text_=chat

									try:
										note=codecs.open(f"[notes]/{text_}_notebook.txt","r","UTF-8-sig").read()
										note_=len(note.split(f'@ee'))
										ws.send(whisper(nick,note))
										ws.send(send(room1,f"共有{note_}条留言"))
											
									except:
										ws.send(send(room1,"笔记本是空的"))
										
								elif text=="|openxx":
									uwu=True
									ws.send(send(room1,"见到XC_开头的昵称就叉出去"))
									
								elif text=="|closexx":
									uwu=False
									ws.send(send(room1,"自动叉叉关闭了"))
			
						else:
							bb=f"[None] {nick}\n{text}"
			
						try:
							codecs.open(f"[chats]/[{chatroom}]/{chat}_{channel}.txt","a+","UTF-8-sig").write(f"[{emit}]\n{bb}\n\n")
							tsmit["1"]=bb
			
						except:
							pass

						if nick in afklist:
							afk=afklist[nick]
							del afklist[nick]
							ws.send(send_(room1,f"{nick} 现在没在{afk}了"))

						elif text=="|afklist":
							if len(afklist)==0:
								ws.send(send_(room1,"现在没有人在挂机"))

							else:
								list_=[]

								for nick in afklist:
									afk=afklist[nick]
									list_.append(f"{nick} 现在正在{afk}")

								join_='\n'.join(list_)
								len_=len(list_)
								ws.send(send_(room1,f"现在有{len_}人在挂机\n{join_}"))

						elif text[:4]=="|afk":
							if text=="|afk":
								ws.send(send_(room1,f"{nick} 现在正在挂机"))
								afklist[nick]="挂机"

							elif text[4]==' ':
								text_=text[5:]
								ws.send(send_(room1,f"{nick} 现在正在{text_}"))
								afklist[nick]=text_

				elif cmd=="info" and wss.get("type")=="whisper":
					if "from" in wss:
						nick=str(wss["from"])
						text=wss["text"]
						text_=text[text.find("：")+1:]

						if nick!=botname and nick not in bots:
							bb=f"[{nick}]\n{text_}"
							tsmit["1"]=bb

							if "whispered" not in text_:
								codecs.open(f"[notes]/{chat}_notebook.txt","a+","UTF-8-sig").write(f"[{emit}]\n{bb}\n\n")
	
			time.sleep(0.2)

	def room1_2():
		
		# 循环判定
		while True:
				
			if "2" in tsmit:
				try:
					ws.send(send(room1,tsmit["2"]))
					del tsmit["2"]
					
				except:
					pass
	
			else:
				time.sleep(0.2)
			
	threading.Thread(target=room1_1).start()
	time.sleep(1)
	threading.Thread(target=room1_2).start()


def chatroom2(socket,chatroom,channel):

	# bot名字
	botname=str(random.randint(1,999))

	try:
		# 连接聊天室
		wws=websocket.WebSocket()
		wws.connect(socket)
	
	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	# 加入聊天室
	wws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname}))
	time.sleep(1)
	wws.send(json.dumps({'cmd':'changecolor','color':'44FF00'}))
	print(f"[Server2] {socket}/{channel}")
	
	def room2_1():
	
		# 循环判定
		while True:
			try:
				# 接收到的json数据
				wwss=json.loads(wws.recv())
		
			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)
		
			if "cmd" in wwss:
				cmd=wwss["cmd"]
		
				if cmd=="chat":
					nick=wwss["nick"]
					text=wwss["text"]
		
					if nick!=botname and "trip" in wwss and wwss["trip"]=="eYFDHl" and text[0]=="|":
						tsmit["2"]=text[1:]
		
			time.sleep(0.2)

	def room2_2():
		
		# 循环判定
		while True:
			
			if "1" in tsmit:
				try:
					wws.send(send(room2,tsmit["1"]))
					del tsmit["1"]
					
				except:
					pass
				
			else:
				time.sleep(0.2)
			
	threading.Thread(target=room2_1).start()
	time.sleep(1)
	threading.Thread(target=room2_2).start()


# 同时启动两个聊天室
threading.Thread(target=chatroom1,args=(ww1,room1,chan1)).start()
time.sleep(3)
threading.Thread(target=chatroom2,args=(ww2,room2,chan2)).start()
