﻿import datetime
import time
import re
import codecs




def replay(channel,color):
	try:
		# 连接聊天室
		wws=websocket.WebSocket()
		wws.connect(socket)
	
	except:
		ws.send(send(f"[自动回复]\n链接目标聊天室失败"))

	# 加入聊天室
	wws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname}))
	time.sleep(1)
	wws.send(json.dumps({'cmd':'changecolor','color':color}))
	print(f"[Server2] {socket}/{channel}")


	history=codecs.open("[chats]/[Tchat]/2022.09.25_lounge.txt","r","UTF-8").read()
	re_=re.findall(r"\[(\d{2}:\d{2}:\d{2})\]",history)
	print(re_)


	history_=[]

	for time_ in re_:
		try:
			split_=history.split(f"[{time_}]",1)
			notrip=split_[0].split("] ",1)[1].split("\n",1)
			history_.append(f"{time_} {notrip[0]} {notrip[1]}".strip())
			history=split_[1]

		except:
			pass


	for uwu in history_:
		try:
			msg=uwu.split(" ",2)
			msg_=history_[history_.index(uwu)-1].split(" ",2)

			if history_[0]==uwu:
				time.sleep(1)

			else:
				time_=datetime.datetime.strptime(msg[0],'%H:%M:%S')-datetime.datetime.strptime(msg_[0],'%H:%M:%S')
				time.sleep(int(time_.seconds))

			ws.send(chatas('replay',msg[1],'',msg[2]))

		except:
			pass
