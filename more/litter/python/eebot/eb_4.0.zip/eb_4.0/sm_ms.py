import requests
import json
import codecs

def upload(file):
	url='https://sm.ms/api/v2/upload'
	header_={'Authorization':'HzqjuaAtIquTnejszBzLn14trGpzicj8'}
	data={'smfile':codecs.open(file,"rb")}
	json_=requests.post(url,files=data,headers=header_).json()
	return f"![]({json_['data']['url']})"