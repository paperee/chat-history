import wordcloud
import time
# import numpy
# import PIL

def cloud(nicks):
	nicks_=' '.join(nicks)
	# background=PIL.Image.open("[word]/hack.chat.png")
	# graph=numpy.array(background)
	# mask=graph
	wordcloud_=wordcloud.WordCloud(background_color="white",font_path="[word]/霞鹜臻楷.ttf",colormap="summer",collocations=False,max_words=57,width=640,height=640,min_font_size=32,max_font_size=128,margin=32)
	image=f"[temp]/{time.strftime('%Y.%m.%d %H:%M:%S',time.localtime())}.png"
	
	wordcloud_.generate(nicks_)
	wordcloud_.to_file(image)
	
	return image