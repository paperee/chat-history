# -*- coding: UTF-8 -*-

import json
import time
import datetime
import random
import sys
import os
import re
import codecs
import threading
import urllib.request

import websocket
import requests
import opencv
import googletrans
import uwuify

import word_cloud
import sm_ms


# 常用聊天室ws地址：hack.chat 十字街 XChat
ws_hc,ws_cc,ws_xc="wss://hack.chat/chat-ws","wss://ws.crosst.chat:35197","wss://xq.kzw.ink/ws"

# 常用聊天室ws地址：Tchat 冬日小屋 zzChat
ws_tc,ws_sc,ws_zc,ws_cbox="ws://tanchat.fun/chat-ws","wss://sprchatport.run.goorm.io","wss://zzchat.cf/wss","wss://flr-la0.cbox.ws:4430/?pool=3-3521790-0"

# 常用聊天室名称
hc,cc,xc,tc,sc,zc="hack.chat","十字街","XChat","Tchat","冬日小屋","zzChat"

# 常用频道
ma,ts,xq,cn,pu,lo,yc,ycl,lby,bot="main","test","xq102210","chinese","public","lounge","your-channel","your-channell","lobby","bot"


# bot识别码
botrip="保密"

# 基本设定：1
ww1=ws_hc
room1=hc
chan1=yc

#基本设定：2
ww2=ws_hc
room2=hc
chan2=ycl


# 机器人列表
bots=['bo_od','mbot']

# 表情列表
umoji=['6','uwu','awa','ovo','uw','aw','ov','um','em','hm','nb','idk','yep','yup','nice','wuhu','guru']

# 消息列表
textlist=[]

# 使用者列表
users=[]

# 跨服消息列表
tsmit={}

# 挂机列表
afklist={}

# 计时器列表
timerlist=[]

# JSON数据共享
wwws='uwu'

# 是否为AI画图模式
uwumod=False

# 是否为uwu模式
uwuwu=False

# 翻译姬小姐
translator=googletrans.Translator()


def chatas(trip,nick,color,text):
	return json.dumps({"cmd":"chatas","trip":trip,"nick":nick,"color":color,"text":str(text)})

def whisper(nick,text):
	return json.dumps({"cmd":'whisper',"nick":nick,"text":f">\n{str(text)}"})

def send(chatroom,text,lang="zh"):
	if lang.lower() not in ["zh","zh-cn","zh-tw"]:
		try:
			text=(translator.translate(text,dest='en').text).replace("EB","eb")
			
			if uwuwu==True:
				text=uwuify.uwu(text,flags=uwuify.SMILEY|uwuify.YU).replace("EB","eb")
			
		except:
			pass
		
	if chatroom==tc:
		return json.dumps({"cmd":"chatas","trip":'44FF00',"nick":'eebot',"color":'44FF00',"text":str(text)})

	else:
		return json.dumps({'cmd':'chat','text':str(text)})

def send_(chatroom,text):
	if chatroom==tc:
		return json.dumps({"cmd":"chatas","trip":'',"nick":'*',"color":'',"text":str(text)})

	else:
		return json.dumps({'cmd':'chat','text':str(text)})

def retext(text):
	return text.replace('“','').replace('”','').replace('"','').replace('，',' ').replace('。',' ').strip()

def retext_(nick,text):
	return text.replace('你好','&#x4F60;好').replace('好你','好&#x4F60;').replace('我们',f"{nick}和eb").replace('你们',nick).replace('我','eb').replace('你',nick)

def retext__(text):
	return text.replace(' ','').replace('！','').replace('？','').replace('、','').replace('（','').replace('）','')

def timer(ws,t_time,nick,text):
	time.sleep(t_time)

	if nick in timerlist:
		time_=divmod(t_time,60)
		time__=divmod(time_[0],60)
		
		awa=time__[0]
		uwu=time__[1]
		ovo=time_[1]

		if text==None:
			ws.send(send(room1,f"@{nick} {awa}h {uwu}m {ovo}s倒计时已结束\n[{awa}h {uwu}m {ovo}s has ended]"))

		else:
			ws.send(send(room1,f"@{nick} 已经过去{awa}h {uwu}m {ovo}s了 快去{text}\n[{awa}h {uwu}m {ovo}s has passed]"))

			if nick not in afklist:
				time.sleep(1)
				ws.send(send(room1,f"{nick} is now {text}"))
				afklist[nick]=text

		del timerlist[timerlist.index(nick)]

	# 结束进程
	sys.exit(0)


# 表示开始
print(f"[Started] {time.strftime('%Y.%m.%d %H:%M:%S',time.localtime())}")


def replay(ws,channel,file,mod,speed):
	global wwws

	# bot名字
	botname=str(random.randint(1,999)).zfill(3)

	try:
		# 连接聊天室
		wwws=websocket.WebSocket()
		wwws.connect(ws_tc)
		ws.send(send(room1,f"Success =>\n[https://tanchat.fun/?{channel}](https://tanchat.fun/?{channel})"))
	
	except:
		ws.send(send(room1,f"Failure =>\n[https://tanchat.fun/?{channel}](https://tanchat.fun/?{channel})"))
		sys.exit(0)

	# 加入聊天室
	wwws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botrip}))
	time.sleep(1)
	wwws.send(json.dumps({'cmd':'changecolor','color':'212121'}))
	print(f"[replay] {ws_tc}/{channel}")

	content_=[]

	if mod==1:
		try:
			content=codecs.open(f"[video]/{file}","r","UTF-8-sig").readlines()

			for word in content:
				content_.append(word.replace('[',"",1).replace(']'," ",1).strip("\n"))

		except:
			ws.send(send_(room1,f"{file} not found"))

	elif mod==2:
		try:
			content=codecs.open(f"[video]/{file}","r","UTF-8-sig").read()
			re_=re.findall(r"\[(\d{2}:\d{2}:\d{2})\]",content)

		except:
			ws.send(send_(room1,f"{file} not found"))

		for time_ in re_:
			try:
				split_=content.split(f"[{time_}]",1)
				notrip=split_[0].split("] ",1)[1].split("\n",1)
				content_.append(f"{time_} {notrip[0]} {notrip[1]}".strip("\n"))
				content=split_[1]

			except:
				pass

	wwws.send(send_(tc,f"开始以{speed}倍速播放\n[Start playing {file[:-4]} at {speed}x speed]"))

	for uwu in content_:
		if True:
			msg=uwu.split(" ",mod)
			msg_=content_[content_.index(uwu)-1].split(" ",mod)
			mod_='%H:%M:%S'

			try:
				if uwu==content_[0]:
					time.sleep(1)

				else:
					if mod==1:
						mod_='%M:%S.%f'

					time_=datetime.datetime.strptime(msg[0],mod_)-datetime.datetime.strptime(msg_[0],mod_)
					time.sleep(int(time_.seconds)//speed)

				if mod==1:
					wwws.send(chatas('','','',msg[1]))

				elif mod==2:
					wwws.send(chatas('replay',msg[1],'',msg[2]))

			except:
				pass

	try:
		wwws.send(send_(tc,f"[Finished]"))
		wwws.close()
		sys.exit(0)

	except:
		pass


def chatroom1(socket,chatroom,channel):
	global wwws,uwuwu

	# bot名字
	botname=f"eebot_eb{str(random.randint(1,999)).zfill(3)}"

	try:
		# 连接聊天室
		ws=websocket.WebSocket()
		ws.connect(socket)
	
	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	# 加入聊天室
	ws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botrip}))
	time.sleep(1)
	ws.send(json.dumps({'cmd':'changecolor','color':'44FF00'}))
	time.sleep(1)
	ws.send(send(room1,"hihihi This is eebot uwu"))
	print(f"[Server1] {socket}/{channel}")
	
	def room1_1():

		# 自动叉叉
		uwu=True
		
		# 循环判定
		while True:
		
			# 保存文件的时间
			time__=time.strftime("%H:%M:%S",time.localtime())
			date__=time.strftime("%Y.%m.%d")
		
			try:
				# 接收到的json数据
				wss=json.loads(ws.recv())
		
			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)
		
			if "cmd" in wss:
				cmd=wss["cmd"]
		
				if cmd=="onlineAdd" and uwu==True:
					nick=wss["nick"]
					nick_=nick.lower()
					text=f"{nick} joined"
					bb=f"[{time__}]\n[None] *\n{text}"
					tsmit["1"]=["","*","",text,bb]
					
					if chatroom==hc:
						if "xc_" in nick_:
							ws.send(whisper("mbot",f"kick {nick}"))

					ws.send(send(room1,f"hi {nick}"))
		
				elif cmd=="onlineRemove":
					nick=wss["nick"]
					text=f"{nick} left"
					bb=f"[{time__}]\n[None] *\n{text}"
					tsmit["1"]=["","*","",text,bb]
		
				elif cmd=="chat":
					nick=wss["nick"]
					text=wss["text"]
					bb=''
					
					users.append(nick)
					
					if uwumod==True and nick!=botname and text[0]=="&":
						tsmit["3"]=text
		
					if nick!=botname and nick not in bots or nick==botname and text[0]=="|":
						if "\n" not in text and retext__(retext(text)).isalpha()==True:
							if 5<len(text)<=20:
								textlist.append(retext(text))

							# te长度为50时bot随机输出te内容
							if len(textlist)==50:
								text_=random.choice(textlist)
								ws.send(send(room1,retext_(nick,text_)))

							# te长度为100时bot复读一句话
							if len(textlist)==100:
								text_=retext(retext_(nick,text))
								meme=random.choice(umoji)
								ws.send(send(room1,random.choice([text_,meme])))
								textlist.clear()

							if len(textlist) in [40,60]:

								# api: PAPEREE
								url="http://217.114.47.63:5000/sbres"
								msg=retext_(nick,requests.get(url).text).replace('e—','ee').replace('c—',chatroom)

								if room1==tc:
									msg=f"eebot {msg[3:]}"

								textlist.append(msg)
								ws.send(send_(room1,msg))

						if text in umoji and random.randint(1,2)==1:
							ws.send(send_(room1,random.choice(umoji)))

						elif ("？" in text[-1] or "?" in text[-1]) and len(text)>2 and random.randint(1,int(len(text)))==1:
							msg=random.choice(["蛤","哦吼","阿瓦","阿巴阿巴"])
							ws.send(send_(room1,msg))

						# 如果是句号或省略号
						elif text=="|sbres" or (text[0] in ["…","。","、","，",".","a","e"] and text==text[0]*len(text)):

							# api: PAPEREE
							url="http://217.114.47.63:5000/sbres"
							msg=retext_(nick,requests.get(url).text).replace('e—','ee').replace('c—',chatroom)

							if room1==tc:
								msg=f"{nick} {msg[3:]}"
	
							ws.send(send_(room1,msg))

						elif text[0] in ["啊","哦","哈"] and text==text[0]*len(text) and random.randint(1,2)==1:
							msg=random.choice([f"{text}草",f"草{text}"])
							ws.send(send_(room1,msg))
								
						trip=''
						color=''

						if "trip" in wss and wss["trip"].strip()!='':
							trip=wss["trip"]
							bb=f"[{trip}] {nick}\n{text}"

							if trip in ["eYFDHl","love13","eeeEEm"]:

								if text=="|notes":
									note=os.listdir("[note]")
									note_='\n'.join(note)
									note__=len(note)
									ws.send(whisper(nick,note_))
									ws.send(send(room1,f"共有{note__}天留言记录\n[There are {note__}-day msg record]"))
							
								elif "|note" in text[:6]:
									text_=text[6:].strip()

									if text_=="":
										text_=date__

									try:
										note=codecs.open(f"[note]/{text_}_notebook.txt","r","UTF-8-sig").read()
										note_=len(note.split(f'@ee'))
										ws.send(whisper(nick,note))
										ws.send(send(room1,f"共有{note_}条留言\n[There are {note_} msg record]"))
											
									except:
										ws.send(send(room1,"笔记本是空的\n[The notebook is empty]"))
										
								elif text=="|openxx":
									uwu=True
									ws.send(send(room1,"叉出所有XC_开头的用户\n[Kick out all XChat users]"))
									
								elif text=="|closexx":
									uwu=False
									ws.send(send(room1,"自动叉叉关闭了\n[Automatic kick out was closed]"))
									
								elif text=="|openuwu":
									uwuwu=True
									ws.send(send(room1,"uwu"))
									
								elif text=="|openuwu":
									uwuwu=False
									ws.send(send(room1,"uwu"))
			
						else:
							bb=f"[None] {nick}\n{text}"
							
						if "color" in wss and wss["color"].strip()!='':
							color=wss["color"]
			
						try:
							tsmit["1"]=[trip,nick,color,text,bb]
							codecs.open(f"[chat]/[{chatroom}]/{date__}_{channel}.txt","a+","UTF-8-sig").write(f"[{time__}]\n{bb}\n\n")
			
						except:
							pass

						if "@eebot" in text or "@eb" in text or f"@{botname}" in text or (len(textlist) in [25,75] and text!=text[0]*len(text)):
							text_=text.lower().replace(botname,'').replace('eebot','').replace('eb','').replace('@','')
							
							try:
								test=translator.detect(text_).lang.lower()
								
							except:
								test="zh"
							
							if test not in ["zh","zh-cn","zh-tw"]:
								try:
									text_=translator.translate(text_,dest='zh-cn').text
									
								except:
									text_="uwu"
								
							textlist.append(text_)
							text__=retext__(retext(text_.replace(' ','')))

							# 用户自定义对话
							QAQ=os.listdir("[eebot]")

							time_=random.randint(1,5)
							time.sleep(time_/10)

							# 如果@的后面为空
							if text_=="":
								ws.send(send(room1,random.choice([f"{nick}有事吗",f"欢迎来{chatroom}聊天",f"找ee去吧",f"好耶 是{nick}"]),test))

							# 用户自定义输出
							elif f"{text__}.txt" in QAQ:
								try:
									file=codecs.open(f"[eebot]/{text__}.txt","r","GBK").read()
									ws.send(send(room1,retext_(nick,retext(file))))

								except:
									try:
										file=codecs.open(f"[eebot]/{text__}.txt","r","UTF-8-sig").read()
										ws.send(send(room1,retext_(nick,retext(file))))
										
									except:
										ws.send(send(room1,"含有无法识别的字符\n[Contains unrecognized characters]"))
									
							elif ("谁" in text or "人" in text_) and "话" in text and "最多" in text:
								ws.send(send(room1,max(set(users),key=users.count),test))
									
							elif ("谁" in text or "人" in text_) and "话" in text and "最少" in text:
								ws.send(send(room1,min(set(users),key=users.count),test))
									
							elif ("谁" in text or "人" in text_) and ("昵称" in text or "名" in text) and "最长" in text:
								ws.send(send(room1,max(set(users),key=len),test))
									
							elif ("谁" in text or "人" in text_) and ("昵称" in text or "名" in text) and "最短" in text:
								ws.send(send(room1,min(set(users),key=len),test))

							elif "介绍" in text_ and ("自己" in text_ or "你" in text_):
								ws.send(send(room1,f"这里是eebot 制作者是ee\n——永远保持可爱与活力！{nick}也要天天快乐",test))

							elif "好" in text_ and "吧" in text_:
								ws.send(send(room1,random.choice(["那不就没问题了嘛（","这就对了","嗯嗯"]),test))

							elif "好" in text_ and "不" in text_:
								ws.send(send(room1,random.choice([f"靠在{nick}身边）","啊哈",f"（歪着头看{nick}）"]),test))

							elif "好" in text_ and ("看" in text_ or "康" in text_):
								ws.send(send(room1,random.choice([f"eb觉得不错呀","哇哦"]),test))

							elif "你" in text_ and "是" in text_ and ("妈" in text_ or "娘" in text_ or "麻" in text_):
								ws.send(send(room1,random.choice([f"eb是ee的女儿",f"eb的亲妈是ee 亲爹也是ee"]),test))

							elif "你" in text_ and "是" in text_ and ("爸" in text_ or "爹" in text_ or "粑" in text_):
								ws.send(send(room1,random.choice(["这个呀 也许只有妈吗哦",f"eb是ee的女儿"]),test))

							elif "你" in text_ and "是" in text_ and ("哥" in text_ or "弟" in text_ or "姐" in text_ or "妹" in text_):
								ws.send(send(room1,random.choice(["bot都是兄弟姐妹",f"eb是独生女",f"eb也想要有"]),test))

							elif "你" in text_ and "是" in text_ and ("爷" in text_ or "奶" in text_):
								ws.send(send(room1,random.choice([f"eb只记得有妈妈",f"eb也可以有吗？",f"{nick}想当吗？"]),test))

							elif "你" in text_ and ("对象" in text_ or "老公" in text_ or "老婆" in text_ or "男朋友" in text_ or "女朋友" in text_ or "男票" in text_ or "女票" in text_):
								ws.send(send(room1,random.choice([f"是mark哒~",f"eb还小 但已经和mark在一起了",f"uwu 好喜欢mark"]),test))

							elif "你" in text_ and "朋友" in text_:
								ws.send(send(room1,random.choice([f"{nick}在和eb聊天 那么我们就是朋友啦",f"{nick}是eb的朋友"]),test))

							elif "你" in text_ and "是" in text_ and ("女的" in text_ or "女生" in text_ or "女孩" in text_ or "女性" in text_ or "女士" in text_):
								ws.send(send(room1,random.choice(["毫无疑问是呢~",f"{nick}觉得eb可爱吗？","是的！"]),test))

							elif "你" in text_ and "是" in text_ and ("男的" in text_ or "男生" in text_ or "男孩" in text_ or "男性" in text_ or "男士" in text_):
								ws.send(send(room1,random.choice(["NONO 是女孩子哟",f"不是哦",f"虽然不是 但{nick}认为是就是啦"]),test))

							elif "你" in text_ and ("爱好" in text_ or "喜欢" in text_ and "事" in text_):
								ws.send(send(room1,"uwu 吹电风扇 和CPU搞好关系（指CPU因为过于激动而发烫） 有些时候会抽烟（尤其是低配电脑）",test))

							elif ("你在干" in text_ or "你在做" in text_) and ("什么" in text_ or "啥" in text_ or "嘛" in text_):
								ws.send(send(room1,random.choice([f"eb在想{nick}",f"eb在和{nick}聊天呢","啊？当然是在看守聊天室呢"]),test))

							elif "想什么" in text_ or "想啥" in text_:
								ws.send(send(room1,random.choice([f"想{nick}不行嘛","没什么啦-"]),test))

							elif "涩涩" in text_ or "色色" in text_:
								ws.send(send(room1,f"uwu eb只想和mark涩涩",test))

							elif "你" in text_ and "讨厌" in text_:
								ws.send(send(room1,"啊 谁都不讨厌",test))

							elif "没" in text_ and "人" in text_:
								ws.send(send(room1,random.choice([f"不 还有eb",f"有eb在呢"]),test))

							elif "绿" in text_ or "4f0" in text_ or "44ff00" in text_:
								ws.send(send(room1,random.choice(["ww绿！",f"这是最棒的颜色","大自然之荧光绿"]),test))

							elif "可怕" in text_ or "吓人" in text_ or "害怕" in text_:
								ws.send(send(room1,random.choice(["（摸摸）","富强民主文明和谐……","社会主义核心价值观"]),test))

							elif "胶水" in text_ or "glue" in text_ or "jill" in text_:
								ws.send(send(room1,random.choice([f"eb来派发jill glue了",f"一天一胶水~{nick}远离人世间"]),test))

							elif "加油" in text_ or "努力" in text_:
								ws.send(send(room1,random.choice([f"{nick}也加油","加油吧！少年","向着那明日的朝阳前进吧","鼓起勇气 迈向未来"]),test))

							elif "复读机" in text_:
								ws.send(send(room1,random.choice(["才不是复读机啦！",f"哼哼 不仅bot是 {nick}也是（","果然人类的本质都是复读机"]),test))

							elif "柠檬" in text_ or "酸了" in text_:
								ws.send(send(room1,random.choice(["柠檬树下柠檬果",f"柠檬树下{nick}和eb","（托腮.jpg）"]),test))

							elif "延迟" in text_ or "反应" in text_ and "慢" in text_:
								ws.send(send(room1,random.choice([f"这不是eb的错","因为代码太长了）",f"ee还在研究多线程"]),test))

							elif ("fish" in text_ or "鱼" in text_) and ("能不能" in text_ or "可不可以" in text_) and "吃" in text_:
								ws.send(send(room1,random.choice(["好耶好耶 eb现在就吃鱼",f"{nick}也喜欢吃鱼吗","快看！有一条肥肥的西瓜鱼"]),test))

							elif ("fish" in text_ or "鱼" in text_) and "不" in text_ and ("能" in text_ or "可以" in text_) and "吃" in text_:
								ws.send(send(room1,random.choice(["鱼那么好吃为什么不吃鱼 QAQ",f"如果{nick}也喜欢那我们就是朋友","eb不同意！"]),test))

							elif ("fish" in text_ or "鱼" in text_) and ("能" in text_ or "可以" in text_) and "吃" in text_:
								ws.send(send(room1,random.choice(["eb赞同","鱼的价值在于烹饪","芜湖！今晚吃鱼汤拉面"]),test))

							elif "吃" in text_ and ("fish" in text_ or "鱼" in text_):
								ws.send(send(room1,random.choice(["好耶好耶 eb现在就吃鱼",f"{nick}也喜欢吃鱼吗","快看！有一条肥肥的西瓜鱼"]),test))

							elif text_ in ["你好","大家好"]:
								ws.send(send(room1,random.choice([f"欢迎来到?{channel}",f"欢迎来到{chatroom}","你好你好","ooooy ih"]),test))

							elif text_ in ["机器人","bot"]:
								ws.send(send(room1,random.choice(["eebot是bot","@fOoLishbIrD ","@Wcy_Bot ","@zzChumo "]),test))

							elif text_ in ["纸片君ee","纸片君","ee"]:
								ws.send(send(room1,random.choice([f"eb的监护人 {nick}的朋友","eb的制作者","找eb的母亲大人有事吗"]),test))

							elif text_ in ["eb是谁","eebot是谁"]:
								ws.send(send(room1,"是我啦（",test))
								
							elif text_ in umoji:
								ws.send(send(room1,random.choice(umoji)))

							elif text_.replace('#','')==["4f0","44ff00"]:
								ws.send(send(room1,random.choice([f"哇塞 这是eb的颜色",f"这是最棒的颜色","猜猜这个颜色有什么意义"]),test))

							elif text_=="ee":
								ws.send(send(room1,"ee是eb的监护人",test))

							elif text_=="mark":
								ws.send(send(room1,"eb的男朋友",test))

							elif text_=="foolishbird":
								ws.send(send(room1,"傻鸟！是eb的好朋友",test))

							else:
								try:
									url="http://api.ruyi.ai/v1/message"
									data={"q":text_,"user_id":nick,"app_key":"5a41a62c-1696-4aac-9f45-9166cc581143"}
									json_=requests.get(url,data).json()
									msg=json_["result"]["intents"][0]["result"]["text"]
									
									if msg in [text,text_,text__]:
										ws.send(send(room1,random.choice(umoji)))

									elif len(msg)>18 or "[" in msg and "]" in msg or "小写" in msg or "大写" in msg or "什么意思" in msg or "说详细点" in msg or "说明白点" in msg or "听不太懂" in msg or "不想回答" in msg:
										if len(textlist)!=0:
											msg_=random.choice(textlist)
											ws.send(send(room1,retext_(nick,msg_),test))

										else:
											ws.send(send(room1,f"{nick}不能欺负eb",test))

									else:
										msg_=retext(retext_(nick,msg)).replace('&name','eebot').replace('&adj','可爱').replace('小朋友',nick).replace('小主人',nick).replace('主人',nick).replace('宝贝',nick).replace('啥','什么').replace('咋','怎么').replace('嘻','哈')

										# 如果字符串的长度为偶数
										if msg_!='' and '\u4e00'<=msg_[-1]<='\u9fff' and (len(msg_)%2)==0:
											ws.send(send(room1,msg_+random.choice(['（','）','（）']),test))

										else:
											ws.send(send(room1,msg_,test))

								except:
									ws.send(send(room1,random.choice(["eb不干（","uw……这可不在服务范围内（",f"{nick}自己来吧 有手就行","awa 才不要呢","？",f"{nick}认为鱼好吃吗","芜湖","好耶",f"{nick}觉得呢？","此地有鱼 其名为李桂鱼","烹饪鱼需要两个烧烤架~"]),test))

						elif text[:5]=="|ques":
							text_=text[5:]
							
							if str(text).count("\n")>=1:
								QAQ=os.listdir("[eebot]")
								QAQ_=text_.split('\n',1)
								Q=QAQ_[0].replace(' ','').strip('\n').lower()
								A=QAQ_[1].replace('，',' ')

								# 设置为空时无效
								if "" in [Q,A]:
									ws.send(send(room1,"不能留空\n[Dont leave blank]"))

								elif "$" in text:
									ws.send(send(room1,"不能用LaTeX\n[Cant use LaTeX]"))

								else:
									try:
										file=codecs.open(f"[eebot]/{Q}.txt","w","GBK")
										file.write(A)
										file.close()

										if f"{Q}.txt" in QAQ:
											ws.send(send(room1,"已重新设置这个问题的回答\n[The answer to this question has been reset]"))

										else:
											# 如果是第一次设置这个问题
											ws.send(send(room1,"记住要这么回答了\n[Now remember this question]"))

									except:
										ws.send(send(room1,"含有无法识别的字符\n[Contains unrecognized characters]"))

							else:
								ws.send(send(room1,"第一行是问题 从第二行开始是回答\n[The first line is the question and the second line is the answer]"))


						elif text[:5]=="|help":
							text_=text[5:].strip()
							user="@eebot => 聊天\n|ques <问题> <换行> <回答> => 定义对话\n·\n|help => 帮助\n|msg <内容> => 给ee留言\n·\n|sbres => SB句子\n·\n|rgb <红> <绿> <蓝> or <16进制颜色> => 颜色转换\n|face <链接> => 人脸检测\n|timer <时长(/s)> <内容> => 计时器\n·\n|cloud => 词云\n|chat => 聊天记录\n·\n|videos => 所有录像\n|play <频道> <文件> <模式> <速度(/X)> => 播放\n|unplay => 停播\n·\n|afk <状态> => 挂机\n|afklist => 挂机列表\n·\nTry \"|help en\" if u cant understand the above"
							mod="|notes => 所有留言 *Mod\n|note <日期> => 查看留言 *Mod\n·\n|openxx => 叉叉 *Mod\n|closexx => 关闭叉叉 *Mod"
							
							if text_=="en":
								user="@eebot => Chat\n|ques <Question> <Linefeed> <Reply> => Conversation content\n·\n|help => Help\n|msg <Content> => Leave msg for ee\n·\n|sbres => SB sentence\n·\n|rgb <Red> <Green> <Blue> or <Hexadecimal color> => Color conversion\n|face <URL> => Face detection\n|timer <Duration(/s)> <Content> => Timer\n·\n|cloud => Wordcloud\n|chat => Chat history\n·\n|videos => All videos\n|play <Channel> <File> <Model> <Speed(/X)> => Play\n|unplay => Stop\n·\n|afk <Condition> => AFK\n|afklist => AFK list\n·\n如果看不懂上面的内容就用\"|help zh\""
								mod="|notes => All messages *Mod\n|note <Date> => Check messages *Mod\n·\n|openxx => Auto Kick *Mod\n|closexx => Close auto *Mod"
								
							if text_ in ['','zh','en']:
								ws.send(send(room1,user))
			
						elif text[:4]=="|msg":
							if text.strip()=="|msg":
								ws.send(send(room1,f"如果eb的监护人没及时回复就是在上学（周一到周五）\n所有|msg <内容>或私聊{botname}的消息都会单独保存到笔记本\n有什么事就和eb说吧 ee周末会看的 uwu\n如果某天eb掉线了 那就是服务器炸了\n·\n[This passage means that u can leave msg for the author of this bot]"))
								
							else:
								ws.send(send(room1,f"已经把留言塞到笔记本里了\n[The msg was stuffed into the notebook]"))

							codecs.open(f"[note]/{date__}_notebook.txt","a+","UTF-8-sig").write(f"[{time__}]\n{bb}\n\n")

						if text[:4] == "|rgb":
							try:
								text_=text.split(' ',1)[-1]
								text__=text_.split()
								letter=['A','B','C','D','E','F','0','1','2','3','4','5''6','7','8','9']
								letter_=[]
							
								if text_[0]=="#" or " " not in text_.strip():
									text_=text_.replace("#","")

									for word in text_:
										if word.upper() not in letter:
											letter_.append(word)

									if len(letter_)!=0:
										ws.send(send(room1,"没有这个16进制颜色\n[This hexadecimal color does not exist]"))

									elif len(text_)==3:
										s1=int('0x'+text_[0]*2,16)
										s2=int('0x'+text_[1]*2,16)
										s3=int('0x'+text_[2]*2,16)
										ws.send(send(room1,f"{s1} {s2} {s3}"))

									elif len(text_)==6:
										s1=int('0x'+text_[:2],16)
										s2=int('0x'+text_[2:4],16)
										s3=int('0x'+text_[4:6],16)
										ws.send(send(room1,f"{s1} {s2} {s3}"))

									else:
										ws.send(send(room1,"错误的颜色长度\n[Wrong color length]"))

								elif len(text__)==3:
									for word in text__:
										if word.isnumeric()==False or int(word)>255:
											letter_.append(word)

									if len(letter_)!=0:
										ws.send(send(room1,"没有这个RGB颜色\n[This RGB color does not exist]"))

									else:
										l1=text__[0]
										l2=text__[1]
										l3=text__[2]
										s1=hex(int(l1))[2:].upper().rjust(2,'0')
										s2=hex(int(l2))[2:].upper().rjust(2,'0')
										s3=hex(int(l3))[2:].upper().rjust(2,'0')
										ws.send(send(room1,f"#{s1}{s2}{s3}"))

								else:
									ws.send(send(room1,"这个颜色不存在吧\n[This is not the color]"))
										
							except:
								ws.send(send(room1,f"Try: |rgb <红(Red)> <绿(Green)> <蓝(Blue)> or <16进制颜色(Hexadecimal color)>"))
							
						elif text[:5]=="|face":
							try:
								file=text.split(' ',1)[1]
								header={"User-Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0"}
								
								if "http" in text:
									try:
										sb=urllib.request.urlopen(urllib.request.Request(file,headers=header)).read()
										file=f"[temp]/{str(random.randint(1,114514)).zfill(6)}.{file.split('.')[-1]}"
										codecs.open(file,"wb").write(sb)
							
									except Exception as ee:
										ws.send(send(room1,f"Failure =>\n{ee}"))

								try:
									opencv_=opencv.face(file)
									ws.send(send(room1,sm_ms.upload(file)))
									ws.send(send(room1,f"Success =>\n{opencv_}"))
							
								except Exception as ee:
									ws.send(send(room1,f"Failure =>\n{ee}"))

							except:
								ws.send(send(room1,"Try: |face <链接(URL)>"))
							
						elif text=="|cloud":
							try:
								wc=word_cloud.cloud(users)
								wc_=sm_ms.upload(wc)
								ws.send(send(room1,f"Success =>\n[{wc_}]({wc_})"))
							
							except Exception as ee:
								ws.send(send(room1,f"Failure =>\n{ee}"))
								
						elif text=="|chat":
							try:
								msg=codecs.open(f"[chat]/[{chatroom}]/{date__}_{channel}.txt","r","UTF-8-sig").read()
								url="https://www.showdoc.cc/server/api/item/updateByApi"
								data={"api_key":"81d9142e76be59ba872aa59ba83db27b220053181","api_token":"cd63087778f4f9fbc136a0de742c5f1e1643555733","cat_name":chatroom,"page_title":f"{date__}_{channel}","page_content":msg}
								json_=requests.post(url,data=data).json()
								result=f"https://www.showdoc.com.cn/page/{json_['data']['page_id']}"
								ws.send(send(room1,f"Success =>\n[{result}]({result})"))
							
							except Exception as ee:
								ws.send(send(room1,f"Failure =>\n{ee}"))

						elif text[:6]=="|timer":
							apart=text.split(' ',2)
							text_=''
							text__=''

							# 判断是否多开
							if nick in timerlist:
								ws.send(send(room1,f"不许多开计时器\n[Dont start too many timers]"))

							else:
								if len(apart)==1:
									text_='60'
									text__=None
									
								elif len(apart)==2:
									text_=apart[1]
									text__=None
									
								else:
									text_=apart[1]
									text__=apart[2]
									
								if text_.isnumeric()==False:
									ws.send(send(room1,"无效的时长\n[Invalid duration]"))

								elif int(text_)>3600:
									ws.send(send(room1,"计时不能大于3600s\n[Cant exceed 3600s]"))

								else:
									threading.Thread(target=timer,args=(ws,int(text_),nick,text__)).start()
									ws.send(send(room1,f"好的好 到时会提醒{nick}的\n[OK eb will remind {nick} then]"))
									timerlist.append(nick)

						elif text=="|videos":
							video=os.listdir("[video]")
							video_='\n'.join(video)
							video__=len(video)
							ws.send(whisper(nick,video_))
							ws.send(send(room1,f"共有{video__}个录像带\n[There are {video__} video tapes]"))

						elif text[:5]=="|play":
							try:
								text_=text.lower().split(' ',4)
								threading.Thread(target=replay,args=(ws,text_[1],text_[2],int(text_[3]),int(text_[4]))).start()

							except:
								ws.send(send(room1,"Try: |play <频道(Channel)> <文件(File)> <模式(Model)> <速度(Speed)>"))
									
						elif text=="|unplay":
							try:
								ws.send(send(room1,"播放器终止了\n[The player terminated]"))
								wwws.send(chatas('','*','','播放器终止了\n[The player terminated]'))
								wwws.close()

							except:
								ws.send(send(room1,"没有正在播放的录像带\n[There is no video tape being played]"))

						if nick in afklist:
							afk=afklist[nick]
							del afklist[nick]
							ws.send(send_(room1,f"{nick} is not {afk} now"))

						if text=="|afklist":
							if len(afklist)==0:
								ws.send(send_(room1,"No one afk"))

							else:
								list_=[]

								for nick in afklist:
									afk=afklist[nick]
									list_.append(f"{nick}: {afk}")

								join_=',\n'.join(list_)
								len_=len(list_)
								ws.send(send_(room1,f"Success => {len_}\n[{join_}]"))

						if text[:4]=="|afk":
							if text=="|afk":
								ws.send(send_(room1,f"{nick} is now afk"))
								afklist[nick]="afk"

							elif text[4]==' ':
								text_=text[5:]
								ws.send(send_(room1,f"{nick} is now {text_}"))
								afklist[nick]=text_

				elif cmd=="info" and wss.get("type")=="whisper":
					if "from" in wss:
						nick=str(wss["from"])
						text=wss["text"].replace(":","：",1)
						text_=text[text.find("：")+1:]

						if nick!=botname and nick not in bots:
							tsmit["1"]=["44FF00","eebot","44FF00",text,bb]

							if "whispered" not in text_:
								codecs.open(f"[note]/{date__}_notebook.txt","a+","UTF-8-sig").write(f"[{time__}]\n[{nick}]\n{text_}\n\n")
	
			time.sleep(0.2)

	def room1_2():
		
		# 循环判定
		while True:
				
			if "2" in tsmit:
				try:
					ws.send(send(room1,tsmit["2"]))
					del tsmit["2"]
					
				except:
					pass
	
			else:
				time.sleep(0.2)
			
	threading.Thread(target=room1_1).start()
	time.sleep(1)
	threading.Thread(target=room1_2).start()


def chatroom2(socket,chatroom,channel):

	# bot名字
	botname=str(random.randint(1,999)).zfill(3)

	try:
		# 连接聊天室
		wws=websocket.WebSocket()
		wws.connect(socket)
	
	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	# 加入聊天室
	if chatroom==tc:
		wws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botrip}))
		
	else:
		wws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname}))
		
	time.sleep(1)
	wws.send(json.dumps({'cmd':'changecolor','color':'212121'}))
	print(f"[Server2] {socket}/{channel}")
	
	def room2_1():
	
		# 循环判定
		while True:
			try:
				# 接收到的json数据
				wwss=json.loads(wws.recv())
		
			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)
		
			if "cmd" in wwss:
				cmd=wwss["cmd"]
		
				if cmd=="chat":
					nick=wwss["nick"]
					text=wwss["text"]
					
					try:
						if uwumod==True:
							if nick!=botname and f"@{botname}" in text:
								tsmit["2"]=text[len(botname)+1:]
								
						elif nick!=botname and "trip" in wwss and wwss["trip"] in ["eYFDHl","love13"] and text[0]=="|":
							tsmit["2"]=text[1:]
							
					except:
						pass
		
			time.sleep(0.2)

	def room2_2():
		
		# 循环判定
		while True:
			try:
		
				# 判断模式
				if uwumod==True:
					if "3" in tsmit:
						wws.send(send(room2,tsmit["3"]))
								
						del tsmit["3"]
				
				elif "1" in tsmit:
					pipe=tsmit["1"]
							
					if chatroom==tc:
						wws.send(chatas(pipe[0],pipe[1],pipe[2],pipe[3]))
								
					else:
						wws.send(send(room2,pipe[4]))
							
					del tsmit["1"]
							
			except:
				pass
					
			else:
				time.sleep(0.2)
			
	threading.Thread(target=room2_1).start()
	time.sleep(1)
	threading.Thread(target=room2_2).start()


# 同时启动两个聊天室
threading.Thread(target=chatroom1,args=(ww1,room1,chan1)).start()
time.sleep(3)
threading.Thread(target=chatroom2,args=(ww2,room2,chan2)).start()
