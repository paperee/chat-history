import cv2

def face(image):
	
	# 读取图片文件
	src=cv2.imread(image)
	
	# 转成灰度图像
	gray=cv2.cvtColor(src,cv2.COLOR_BGR2GRAY)
	
	# 创建一个级联分类器 加载一个.xml分类器文件 它既可以是Haar特征也可以是LBP特征的分类器
	face_detecter=cv2.CascadeClassifier('207bb2305d711a834168f9952adeee06_venv/lib/python3.9/site-packages/cv2/data/haarcascade_frontalface_default.xml')
	
	# 多个尺度空间进行人脸检测 返回检测到的人脸区域坐标信息
	faces=face_detecter.detectMultiScale(image=gray,scaleFactor=1.1,minNeighbors=5)
	
	# 在原图像上绘制矩形标识
	for x,y,w,h in faces:
		cv2.rectangle(img=src,pt1=(x,y),pt2=(x+w,y+h),color=(68,255,0),thickness=2)
		
	cv2.imwrite(image,src,[int(cv2.IMWRITE_PNG_COMPRESSION),0])
	cv2.waitKey(0)
	cv2.destroyAllWindows()
	
	return str(faces)