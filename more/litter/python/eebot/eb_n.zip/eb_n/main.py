import websocket
import requests
import json
import time
import random
import calendar
import re
import threading
from langconv import *


def sendd(text):

	# text:发送的内容
	head = "https://s1.ax1x.com/2022/03/27/qw2gkn.png"
	return json.dumps({"cmd":"chat","text":str(text),"head":head})


class runbox:
	def __init__(self,room,name,pas):

		# 包含了频道、bot名称、bot密码
		self.room = room
		self.name = name
		self.pas = pas

		# 记录join成员
		self.join = []

		# 写入短文本
		self.text = []

		# 推荐列表
		self.wuhu = []
		self.site = []

		# afk人员清单
		self.afk = []

		# 游戏数据及游戏成员
		self.game = []
		self.play = []
		self.by = []

		# 真心话开关
		self.true = False

		# 飞花令开关
		self.flower = False

		# 词语接龙开关
		self.word = False

		# 故事制造机开关
		self.story = False

		# 某纸片的图开关（雾
		self.pic = False
	

	def handle(self,json_data):

		# 将对应的cmd类型和对应的函数结合
		self.data = json_data
		td = self.data

		# 如果接受到了包含cmd的json数据
		if "cmd" in td:

			# 发送文本类型
			if td["cmd"] == "chat":
				self.chat()

			# 用户进入类型
			elif td["cmd"] == "onlineAdd":
				self.onlineadd()

			# 用户离开类型
			elif td["cmd"] == "onlineRemove":
				self.onlineremove()

			# 进入聊天时用户的列表
			elif td["cmd"] == "onlineSet":
				self.onlineset()

			# 服务器错误日志
			elif td["cmd"] == "warn":
				self.warn()

			# 进入聊天时用户的列表
			elif td["cmd"] == "info" and td.get("type") == "whisper":
				self.whisper()


	def chat(self):

		# 缩写列表
		jo = self.join
		te = self.text
		wu = self.wuhu
		si = self.site
		pl = self.play
		ga = self.game
		af = self.afk
		by = self.by
		name = self.name
		room = self.room
		text = self.data["text"]
		nick = self.data["nick"]
		leve = self.data["level"]


		# 随机等待时间
		zz = random.choice([0.15,0.2,0.25])
		ee = random.choice([0.45,0.5,0.55])


		# bot私聊
		n = "\n"
		nn = "·\n"
		per = "/w {} .".format(nick) + n + nn


		# 保存聊天记录的文件名及路径
		chat = time.strftime("%Y.%m.%d")
		nel = "chats/" + room + "/" + chat + ".txt"
		nell = "chats/" + chat + " " + room + ".txt"
		hc = time.strftime("%H:%M:%S ",time.localtime())
		ms = hc + nick + n + text + n*2


		# 用于排除bot昵称
		with open("record/name.txt","r") as fp:
			bot = fp.readlines()
			bot.append(name + n)


		# 随机表情
		with open("record/meme.txt","r") as fp:
			me = fp.readlines()
			meme = random.choice(me)


		# 查找相关文件夹是否存在
		with open("record/channel.txt","r") as fp:
			chan = fp.readlines()

			# 按日期和频道写入消息和发送时间
			if room + n in chan:
				with open(nel,"a+") as fp:
					fp.write(ms)

			else:
				with open(nell,"a+") as fp:
					fp.write(ms)


		# 自动清空text
		with open("record/text.txt","r+") as fp:
			ex = fp.readlines()
			if len(ex) == 30:
				fp.truncate(0)


		# 当wu中的数据为10
		if len(wu) == 10:

			# 自动清空wu
			time.sleep(ee)
			ws.send(sendd("已自动清空推荐记录"))
			wu.clear()
	

		# 当si中的数据为10
		if len(si) == 10:

			# 自动清空si
			time.sleep(ee)
			ws.send(sendd("已自动清空随机记录"))
			si.clear()


		# 为防止刷屏而屏蔽bot昵称
		if nick + n not in bot:

			# 如果成员第一次打招呼
			if text in ["hello","hi","hey","hi yo","hey yo"] and nick not in jo:
				a = "hello {}".format(nick)
				b = "hi {}".format(nick)
				c = "hey {}".format(nick)
				d = "hi yo {}".format(nick)
				e = "hey yo {}".format(nick)
				f = "{}!".format(nick)

				# bot打招呼
				time.sleep(zz)
				ws.send(sendd(random.choice([a,b,c,d,f])))

				# 保存昵称到jo
				jo.append(nick)


			if room == "xq102210":
				if text[:4] == "ban-":
					if leve >= 999999:
						if text[4:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							if text[4] == "@" and text[5:] != "":
								a = str(text[5:]).replace(' ','')
								ws.send(json.dumps({"cmd":"ban","nick":a}))

							else:
								ws.send(sendd("请输入带@的昵称"))

					else:
						ws.send(sendd("没有足够的权限"))


				if text[:5] == "dumb-":
					if leve >= 999999:
						if text[5:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							if text[5] == "@" and text[6:] != "":
								a = str(text[6:]).replace(' ','')
								ws.send(json.dumps({"cmd":"dumb","nick":a}))

							else:
								ws.send(sendd("请输入带@的昵称"))

					else:
						ws.send(sendd("没有足够的权限"))


				if text[:5] == "kick-":
					if leve >= 999999:
						if text[5:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							if text[5] == "@" and text[6:] != "":
								a = str(text[6:]).replace(' ','')
								ws.send(json.dumps({"cmd":"kick","nick":a}))

							else:
								ws.send(sendd("请输入带@的昵称"))

					else:
						ws.send(sendd("没有足够的权限"))


				if text[:5] == "kill-":
					if leve >= 999999:
						if text[5:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							if text[5] == "@" and text[6:] != "":
								a = str(text[6:]).replace(' ','')
								ws.send(json.dumps({"cmd":"kick","nick":a}))

							else:
								ws.send(sendd("请输入带@的昵称"))

					else:
						ws.send(sendd("没有足够的权限"))


				if text[:6] == "limit-":
					if leve >= 999999:
						if text[6:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							a = str(text[6:]).replace(' ','')
							ws.send(json.dumps({"cmd":"kick","open":a}))

					else:
						ws.send(sendd("没有足够的权限"))


				if text[:9] == "moveuser-":
					if leve >= 999999:
						if text[9:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							if text[9] == "@" and text[10:] != "":
								a = str(text[10:]).replace(' ','')
								ws.send(json.dumps({"cmd":"moveuser","nick":a}))

							else:
								ws.send(sendd("请输入带@的昵称"))

					else:
						ws.send(sendd("没有足够的权限"))


				if text[:6] == "speak-":
					if leve >= 999999:
						if text[6:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							a = str(text[6:]).replace(' ','')
							ws.send(json.dumps({"cmd":"speak","ip/hash":a}))

					else:
						ws.send(sendd("没有足够的权限"))


				if text[:6] == "unban-":
					if leve >= 999999:
						if text[6:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							a = str(text[6:]).replace(' ','')
							ws.send(json.dumps({"cmd":"kick","ip/hash":a}))

					else:
						ws.send(sendd("没有足够的权限"))


				if text == "unbanall-":
					if leve >= 999999:
						ws.send(json.dumps({"cmd":"unbanall"}))

					else:
						ws.send(sendd("没有足够的权限"))


				if text[:7] == "unkill-":
					if leve >= 999999:
						if text[7:] == "":
							ws.send(sendd("请勿留空哦"))

						else:
							if text[7] == "@" and text[8:] != "":
								a = str(text[8:]).replace(' ','')
								ws.send(json.dumps({"cmd":"unkill","nick":a}))

							else:
								ws.send(sendd("请输入带@的昵称"))

					else:
						ws.send(sendd("没有足够的权限"))


				if text in ["xc"]:
					with open("record/xc.txt","r") as fp:
						xc = fp.read()
						ws.send(sendd(per + xc))


				if text in ["mod"]:
					with open("record/mod.txt","r") as fp:
						mo = fp.read()
						ws.send(sendd(per + mo))


			if text in ["机器人","bot"]:
				with open("record/bot.txt","r") as fp:
					bo = fp.read()
					ws.send(sendd(per + bo))


			if text in ["功能","order"]:
				with open("record/order.txt","r") as fp:
					er = fp.read()
					if room == "xq102210":
						a = "如果你想了解XChat：「xc」"
						b = "辅助管理使用方法：「mod」"
						ws.send(sendd(per + er + nn + a + n + b))

					else:
						ws.send(sendd(per + er))


			if text in ["帮助","help"]:
				with open("record/help.txt","r") as fp:
					he = fp.read()
					ws.send(sendd(per + he))


			if text in ["网站","web"]:
				with open("record/web.txt","r") as fp:
					we = fp.read()
					ws.send(sendd(per + we))


			if text in ["时间","time"]:

				# 获取计算机时间
				a = time.strftime("Time %a %Y.%m.%d %H:%M:%S",time.localtime())
				ws.send(sendd(a))


			if text in ["日历","cal"]:

				# 日历模块调用calendar库
				a = int(time.strftime("%Y"))
				b = int(time.strftime("%m"))
				cal = calendar.month(a,b).replace(' ','⠀').replace('⠀⠀',' ⠀')
				ws.send(sendd(per + cal))


			if text in ["农历","date"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/yinlongli?api_key=dd488292c6ea462a"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = "日：" + a["lunar"] + n + "年：" + a["yearZodiac"] + "（" + a["lunarYearName"] + "）"
				ws.send(sendd(per + word))


			if text in ["下载","eebot"]:

				# eebot的下载地址
				with open("record/eebot.txt","r") as fp:
					eb = fp.read()
					time.sleep(zz)
					ws.send(sendd(per + eb))


			if text in ["重置","clear"]:
				time.sleep(zz)

				# 如果wu和si中无数据
				if len(wu) == 0 and len(si) == 0:
					ws.send(sendd("当前无记录 不需要清空"))

				else:
					# 清空wu和si中的所有数据
					ws.send(sendd("已清空所有随机记录"))
					wu.clear()
					si.clear()


			# 如果昵称在af列表里
			if nick in af:

				# 排除以下消息
				if text not in ["挂机","afk","挂机列表","list"]:

					# 把昵称从af中移除
					a = "welcome back {}".format(nick)
					b = "{} is back".format(nick)
					time.sleep(zz)
					ws.send(sendd(random.choice([a,b])))
					del af[af.index(nick)]

				# 不能重复挂机
				elif text in ["挂机","afk"]:
					time.sleep(zz)
					ws.send(sendd("{} is already in afk list".format(nick)))


			# 如果昵称不在af列表里
			if nick not in af:

				# 将昵称加入af
				if text in ["挂机","afk"]:
					time.sleep(zz)
					ws.send(sendd("{} is now afk".format(nick)))
					af.append(nick)

					# 退出真心话游戏
					if self.true == True and nick in by:
						time.sleep(ee)
						ws.send(sendd("{}已离开真心话游戏".format(nick)))
						a = by.index(nick)
						del by[a]
						del pl[a]


			# 查看af列表
			if text in ["挂机列表","list"]:

				# 若af的长度为0
				if len(af) == 0:
					time.sleep(zz)
					ws.send(sendd("目前无人挂机 列表为空"))

				else:
					# 输出列表
					a = nn + "afk list:" + str(af).replace('[\'','').replace('\']','').replace('\'',' ')
					time.sleep(zz)
					ws.send(sendd(a))
	

			# 如果有人提到了挂机成员
			for name in af:

				# 提示该成员在afk状态
				if "@{}".format(name) in text:
					time.sleep(zz)
					ws.send(sendd("{} is now afk".format(name)))


			if text in ["欢迎语","wel"]:
				with open("record/wel.txt","r") as fp:
					el = fp.read()
					ws.send(sendd(per + el))


			if text in ["揭示板","cas"]:
				with open("record/date.txt","r") as fp:
					da = str(fp.readlines())
					date = da.replace('[\'','').replace('\']','').replace('\'',' ').replace('\\n','')
					with open("record/cas.txt","r") as fp:
						hc = fp.read()
						ws.send(sendd(per + hc + date))


			if text in ["留言板","ees"]:
				with open("record/ees.txt","r") as fp:
					ee = fp.read()
					ws.send(sendd(per + ee))


			if text in ["签到","dk"]:
				with open("record/deta.txt","r") as fp:
					de = str(fp.readlines())
					deta = de.replace('[\'','').replace('\']','').replace('\'',' ').replace('\\n','')
					with open("record/dk.txt","r") as fp:
						dk = fp.read()
						ws.send(sendd(per + dk + deta))


			if text in ["聊天","chat"]:
				a = "{}内接聊天功能~".format(name)
				b = "欢迎@{} 哦".format(name)
				time.sleep(zz)
				ws.send(sendd(per + a + n + b))


			if text in ["IP"]:
				a = "说明：查询IP地址的信息" + n + "使用方法：IP-IP地址"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["PING"]:
				a = "说明：PING某网站的域名（已挂）" + n + "使用方法：PING-域名"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["ICP"]:
				a = "说明：查询ICP备案记录" + n + "使用方法：ICP-域名"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["QQ"]:
				a = "说明：查询QQ号昵称" + n + "使用方法：QQ-QQ号"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["天气","city"]:
				a = "说明：获取当天的天气信息" + n + "使用方法：CITY-不带市的城市"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["百度","baidu"]:
				a = "说明：查询百度百科" + n + "使用方法：DU-词条名称"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["搜狗","sogo"]:
				a = "说明：查询搜狗百科" + n + "使用方法：SOGO-词条名称"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["翻译机","tran"]:
				a = "说明：在线翻译" + n + "使用方法：F-要翻译的句子"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["网易云","id"]:
				a = "说明：在线解析网易云音乐" + n + "使用方法：ID-歌曲ID"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["手机号","num"]:
				a = "说明：查询手机号的信息" + n + "使用方法：N-手机号"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["垃圾分类","waste"]:
				a = "说明：垃圾分类" + n + "使用方法：L-垃圾名"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["哔哩哔哩","bili"]:
				a = "说明：获取B站视频的标题简介等" + n + "使用方法：BI-视频BV号"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["满分作文","lolo"]:
				a = "说明：狗屁不通文章生成" + n + "使用方法：LO-主题关键词"
				time.sleep(zz)
				ws.send(sendd(per + a))


			if text in ["聊天室","room"]:
				with open("record/room.txt","r") as fp:
					h = fp.readlines()
					hh = random.choice(h).replace('\\n',n)

					# 内容在si的情况下
					if hh in si:
						ws.send(sendd("耶 就不告诉{}".format(nick)))

					else:
						# 直接发送h
						ws.send(sendd(per + hh))
						si.append(hh)


			if text in ["推荐","wuhu"]:
				with open("record/wuhu.txt","r") as fp:
					w = fp.readlines()
					ww = random.choice(w).replace('\\n',n)

					# wuhuu中的内容在wu的情况下
					if ww in wu:
						ws.send(sendd("{}中奖了 再来一次".format(nick)))
	
					else:
						ws.send(sendd(per + ww))
						wu.append(ww)


			# 来自朋友们的网站
			if text in ["树洞","tree"]:
				with open("record/tree.txt","r") as fp:
					f = fp.readlines()
					ff = random.choice(f).replace('\\n',n)

					# 内容在si的情况下
					if ff in si:
						ws.send(sendd("此链接被吃了"))
				
					else:
						# 直接发送f
						ws.send(sendd(per + ff))
						si.append(ff)


			if text in ["趣站","site"]:
				with open("record/site.txt","r") as fp:
					s = fp.readlines()
					ss = random.choice(s).replace('\\n',n)

					# 内容在si的情况下
					if ss in si:
						ws.send(sendd("不给不给 不给{}".format(nick)))
	
					else:
						# 直接发送s
						ws.send(sendd(per + ss))
						si.append(ss)


			if text in ["游戏","game"]:
				with open("record/game.txt","r") as fp:
					g = fp.readlines()
					gg = random.choice(g).replace('\\n',n)

					# 内容在si的情况下
					if gg in si:
						ws.send(sendd("哼 不可以贪心哦"))
	
					else:
						# 直接发送g
						ws.send(sendd(per + gg))
						si.append(gg)


			if text in ["网盘","pan"]:
				with open("record/pan.txt","r") as fp:
					p = fp.readlines()
					pp = random.choice(p).replace('\\n',n)

					# 内容在si的情况下
					if pp in si:
						ws.send(sendd("{}再试一次呗".format(nick)))
	
					else:
						# 直接发送p
						ws.send(sendd(per + pp))
						si.append(pp)
	

			if text in ["降水量预报"]:

				# api:优客API
				api = "https://api.iyk0.com/jyu?type=img"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + "![](" + res + ")"))
	

			if text in ["今日的世界"]:

				# api:优客API
				api = "https://api.iyk0.com/60s"
				se = requests.get(api)
				res = se.json()
				ws.send(sendd(per + "![](" + res["imageUrl"] + ")"))
	

			if text in ["摸鱼日历"]:

				# api:韩小韩API
				api = "https://api.vvhan.com/api/moyu"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + "![](" + res + ")"))


			if text in ["纸片君"]:
				with open("record/zpj.txt","r") as fp:
					if self.pic == False:
						z = fp.read()
						time.sleep(zz)
						ws.send(sendd(nn + z))

					with open("record/paper.txt","r") as fp:
						p = fp.readlines()
						j = random.choice(p)
						ws.send(sendd(per + "![](" + j.replace('\n','') + ")"))
						self.pic = True


			if text in ["七濑胡桃","heal"]:

				# api:小歪API
				api = "https://api.ixiaowai.cn/mcapi/mcapi.php"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + "![](" + res + ")"))
	

			if text in ["每日必应","bing"]:

				# api:保罗API
				api = "https://api.vvhan.com/api/bing?type=sj"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + "![](" + res + ")"))
	

			if text in ["小姐姐","girl"]:

				# api:夏沫博客 SuixinAPI
				api = random.choice(["https://cdn.seovx.com/ha/?mom=302","http://api.botwl.cn/api/meinvtu?n=1"])
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + "![](" + res + ")"))


			if text in ["涩图","acg"]:

				# api:晓晴博客 樱花 MuRongPIG自建
				api = random.choice(["https://acg.toubiec.cn/random.php","https://www.dmoe.cc/random.php","https://mrpig.eu.org/"])
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + "![](" + res + ")"))


			if text in ["头像","head"]:

				# api:搏天api
				api = "http://api.btstu.cn/sjtx/api.php"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + "![](" + res + ")"))
	

			if text in ["阿鲁","aru"]:

				# api:姬长信API
				api = "https://api.isoyu.com/ARU_GIF_S.php"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + "![](" + res + ")"))


			if text in ["表情","meme"]:

				# 表情参见设定部分
				ws.send(sendd(meme))


			if text in ["换色","color"]:

				# api:SuixinAPI 韩小韩API
				with open("record/color.txt","r") as fp:
					api = random.choice(["http://api.botwl.cn/api/sjys","https://api.vvhan.com/api/color"])
					se = requests.get(api)
					o = fp.readlines()
					oo = random.choice(o)
					co = random.choice([se.text,oo[:7]])

				# 更换bot的颜色
				ws.send(sendd("/color " + co))

				if co == se.text:
					ws.send(sendd(nn + "16进制颜色：" + co + n + "（仅在hack.chat有效）"))

				else:
					ws.send(sendd(nn + "16进制颜色：" + oo + n + "（仅在hack.chat有效）"))

				# 发送后重新换回44FF00
				ws.send(sendd("/color 44FF00"))
	

			if text in ["音乐","music"]:
				
				# 保罗API
				api = "https://api.paugram.com/acgm"
				se = requests.get(api)
				res = se.json()
				word = res["title"] + " " + res["artist"] + " " + n + res["link"]
				ws.send(sendd(per + word))


			if text in ["一言"]:

				# api:Hitokoto
				api = "https://v1.hitokoto.cn"
				se = requests.get(api)
				res = se.json()
				word = res["from"] + " " + res["creator"] + n + "「" + res["hitokoto"] + "」"

				# api:韩小韩API
				apii = "https://api.vvhan.com/api/ian"
				see = requests.get(apii)
				ress = see.text

				# 随机选取
				b = random.choice([word,ress])

				# 如果双引号存在就替换
				if "“" in b or "”" in b:
					ws.send(sendd(per + b.replace('“','「').replace('”','」')))

				# 如果b内容是ress
				elif b == ress:
					ws.send(sendd(per + "「" + b + "」"))

				else:
					# 以上两种情况皆无
					ws.send(sendd(per + b))


			if text in ["励志"]:

				# api:SuixinAPI
				api = "http://api.botwl.cn/api/yhyl"
				se = requests.get(api)
				res = "「" + se.text + "」"
				ws.send(sendd(per + res))


			if text in ["情话"]:

				# api:沙雕APP
				api = "https://api.lovelive.tools/api/SweetNothings/count/Serialization/serializationType"
				se = requests.get(api)
				res = se.json()
				word = res["returnObj"]
				a = random.choice(word)

				# api:UomgAPI
				apii = "https://api.uomg.com/api/rand.qinghua"
				see = requests.get(apii)
				ress = see.json()
				wordd = ress["content"]

				# api:韩小韩API
				apiii = random.choice(["https://api.vvhan.com/api/love","https://api.vvhan.com/api/sao"])
				seee = requests.get(apiii)
				resss = seee.text
				
				# 随机选取
				b = random.choice([a,wordd,resss])

				# 如果双引号存在就替换
				if "“" in b or "”" in b:
					ws.send(sendd(per + b.replace('“','「').replace('”','」')))

				else:
					# 以上两种情况皆无
					ws.send(sendd(per + "「" + b + "」"))
	

			if text in ["哲学"]:
				
				# api:奇远api
				api = "https://api.oddfar.com/yl/q.php?c=2011"
				se = requests.get(api)
				res = "「" + se.text + "」"
				ws.send(sendd(per + res))
	

			if text in ["伤感"]:
				
				# api:优客API
				api = "https://api.iyk0.com/sg/"
				se = requests.get(api)
				res = "「" + se.text + "」"
				ws.send(sendd(per + res))


			if text in ["笑话"]:
				
				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/xiaohua?api_key=c2b3c8ef3925db80"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = "【" + a["title"] + "】" + n + a["content"]

				# 如果双引号存在就替换
				if "“" in word or "”" in word:
					ws.send(sendd(per + word.replace('“',n + '「').replace('”','」' + n)))

				else:
					# 以上两种情况皆无
					ws.send(sendd(per + word))


			if text in ["抽签"]:
				
				# api:SuixinAPI
				api = "http://api.botwl.cn/api/qiuqian"
				se = requests.get(api)
				res = se.text.replace('[\\n]',n)
				ws.send(sendd(per + res))


			if text in ["彩虹屁"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/caihongpi?api_key=4acee95f422ea04a"
				se = requests.get(api)
				res = se.json()
				b = res["data"]["comment"]

				# 如果双引号存在就替换
				if "“" in b or "”" in b:
					ws.send(sendd(per + b.replace('“','「').replace('”','」')))

				else:
					# 在两边加上括号
					ws.send(sendd(per + "「" + b.replace('"','') + "」"))


			if text in ["毒鸡汤"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/dujitang?api_key=e5103c1917bc4026"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = a["comment"]

				# api:搏天api
				apii = "http://api.btstu.cn/yan/api.php"
				see = requests.get(apii)
				ress = see.text
				
				# 随机选取并发送
				b = random.choice([word,ress])
				ws.send(sendd(per + "「" + b + "」"))


			if text in ["古诗词"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/Gushici?api_key=1469d017a08f2827"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = a["title"] + " " + a["author"] + n + "「" + a["min_content"] + "」"
				ws.send(sendd(per + word))


			if text in ["今日曰"]:

				# api:韩小韩API
				api = "https://api.vvhan.com/api/en"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				b = "Today Is " + a["month"] + " " + a["day"]
				word = b + n + "「" + a["zh"] + "」" + n + "「" + a["en"] + "」"
				ws.send(sendd(per + word))
	

			if text in ["猜字谜"]:
				
				# api:SuixinAPI
				api = "http://api.botwl.cn/api/miyu"
				se = requests.get(api)
				res = se.text
				ws.send(sendd(per + res.replace(' ',n)))
	

			if text in ["绕口令"]:
				
				# api:优客API
				api = "https://api.iyk0.com/rkl/"
				se = requests.get(api)
				res = se.json()
				a = res["txt"].replace('】','】' + n).replace('。','。' + n)
				ws.send(sendd(per + a))
	

			if text in ["网易热评"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/163reping?api_key=5d60829ddff7ea03"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = "来自 " + a["nickname"] + a["songName"] + n + "「" + a["content"] + "」"
				ws.send(sendd(per + word))


			if text in ["舔狗日记"]:

				# api:小歪API
				api = "https://api.ixiaowai.cn/tgrj/index.php"
				se = requests.get(api)
				res = "「" + se.text + "」"

				# api:木小果API
				apii = "https://api.muxiaoguo.cn/api/tiangourj?api_key=300ec8fe32c3562a"
				see = requests.get(apii)
				ress = see.json()
				a = ress["data"]
				word = "「" + a["comment"] + "」"

				# 仅为恶搞
				ee = chat + " " + room + " " + name + n
				
				# 随机选取并发送
				b = random.choice([res,word])
				ws.send(sendd(per + ee + b.replace('*','').replace('“','『').replace('”','』')))


			if text in ["骂人宝典"]:
				
				# api:奇远api
				api = "https://api.oddfar.com/yl/q.php?c=1009"
				se = requests.get(api)
				res = se.text
				with open("record/ma.txt","r") as fp:
					ma = fp.readlines()
					maa = random.choice(ma)
					ws.send(sendd(per + "「" + random.choice([res,maa]).replace(n,'') + "」"))
	

			if text in ["社会语录"]:

				# api:零七生活API 奇远api
				api = random.choice(["https://api.oick.cn/yulu/api.php","https://api.oddfar.com/yl/q.php?c=1002"])
				se = requests.get(api)
				res = se.text.replace('\"','')
				word = "「" + res + "」"
				ws.send(sendd(per + word))
	

			if text in ["中二网名"]:
				
				# api:远昔API
				api = "https://www.yuanxiapi.cn/api/wangming/"
				se = requests.get(api)
				res = se.json()
				a = "「" + res["name"] + "」"
				ws.send(sendd(per + a))


			if text in ["乘法口诀"]:
				with open("record/x.txt","r") as fp:
					x = fp.readlines()
					xx = random.choice(x).replace(n,'')
					time.sleep(zz)
					ws.send(sendd(per + "「" + xx + "」"))
	

			if text in ["央视新闻"]:

				# api:优客API
				api = "https://api.iyk0.com/ysxw/"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				b = len(a)
				c = random.randint(0,b)
				d = a[c]
				e = "标题：" + d["title"] + n + "摘要：" + d["brief"].replace('。','。' + n) + n + "地址：" + d["url"] + n
				f = nn + "聚焦时间：" + d["focus_date"]
				ws.send(sendd(per + e + f))
	

			if text in ["历史上的今天"]:

				# api:公共api
				api = "https://qqlykm.cn/api/lishi/index.php"
				se = requests.get(api)
				res = "【" + se.text + "】"
				ws.send(sendd(per + res))
	

			if text in ["我在人间凑数的日子"]:

				# api:优客API
				api = "https://api.iyk0.com/renjian/"
				se = requests.get(api)
				res = "「" + se.text.replace('"','').replace('“','『').replace('”','』').replace('《',' ').replace('》','')
				if "—" in res:
					a = int(res.count("—"))
					b = res.replace("—"*a,'」' + n).replace("—",n)
					ws.send(sendd(per + b))

				elif "-" in res:
					a = int(res.count("-"))
					b = res.replace("-"*a,'」' + n).replace("-",n)
					ws.send(sendd(per + b))

				else:
					ws.send(sendd(per + res))


			if text[:2] == "E-":
				with open("record/E/" + nick + ".txt","w") as fp:

					# 设置为空时重置
					if text[2:] == "":
						ws.send(sendd("已重置欢迎语"))
						fp.truncate(0)

					# 防止bot被卡BUG
					elif "/" in text[2] or "`" in text or "-" in text[3:]:
						ws.send(sendd("包含无效的字符"))

					else:
						# 把欢迎语写入带昵称的文件中
						fp.write(text[2:] + n)
						ws.send(sendd("设置成功 将在下次进入聊天室时生效"))

						# 打开昵称文件
						with open("record/join.txt","r+") as fpp:
							ck = fpp.readlines()

							# 如果昵称不存在 则向ck写入昵称
							if nick + n not in ck:
								fpp.write(nick + n)
								fp.close()
								fpp.close()


			if text[:3] == "CA-":

				# 判断字数是否小于3
				if len(text[3:]) < 3:
					ws.send(sendd("留言的内容至少3个字 请不要氵哦"))

				else:
					# 把留言写入揭示板中
					with open("record/B/" + chat + ".txt","a+") as fp:
						ch = time.strftime("%H:%M:%S ",time.localtime())
						an = "From." + room + "）" + n + ch + nick + "：" + n + text[3:]
						fp.write(nn + an + n)
						ws.send(sendd("已成功把{}的留言写到揭示板里".format(nick)))

						# 打开日期文件
						with open("record/date.txt","r+") as fpp:
							da = fpp.readlines()

							# 如果日期不存在 则向da写入日期
							if chat + n not in da:
								fpp.write(chat + n)
								fp.close()
								fpp.close()


			if text[:3] == "DK-":

				# 判断字数是否大于10
				if len(text[3:]) > 10:
					ws.send(sendd("心情或状态请在10字内"))

				else:
					ch = time.strftime("%H:%M:%S ",time.localtime())
					an = "From." + room + "）" + n + ch + nick

					# 打开日期文件
					with open("record/deta.txt","r+") as fp:
						da = fp.readlines()
						chat = time.strftime("%Y.%m.%d")
						if chat + n in da:
							with open("record/D/" + chat + ".txt","r+") as fpp:
								ic = fpp.readlines()
								if nick + n in ic:
									ws.send(sendd("{}今天已经签到过了".format(nick)))

								else:
									with open("record/K/" + chat + ".txt","a+") as fppp:
										with open("record/T/" + nick + ".txt","a+") as fpppp:
											fpp.write(nick + n)
											fpppp.write(chat + n)
											fpppp.close()
											dq = open("record/T/" + nick + ".txt","r")
											qd = dq.readlines()
											b = "{}已成功签到".format(nick)
											c = "你的总签到天数为" + str(len(qd)) + "天"
											ws.send(sendd(nn + b + n + c))
											if text[3:] == "" or " " in text:
												fppp.write(nn + an + "已签到" + n)

											else:
												fppp.write(nn + an + text[3:] + n)

											with open("record/kd.txt","r+") as kd:
												dk = kd.readlines()
												if nick + n not in dk:
													kd.write(nick + n)

						else:
							# 如果日期不存在 则不查询用户是否签过到
							with open("record/D/" + chat + ".txt","a+") as fpp:
								with open("record/K/" + chat + ".txt","a+") as fppp:
									with open("record/T/" + nick + ".txt","a+") as fpppp:
										chat = time.strftime("%Y.%m.%d")
										fp.write(chat + n)
										fpp.write(nick + n)
										fpppp.write(chat + n)
										fpppp.close()
										dq = open("record/T/" + nick + ".txt","r")
										qd = dq.readlines()
										b = "{}是今天第1个签到的".format(nick)
										c = "你的总签到天数为" + str(len(qd)) + "天"
										ws.send(sendd(nn + b + n + c))
										if text[3:] == "" or " " in text:
											fppp.write(nn + an + "已签到" + n)

										else:
											fppp.write(nn + an + text[3:] + n)

										with open("record/kd.txt","r+") as kd:
											dk = kd.readlines()
											if nick + n not in dk:
												kd.write(nick + n)


			if text[:2] == "B-":
				with open("record/date.txt","r") as fp:
					da = str(fp.readlines())
					date = da.replace('[\'','').replace('\']','').replace('\'',' ').replace('\\n','')
					if text[2:] == "":
						with open("record/date.txt","r") as fp:
							da = fp.readlines()
							if chat + n in da:
								with open("record/B/" + chat + ".txt","r") as fp:
									ca = fp.read()
									ht = "今日揭示板状况" + n + "（管理员 ee）" + n
									ws.send(sendd(per + ht + ca))

							else:
								ws.send(sendd("今天的揭示板空空如也"))

					elif text[2:] in date:
						with open("record/B/" + text[2:] + ".txt","r") as fp:
							ca = fp.read()
							ht = "聊天室" + text[2:] + "揭示板" + n + "（管理员 ee）" + n
							ws.send(sendd(per + ht + ca))

					else:
						ws.send(sendd("请检查日期是否正确"))


			if text[:2] == "D-":
				with open("record/deta.txt","r") as fp:
					de = str(fp.readlines())
					deta = de.replace('[\'','').replace('\']','').replace('\'',' ').replace('\\n','')
					chat = time.strftime("%Y.%m.%d")
					if text[2:] == "":
						with open("record/deta.txt","r") as fp:
							de = fp.readlines()
							if chat + n in de:
								with open("record/K/" + chat + ".txt","r") as fp:
									dq = fp.read()
									qd = "今日签到人员" + n + "（管理员 ee）" + n
									ws.send(sendd(per + qd + dq))

							else:
								ws.send(sendd("今天还没有人签到哦 快成为第一个签到吧"))

					elif text[2:] in deta:
						with open("record/K/" + text[2:] + ".txt","r") as fp:
							dq = fp.read()
							qd = text[2:] + "签到人员" + n + "（管理员 ee）" + n
							ws.send(sendd(per + qd + dq))

					else:
						ws.send(sendd("请检查日期是否正确"))


			if text[:2] == "C-":
				with open("record/kd.txt","r") as fp:
					kk = fp.readlines()
					if text[2:] == "":
						if nick + n in kk:
							with open("record/T/" + nick + ".txt","r") as fpp:
								dd = str(fpp.readlines())
								dq = open("record/T/" + nick + ".txt","r")
								qd = dq.readlines()
								a = dd.replace('[\'','').replace('\']','').replace('\'',' ').replace('\\n','')
								b = nn + nick + "的签到记录：" + n + a
								c = "你的总签到天数为" + str(len(qd)) + "天"
								ws.send(sendd(b + n + nn + c))

						else:
							ws.send(sendd("查无你的签到记录"))

					else:
						if text[2:] + n in kk:
							with open("record/T/" + text[2:] + ".txt","r") as fpp:
								dd = str(fpp.readlines())
								dq = open("record/T/" + text[2:] + ".txt","r")
								qd = dq.readlines()
								a = dd.replace('[\'','').replace('\']','').replace('\'',' ').replace('\\n','')
								b = nn + text[2:] + "的签到记录：" + n + a
								c = "他的总签到天数为" + str(len(qd)) + "天"
								ws.send(sendd(b + n + nn + c))

						else:
							ws.send(sendd("查无此人的签到记录"))


			if text[:3] == "IP-":

				# 判断词后是否留空
				if text[3:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:韩小韩API
					url = "https://api.vvhan.com/api/getIpInfo"
					data = {"ip":text[3:]}
					se = requests.get(url,data)
					res = se.json()
					if res["success"] == False:
						ws.send(sendd("请求失败 请检查IP地址"))

					else:
						a = res["info"]
						b = nn + "地址：" + res["ip"] + n + "所属：" + a["lsp"]
						if a["prov"] == "":
							ws.send(sendd(b))

						elif a["city"] == "":
							c = n + nn + "国家：" + a["country"] + n + "省份：" + a["prov"]
							ws.send(sendd(b + c))

						else:
							c = n + nn + "国家：" + a["country"] + n + "省份：" + a["prov"] + n + "城市：" + a["city"]
							ws.send(sendd(b + c))


			if text[:5] == "PING-":

				# 判断词后是否留空
				if text[5:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:SuixinAPI
					url = "http://api.botwl.cn/api/ping"
					data = {"url":text[5:]}
					se = requests.get(url,data)
					res = se.json()

					# 如果状态码为1 则成功
					if res["code"] == 1:
						a = nn + res["host"] + "（" + res["ip"] + "）"
						b = n + nn + "最快用时：" + res["ping_time_min"] + n + "最慢用时：" + res["ping_time_max"]
						ws.send(sendd(a + b.replace(' ','')))

					else:
						ws.send(sendd("获取失败 请检查域名"))


			if text[:4] == "ICP-":

				# 判断词后是否留空
				if text[4:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:零七生活API
					url = "https://api.oick.cn/icp/api.php"
					data = {"url":text[4:]}
					se = requests.get(url,data)
					res = se.json()

					# 如果状态码为200 则成功
					if res["code"] == 200:
						a = nn + res["site_name"] + "（" + res["site_index"] + "）"
						b = n + nn + "单位：" + res["name"] + n + "类型：" + res["nature"]
						c = n + nn + "备案信息：" + res["icp"] + n + "备案时间：" + res["site_time"]
						ws.send(sendd(a + b + c))

					# 如果状态码为201 无记录
					elif res["code"] == 201:
						ws.send(sendd("API出错或未有此域名ICP备案记录"))

					else:
						ws.send(sendd("获取失败 请检查域名"))


			if text[:3] == "QQ-":

				# 判断词后是否留空
				if text[3:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:搏天api
					url = "http://api.btstu.cn/qqxt/api.php"
					data = {"qq":text[3:]}
					se = requests.get(url,data)
					res = se.json()

					if res["code"] == 1 and res["name"] != "":
						a = nn + res["name"] + n + text[3:]
						ws.send(sendd(a))

					else:
						ws.send(sendd("查询失败 请检查QQ号"))


			if text[:5] == "CITY-":

				# 判断词后是否留空
				if text[5:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:木小果API
					url = "https://api.muxiaoguo.cn/api/tianqi"
					data = {"city":text[5:],"type":1,"api_key":"9410e360a940cb5e"}
					se = requests.get(url,data)
					res = se.json()
					a = res["data"]

					# 如果状态码为200 则成功
					if res["code"] == 200:
						b = nn + "城市：" + text[5:] + "（" + a["weather"] + "）"
						c = n + "温度：" + a["temp"] + "°C" + n + "湿度：" + a["SD"]
						d = n + nn + "风向：" + a["WD"] + n + "风级：" + a["WS"] + n + "风速：" + a["wse"]
						e = n + nn + "更新时间：" +  a["time"]
						ws.send(sendd(b + c + d + e))

					else:
						ws.send(sendd("查询失败 请检查城市"))


			if text[:3] == "DU-":

				# 判断词后是否留空
				if text[3:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:木小果API
					url = "https://api.muxiaoguo.cn/api/Baike"
					data = {"type":"Baidu","word":text[3:],"api_key":"cb28182953ac4557"}
					se = requests.get(url,data)
					res = se.json()
					a = res["data"]

					# 如果状态码为200 则成功
					if res["code"] == 200:
						b = nn + "查询：" + text[6:] + n + nn + "百度：" + a["content"]
						c = b.replace('。','。' + n).replace('"','').replace('(','（').replace(')','）').replace('“','「').replace('”','」')
						ws.send(sendd(c))

					else:
						ws.send(sendd("查询失败 无此百科"))


			if text[:5] == "SOGO-":

				# 判断词后是否留空
				if text[5:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:木小果API
					url = "https://api.muxiaoguo.cn/api/Baike"
					data = {"type":"Sogo","word":text[5:],"api_key":"cb28182953ac4557"}
					se = requests.get(url,data)
					res = se.json()
					a = res["data"]

					# 如果状态码为200 则成功
					if res["code"] == 200:
						b = nn + "查询：" + text[5:] + n + nn + "搜狗：" + a["content"]
						c = b.replace('。','。' + n).replace('(','（').replace(')','）').replace('“','「').replace('”','」')
						ws.send(sendd(c))

					else:
						ws.send(sendd("查询失败 无此百科"))


			if text[:2] == "F-":

				# 判断词后是否留空
				if text[2:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:网易有道翻译
					url = "http://fanyi.youdao.com/translate"
					head = {"User-Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0"}

					if len(text[2:]) > 200:
						ws.send(sendd("超出最大字符数200"))

					else:
						data = {"doctype":"json","type":"AUTO","i":text[2:]}
						se = requests.get(url,params = data,headers = head,timeout = 10)
						res = se.json()

						# 如果状态码为0 则成功
						if res["errorCode"] == 0:
							a = res["translateResult"][0][0]["tgt"]
							ws.send(sendd("{} said：".format(nick) + a))

						else:
							ws.send(sendd("请求失败 请稍后再试"))


			if text[:3] == "ID-":

				# 判断词后是否留空
				if text[3:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:零七生活API
					url = "https://api.oick.cn/wyy/api.php"
					data = {"id":text[3:]}
					se = requests.get(url,data)
					res = se.url
					if "https://music.163.com/404" == res:
						ws.send(sendd("网易云ID获取失败 请检查"))

					else:
						ws.send(sendd(res))


			if text[:2] == "N-":

				# 判断词后是否留空
				if text[2:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:SuixinAPI
					url = "http://api.botwl.cn/api/sjhgsd"
					data = {"sjh":text[2:]}
					se = requests.get(url,data)
					res = se.json()

					# 如果状态码为1 则成功
					if res["code"] == 1:
						a = nn + "手机号：" + res["手机号"]
						b = n + nn + "归属地：" + res["归属地"] + n + "卡类型：" + res["卡类型"]
						ws.send(sendd(a + b))

					else:
						ws.send(sendd("获取失败 请检查手机号"))


			if text[:2] == "L-":

				# 判断词后是否留空
				if text[2:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:搏天api
					url = "https://api.vvhan.com/api/la.ji"
					data = {"lj":text[2:]}
					se = requests.get(url,data)
					res = se.json()

					if res["sort"] != "俺也不知道是什么垃圾~":
						ws.send(sendd(res["sort"]))

					else:
						ws.send(sendd("所以这是什么垃圾"))


			if text[:3] == "BI-":

				# 判断词后是否留空
				if text[3:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					# api:优客API
					url = "https://api.iyk0.com/bili_cover"
					data = {"msg":text[3:]}
					se = requests.get(url,data)
					res = se.json()

					if "http" in text:
						ws.send(sendd("请输入BV号"))

					else:
						# 如果状态码为200 则成功
						if res["code"] == 200:
							a = nn + "UP主：" + res["name"] + n + "标题：" + res["title"] + n + "简介：" + res["desc"] + n
							b = nn + "地址：" + "https://www.bilibili.com/video/" + text[3:] + n + "封面：" + res["pic"]
							ws.send(sendd(a + b))

						else:
							ws.send(sendd("获取失败 请检查BV号"))


			if text[:3] == "LO-":

				# 判断词后是否留空
				if text[3:] == "":
					ws.send(sendd("请勿留空哦"))

				else:
					if len(text[3:]) <= 10:
						# api:优客API
						url = "https://api.iyk0.com/gpbt/"
						data = {"msg":text[3:],"num":100}
						se = requests.get(url,data)
						res = se.json()

						# 如果状态码为200 则成功
						if res["code"] == 200:
							a = nn + res["data"].replace('\r', '').replace('。', '。' + n).replace('.', '。' + n)
							ws.send(sendd(a))

						else:
							ws.send(sendd("失败 API出错或受频率限制"))

					else:
						ws.send(sendd("请控制主题在10字内"))


			if "http" in text:

				# api:远昔API
				a = re.findall(r'(https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+)',text)
				b = a[0]
				url = "https://yuanxiapi.cn/api/info/"
				data = {"url":b}
				se = requests.get(url,data)
				res = se.json()

				# 如果状态码为200 则成功
				if res["code"] == 200:
					c = "@" + nick + " " + res["title"] + n + b
					ws.send(sendd(nn + c))

					# 单独存放连接
					with open("record/web.txt","r+") as fp:
						eb = fp.readlines()
						if b + n not in eb:
							ch = time.strftime(" %Y.%m.%d %H:%M:%S",time.localtime())
							sm = nn + "From." + room + ch + "）" + n + c + n
							fp.write(sm)


			if "-" not in text:
				if "@" + name in text and "@" in text[0]:

					# @name后的字符串索引
					a = len(name) + 1
					b = text[a:]

					# 如果@的后面为空
					if text[a:] == "":
						time.sleep(ee)
						ws.send(sendd(random.choice(["{}有事吗".format(nick),"欢迎来" + room + "聊天","找ee去吧","好耶"])))

					# 自设的部分
					elif "好" in b:
						time.sleep(ee)
						if "吧" in b:
							ws.send(sendd(random.choice(["那不就没问题了嘛（","这就对了","嗯嗯"])))

						elif "不" in b:
							ws.send(sendd(random.choice(["靠在{}身边）".format(nick),"啊哈"])))

						elif "看" in b or "康" in b:
							ws.send(sendd(random.choice([name + "觉得不错嘛","哇哦"])))

						elif "大家" in b or "你" in b:
							ws.send(sendd(random.choice(["欢迎来到" + room,"你好你好"])))

						else:
							ws.send(sendd(random.choice(["诶嘿","嗨嗨害","欧拉欧拉","好耶好耶"])))

					if "你" in b:
						time.sleep(ee)
						if "是" in b or "的" in b or "有" in b or "没" in b:
							if "妈" in b or "爸" in b or "娘" in b or "爹" in b:
								ws.send(sendd(random.choice([name + "是纸片君ee的",name + "是ee的女儿","eb的亲妈是ee！亲爹也是ee"])))

							if "哥" in b or "弟" in b or "姐" in b or "妹" in b:
								ws.send(sendd(random.choice(["bot们都是（结拜）兄弟姐妹",name + "是独生女","eb也想要有"])))

							if "朋友" in b:
								a = random.choice(bot).replace(n,'')
								ws.send(sendd(random.choice([nick + "在和eb聊天 那么我们就是朋友啦",a + "是" + name + "的朋友"])))

							else:
								ws.send(sendd(random.choice(["没有吧（","{}想当吗？".format(nick),"可以有"])))

						else:
							ws.send(sendd(random.choice(["诶嘿","嗨嗨害","欧拉欧拉","好耶好耶"])))

					elif "没" in b:
						time.sleep(ee)
						if "事" in b or "问题" in b or "关系" in b or "必要" in b:
							ws.send(sendd(random.choice(["问题不大啦","没问题","确实","雀食"])))

						elif "人" in b:
							if "吗" in b or "？" in b or "?" in b:
								ws.send(sendd(random.choice(["有人！","有" + name + "在呢","有bot","来了来了"])))

							else:
								ws.send(sendd(random.choice(["应该吧","是啊","是的","如果是这样的话"])))

						else:
							ws.send(sendd(random.choice(["诶嘿","嗨嗨害","欧拉欧拉","好耶好耶"])))

					elif "《" in b and "》" in b:
						time.sleep(zz)
						ws.send(sendd(random.choice(["论大家都喜欢书名号这回事","芜湖","《" + room + "》","咕噜咕噜"])))

					elif "绿" in b or "44FF00" in b:
						time.sleep(ee)
						ws.send(sendd(random.choice(["ww绿！","44FF00是最棒的颜色","大自然之~~荧光绿~~"])))

					elif "可怕" in b or "吓人" in b or "害怕" in b:
						time.sleep(ee)
						ws.send(sendd(random.choice(["摸摸","富强民主文明和谐……","社会主义核心价值观"])))

					elif "纸片君" in b or "ee" in b:
						time.sleep(ee)
						ws.send(sendd(random.choice(["{}觉得呢".format(nick),"富强民主文明和谐……"])))

					elif "胶水" in b or "glue" in b:
						time.sleep(ee)
						ws.send(sendd(random.choice([name + "来派发jillGlue了","一天一胶水 医生远离我"])))

					elif "加油" in b:
						time.sleep(ee)
						ws.send(sendd(random.choice(["{}也加油".format(nick),"加油吧 少年","向着那明日的朝阳前进吧","鼓起勇气 迈向未来"])))

					elif "复读机" in b:
						time.sleep(ee)
						ws.send(sendd(random.choice(["才不是复读机","不仅bot是 你们也是（"])))

					elif "柠檬" in b or "酸了" in b:
						time.sleep(zz)
						ws.send(sendd(random.choice(["柠檬树下柠檬果", "柠檬树下" + nick + "和" + name,"（托腮.jpg）"])))

					elif "延迟" in b:
						time.sleep(zz)
						ws.send(sendd(random.choice(["这不是" + name + "的错","eb的代码太长了（","ee还在研究多线程"])))

					elif b in ["机器人","bot"]:
						time.sleep(ee)
						ws.send(sendd(random.choice([name + "是bot","@fOoLishbIrD ","@Wcy_Bot ","@zzChumo "])))

					else:
						# api:SuixinAPI
						url = "http://api.botwl.cn/api/aick"
						data = {"msg":text[a:].replace(' ','')}
						se = requests.get(url,data)
						res = se.json()
						l = res["msg"]

						# 判断状态码是否成功
						if res["code"] == "1":

							# 打开aick文件
							with open("record/aick.txt","r") as fp:
								ai = fp.readlines()

								# 以列表的形式读取text
								with open("record/text.txt","r") as fpp:
									xt = random.choice(fpp.readlines())
									tx = xt.replace('我们',"bot").replace('你们',nick)
									tx = tx.replace('我',name).replace('你',nick).replace('，',' ')

									# 屏蔽aick中的关键字
									if text[a:] + n not in ai:

										# 如果l中存在{}
										if "{" in l and "}" in l:
											ws.send(sendd(tx))

										else:
											# 替换和简繁转换
											c = l.replace('随心',"eb").replace('我们',"bot").replace('你们',nick)
											c = c.replace('我',name).replace('你',nick).replace('，',' ')
											d = Converter('zh-hans').convert(c)
											e = d.replace('啥','什么').replace('咋','怎么').replace('“','「').replace('”','」')

											# 如果字符串的长度为偶数
											if (len(e) % 2) == 0:
												f = random.choice(["（","）","（）"])
												ws.send(sendd(e + f))

											else:
												# 直接发送e
												ws.send(sendd(e))

									else:
										# 直接发送tx
										ws.send(sendd(tx))

						else:
							# 随机一句话
							ws.send(sendd(random.choice(["诶嘿","嗨嗨害","欧拉欧拉","好耶好耶"])))


				if len(te) == 25 or len(te) == 75:

					# 判断te的长度和text的长度
					if len(text) < 10 and len(text) > 2:

						# api:SuixinAPI
						url = "http://api.botwl.cn/api/aick"
						data = {"msg":text.replace(' ','')}
						se = requests.get(url,data)
						res = se.json()
						a = res["msg"]

						# 替换和简繁转换
						b = a.replace('随心',"bot").replace('我们',"bot").replace('你们',nick)
						b = b.replace('我',name).replace('你',nick).replace('，',' ')
						c = Converter('zh-hans').convert(b)
						d = c.replace('啥','什么').replace('咋','怎么').replace('“','「').replace('”','」')

						te.append(text)

						# 如果l中存在{}
						if "{" in a and "}" in a:
							e = random.choice(["诶嘿","嗨嗨害","欧拉欧拉","好耶好耶"])
							ws.send(sendd(e))

						else:
							# 如果字符串c的长度为奇数
							if (len(b) % 2) != 0:
								e = d + random.choice(["（","）","（）"])
								ws.send(sendd(e))

							else:
								# 直接发送d
								ws.send(sendd(d))


				if len(text) < 10:

					# 判断未有游戏进行
					if len(ga) == 0:
						time.sleep(zz)
						te.append(text)

						# te长度为50时bot随机输出te内容
						if len(te) == 50:
							t = random.choice(te).replace('我们',"bot").replace('你们',nick)
							t = t.replace('我',name).replace('你',nick)
							ws.send(sendd(t))

						# te长度为100时bot复读一句话
						if len(te) == 100:
							ws.send(sendd(text))
							te.clear()

					# 复读或发送meme中的表情
					if text in meme:
						t = text.replace('我们',"bot").replace('你们',nick)
						t = t.replace('我',name).replace('你',nick).replace('，',' ')
						ws.send(sendd(random.choice([t,meme])))


				if len(text) < 30 and len(text) > 10:

					# 排除@和bot昵称在text的情况 nick里有bot昵称的情况
					if "@" not in text and name not in text and nick + n not in bot:

						# 将话写入text文件
						with open("record/text.txt","r+") as fp:
							tx = fp.readlines()
							if text + n not in tx:
								fp.write(text + n)


			# 防止多个游戏同时进行
			if text in ["真心话","飞花令","词语接龙","故事制造机"]:
				if len(ga) != 0 and text not in ga:
					with open("record/over.txt","r") as fp:
						a = fp.read().replace('——',ga[0])
						time.sleep(zz)
						ws.send(sendd(a))


			# 如果想玩的游戏已经开始了
			if text in ga:
				time.sleep(zz)
				ws.send(sendd("{}已经开始了".format(ga[0])))


			# 在有游戏进行的情况下
			if len(ga) != 0:

				# 结束游戏
				if text in ["结束游戏"]:
					time.sleep(zz)
					ws.send(sendd("{}已结束".format(ga[0])))

					# 清空所有游戏数据
					by.clear()
					pl.clear()
					ga.clear()

					# 关闭所有开关
					self.true = False
					self.word = False
					self.story = False
					self.flower = False
				
				# 重置游戏
				elif text in ["重置游戏"]:
					time.sleep(zz)
					ws.send(sendd("{}已重置".format(ga[0])))

					# 清空游戏内容
					by.clear()
					pl.clear()

					# 在真心话开关打开的情况下
					if self.flower == True:
						time.sleep(ee)
						ws.send(sendd("下句的关键词在第1个字上"))
			

			if text in ["真心话"]:

				# 如果游戏未开启
				if self.true == False and len(ga) == 0:

					# 真心话说明
					with open("record/true.txt","r") as fp:
						a = fp.read()
						ws.send(sendd(a))
						time.sleep(zz)
						ws.send(sendd("真心话游戏开始"))
						ga.append(text)

						# 真心话开关打开
						self.true = True
				

			if text in ["飞花令"]:

				# 如果游戏未开启
				if self.flower == False and len(ga) == 0:

					# 飞花令说明
					with open("record/flower.txt","r") as fp:
						a = fp.read()
						ws.send(sendd(a))
						time.sleep(zz)
						ws.send(sendd("游戏开始 下句的关键词在第1个字上"))
						ga.append(text)

						# 飞花令开关打开
						self.flower = True
				

			if text in ["词语接龙"]:

				# 如果游戏未开启
				if self.word == False and len(ga) == 0:

					# 词语接龙说明
					with open("record/word.txt","r") as fp:
						a = fp.read()
						ws.send(sendd(a))
						time.sleep(zz)
						ws.send(sendd("请{}开一个好头吧".format(nick)))
						ga.append(text)
						by.append(nick)

						# 词语接龙开关打开
						self.word = True
				

			if text in ["故事制造机"]:

				# 如果游戏未开启
				if self.story == False and len(ga) == 0:

					# 故事制造机说明
					a = nn + "游戏制作中 敬请期待"
					ws.send(sendd(a))
					ga.append(text)

					# 故事制造机开关打开
					self.story = True


		if text in ["随机数","r"] or "r" in text[0]:

			# 随机1~999的数字
			r = random.randint(1,999)

			# 如果真心话开关开启
			if self.true == True:

				# 无效在by中的昵称
				if nick in by:
					ws.send(sendd("{}已经r过了".format(nick)))

				else:
					# 发送r数字并记录值和昵称
					by.append(nick)
					pl.append(int(r))
					ws.send(sendd(r))

			else:
				# 如果真心话开关关闭
				ws.send(sendd(r))


		if text in ["结算"]:

			# 如果真心话开关开启
			if self.true == True:

				# 游戏成员<2人
				if len(by) < 2:
					time.sleep(zz)
					ws.send(sendd("人数不足 至少要有2个人"))

				else:
					# 获取pl中最大和最小的数字
					j = max(pl)
					k = min(pl)

					# 获取pl中分别对应最大和最小的成员
					v = by[pl.index(j)]
					m = by[pl.index(k)]

					# 将数字字符串化
					a = "最大：" + str(j) + "（" + v + "）"
					b = "最小：" + str(k) + "（" + m + "）"
					c = nn + "本次参与人数：" + str(len(by)) + n + nn + a + n + b

					# 发送并清空by和pl
					time.sleep(zz)
					ws.send(sendd(c))
					time.sleep(ee)
					ws.send(sendd("@" + v + " 向@" + m + " 提问"))
					by.clear()
					pl.clear()

			# 如果成语接龙开关开启
			if self.word == True:

				# 如果pl中没有数据
				if len(pl) == 0:
					time.sleep(zz)
					ws.send(sendd("不允许在游戏未开始前结束"))

				else:
					# 发送游戏数据后清空
					j = nn + str(pl).replace(',',n).replace('[\'','').replace('\']','').replace('\'',' ')
					k = n + nn + "by." + str(by).replace('[\'','').replace('\']','').replace('\'',' ')
					q = "（" + str(len(by)) + "）"
					time.sleep(zz)
					ws.send(sendd(str(j + k + q)))
					by.clear()
					pl.clear()
	

		# 如果成语接龙开关开启
		if self.word == True:

			# 获取特定位置的字
			z = len(pl)
			a = nn + "@" + nick + " 接了「" + text[2:] + "」 " + n
			b = "下一词的开头为「" + text[-1] + "」"

			# P-存在的情况下
			if "P-" in text and str(text).count("-") == 1:

				# 如果文本长度为6
				if len(text) == 6:

					# 如果pl中没有数据
					if z == 0:
						time.sleep(zz)
						pl.append(text[2:])

						# 昵称已在by的情况下
						if nick in by:
							ws.send(sendd(a + b))

						else:
							# 昵称不在by
							ws.send(sendd("那好 就由{}开始吧".format(nick)))
							time.sleep(zz)
							ws.send(sendd(a + b))

							# 清空by中的昵称再将新昵称写入
							by.clear()
							by.append(nick)

					else:
						# pl中已有数据
						time.sleep(zz)

						# 判断文本中的第三个字是否为前成语的末尾
						if text[2] in pl[z - 1][-1]:
							ws.send(sendd(a + b))
							pl.append(text[2:])

							# 如果昵称不在by中
							if nick not in by:
								by.append(nick)

						else:
							# 成语的头尾接不上
							ws.send(sendd("请检查词语的头尾是否接上"))

				else:
					# 文本长度不是6
					time.sleep(zz)
					ws.send(sendd("请输入四字词哦"))


		# 如果飞花令开关开启
		if self.flower == True:

			# 获取特定位置的字
			z = len(pl) + 2
			v = str(pl).count("花")

			# 如果z列表的长度为9
			if z == 9:
				a = nn + str(pl).replace(',',n).replace('[\'','').replace('\']','').replace('\'',' ')
				b = n + nn + "by." + str(by).replace('[\'','').replace('\']','').replace('\'',' ')
				c = "（" + str(len(by)) + "）"
				time.sleep(ee)
				ws.send(sendd(a + b + c))
				time.sleep(ee)

				# 清空游戏数据并结束游戏
				by.clear()
				pl.clear()
				ga.clear()
				self.flower = False

				# 如果花字多于14个
				if v > 14:
					ws.send(sendd("游戏结束 天女散花x" + str(v)))

				else:
					# 直接结束
					ws.send(sendd("游戏结束 完美撒花"))
	
			# 排除bot的昵称
			elif nick + n not in bot:

				# z列表的长度不为9且P-存在的情况下
				if z != 9 and "P-" in text and str(text).count("-") == 1:

					# 如果文本长度为9
					if len(text) == 9:

						# 如果关键字在固定位置上
						if text[z] == "花":
							a = random.choice(["Perfect! ","Pretty! ","Great! ","Good! "])
							time.sleep(zz)
							pl.append(text[2:])
							time.sleep(zz)

							# 如果昵称不在by中
							if nick not in by:
								by.append(nick)

							# 如果z列表的长度不为8
							if z != 8:
								ws.send(sendd(a + "下句的关键词在第" + str(z) + "个字上"))

							# 如果z列表的长度为8
							if z == 8:
								ws.send(sendd("OK! 七句诗成功输出"))

						# 如果关键字没有在固定位置上
						elif text[z] != "花":
							time.sleep(zz)
							ws.send(sendd("关键词没在固定位置上哦"))
	
					else:
						# 文本长度不是9
						time.sleep(zz)
						ws.send(sendd("请输入七言律诗"))


	def onlineadd(self):

		# 简化和设定部分
		n = "\n"
		jo = self.join
		nick = self.data["nick"]

		a = "hello {}".format(nick)
		b = "hi {}".format(nick)
		c = "hey {}".format(nick)
		d = "hi yo {}".format(nick)
		e = "hey yo {}".format(nick)
		f = "{}!".format(nick)

		with open("record/join.txt","r") as fp:
			time.sleep(0.25)
			jn = fp.readlines()

			if nick + n in jn:
				with open("record/E/" + nick + ".txt","r") as fpp:
					ck = fpp.read()

					# 如果欢迎语被重置了
					if ck == "":
						ws.send(sendd(random.choice([d,e,f])))

					else:
						ws.send(sendd(ck))
						fp.close()
						fpp.close()

			# 如果此用户来过聊天频道
			elif nick in jo:
				ws.send(sendd(random.choice([d,e,f])))

			else:
				# 昵称是第一次出现
				ws.send(sendd(random.choice([a,b,c,f])))
				jo.append(nick)


	def onlineremove(self):
		pass


	def onlineset(self):
		pass


	def warn(self):
		text = self.data["text"]

		# 发送错误信息
		if "/" not in text:
			time.sleep(0.25)
			ws.send(sendd(text))


	def whisper(self):
		if "from" in self.data:
			nick = self.data["from"]

			# 私聊功能研究中……
			time.sleep(0.25)
			ws.send(sendd("/w " + nick + " 怎么啦" + nick + " 暂不支持私聊哦"))


class main:
	def __init__(self,room,name,pas):

		# 设定部分
		self.runbox = runbox(room,name,pas)
		self.room = self.runbox.room
		self.name = self.runbox.name
		self.pas = self.runbox.pas


	def askmsg(self,ws):

		# 通过eb发信息
		with open("record/send.txt","r+") as fp:
			chat = fp.read()
			if chat != "":
				ws.send(sendd(chat))
				fp.truncate(0)
		

	def on_message(self,ws,message):

		# 获取文本信息
		n = "\n"
		js = json.loads(message)
		self.runbox.handle(js)


		# 如果有人说话
		if js["cmd"] == "chat":
			a = n + js["nick"] + " said：" + n + js["text"]
			print(a + n)


		# 如果有人加入聊天室
		if js["cmd"] == "onlineAdd":
			a = n + "-joined" + n + js["nick"]
			print(a + n)


		# 如果有人离开聊天室
		if js["cmd"] == "onlineRemove":
			a = n + "-left" + n + js["nick"]
			print(a + n)


		# 如果服务器发生错误
		if js["cmd"] == "warn":
			a = n + "-error" + n + js["text"]
			print(a + n)


		# 如果接收到私聊
		if js["cmd"] == "info" and js.get("type") == "whisper":
			a = n + js["text"].replace(': ','：' + n)
			print(a + n)


		# 向聊天室自动回复消息
		if js["cmd"] == "onlineSet":
			onlineuser = "Onlineuser:"
			for e in js["nicks"]:
				if e != js["nicks"][-1]:
					onlineuser = onlineuser + e + ","

				else:
					onlineuser = onlineuser + e


	def on_error(self,ws,error):
		pass
	

	def on_close(self,ws):
		pass
	

	def on_open(self,ws):

		self.a = threading.Thread(target = self.askmsg,args=(ws,)) 
		self.a.start()

		# 连接上服务器了则调用
		n = "\n"
		nn = "·\n"
		room = self.room
		name = self.name
		pas = self.pas

		api = "https://api.iyk0.com/jr/"
		se = requests.get(api)
		res = se.json()
		a = json.dumps({"cmd":"join","channel":room,"nick":name,"password":pas})
		hi = random.choice(["hello","hi","hey","hi yo","hey yo"])
		ws.send(a)

		if room != "xq102210":
			ws.send(sendd("/color 44FF00"))

		time.sleep(0.25)
		ws.send(sendd(hi + " this is " + name))
		time.sleep(0.5)
		ws.send(sendd(nn + res["today"].replace('，','！') + n + "想了解更多玩法 请输入「功能」"))


if __name__ == "__main__":
	
	# 设定频道、bot名称、bot密码
	ts = "test"
	xq = "xq102210"
	cn = "chinese"
	hw = "homework"
	yc = "your-channel"
	ycl = "your-channell"
	lrs = "langrensha"

	main = main(room = xq,name = "eebot",pas = "纸片君")

	# 连接聊天室
	hc = "wss://hack.chat/chat-ws"
	cc = "wss://ws.crosst.chat:35197"
	xc = "ws://xq.kzw.ink:6060"
	xcc = "wss://xq.kzw.ink/ws"
	websocket.enableTrace(True)
	ws = websocket.WebSocketApp(xc,on_message = main.on_message,on_error = main.on_error,on_close = main.on_close)
	ws.on_open = main.on_open 
	ws.run_forever()
