import websocket
import json
import time
import random
import sys
import os


# 常用聊天室ws地址：hack.chat 十字街 XChat
ws_hc,ws_cc,ws_xc,ws_xcc="wss://hack.chat/chat-ws","wss://ws.crosst.chat:35197","ws://xq.kzw.ink:6060","wss://xq.kzw.ink/ws"

# 常用聊天室ws地址：Tchat 冬日小屋 zzChat
ws_tc,ws_tcc,ws_sc,ws_zc="ws://chat.thz.cool:6060","wss://chat.thz.cool/chat-ws","wss://sprchatport.run.goorm.io","wss://zzchat.cf/wss"

# 常用聊天室名称
hc,cc,xc,tc,sc,zc="hack.chat","十字街","XChat","Tchat","冬日小屋","zzChat"

# 常用频道
ma,ts,xq,cn,pu,lo,yc,ycl,ccc,bot="main","test","xq102210","chinese","public","lounge","your-channel","your-channell","公共聊天室","bot"


# 设置聊天室ws地址
socket1=ws_xcc

# 设置聊天室名称
chatroom1=xc

# 设置频道名称
channel1=xq


# bot名字
botname="eebot"+str(random.randint(1,999))


# 匿名函数 chat备用
send=lambda text:json.dumps({'cmd':'chat','text':str(text)})

# 匿名函数 join
join=lambda chan,name:json.dumps({"cmd":"join","channel":chan,"nick":name,"password":"4lNXADr3gfQM85cqRJw","token":"papereebot","client_key":"papereebot"})
	

try:
	# 连接聊天室
	ws=websocket.WebSocket()
	ws.connect(socket1)

except:
	# 自动重启
	time.sleep(30)
	py=sys.executable
	os.execl(py,py,*sys.argv)


# 表示开始
ww=time.strftime("%Y.%m.%d %H:%M:%S",time.localtime())
ws.send(join(channel1,botname))
print(f"[Started] {ww}")


# 循环判定
while True:

	# 保存文件的时间
	emit=time.strftime("%H:%M:%S",time.localtime())
	chat=time.strftime("%Y.%m.%d")
	write=open(f"[chats]\\[{chatroom1}]\\{chat}_{channel1}.txt","a+")

	try:
		# 接收到的json数据
		wss=json.loads(ws.recv())

	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	if "cmd" in wss:
		cmd=wss["cmd"]

		if cmd=="onlineSet":
			aa=str(wss["nicks"]).replace("'","").replace("[","").replace("]","")
			print(f"[Online] {aa}\n")
			print("[Records]")

		elif cmd=="onlineAdd":
			nick=wss["nick"]
			print(f"[{emit}]\n{nick} joined\n")

		elif cmd=="onlineRemove":
			nick=wss["nick"]
			print(f"[{emit}]\n{nick} left\n")

		elif cmd=="chat":
			nick,text,leve=wss["nick"],wss["text"],wss["level"]
			bb=''

			# bot私聊用
			per=f"/w {nick} .\n·\n"

			if "trip" in wss and wss["trip"].strip()!='':
				trip=wss["trip"]
				bb=f"[{trip}] {nick}\n{text}"

			else:
				bb=f"[None] {nick}\n{text}"

			dd=f"[{emit}]\n{bb}\n"
			print(dd)

			try:
				write.write(f"{dd}\n")

			except:
				pass

	time.sleep(0.2)
