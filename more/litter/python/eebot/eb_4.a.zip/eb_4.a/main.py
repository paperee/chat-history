import websocket
import json
import time
import random
import sys
import os
import threading


# 常用聊天室ws地址：hack.chat 十字街 XChat
ws_hc,ws_cc,ws_xc,ws_xcc="wss://hack.chat/chat-ws","wss://ws.crosst.chat:35197","ws://xq.kzw.ink:6060","wss://xq.kzw.ink/ws"

# 常用聊天室ws地址：Tchat 冬日小屋 zzChat
ws_tc,ws_tcc,ws_sc,ws_zc="wss://chat.thz.cool/chat-ws","wss://chat.thz.cool/chat-ws","wss://sprchatport.run.goorm.io","wss://zzchat.cf/wss"

# 常用聊天室名称
hc,cc,xc,tc,sc,zc="hack.chat","十字街","XChat","Tchat","冬日小屋","zzChat"

# 常用频道
ma,ts,xq,cn,pu,lo,yc,ycl,ccc,bot="main","test","xq102210","chinese","public","lounge","your-channel","your-channell","公共聊天室","bot"

# bot名字
botname="ee"

# 跨服消息列表
tsmit={}


# text: 信息
def send(text):
	return json.dumps({'cmd':'chat','text':str(text)})


# 表示开始
print("\n[Started] "+time.strftime("%Y.%m.%d %H:%M:%S",time.localtime()))


def room1(socket,chatroom,channel):
	try:
		# 连接聊天室
		ws=websocket.WebSocket()
		ws.connect(socket)
	
	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	# 加入聊天室
	ws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":"4lNXADr3gfQM85cqRJw"}))
	ws.send(send("/color 44FF00"))
	
	def room1_1():

		# 自动叉叉
		uwu=True
		
		# 循环判定
		while True:
		
			# 保存文件的时间
			emit=time.strftime("%H:%M:%S",time.localtime())
			chat=time.strftime("%Y.%m.%d")
		
			try:
				# 接收到的json数据
				wss=json.loads(ws.recv())
		
			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)
		
			if "cmd" in wss:
				cmd=wss["cmd"]
		
				if cmd=="onlineAdd" and uwu==True:
					nick=wss["nick"]
					
					if "XC_" in nick:
						ws.send(send(f"/w mbot kick {nick}"))
		
				elif cmd=="chat":
					nick=wss["nick"]
					text=wss["text"]
					bb=''
		
					if nick!=botname and nick not in ["bo_od","zzChumo"] and "anti_integration" not in nick:
						if "trip" in wss and wss["trip"].strip()!='':
							trip=wss["trip"]
							bb=f"[{trip}] {nick}\n{text}"
							
							if trip=="eYFDHl":
								if text in ["paperee","paper","ee"]:
									try:
										paper=open(f"[notes]/{chat}_notebook.txt","r").read()
										ws.send(send(paper))
										
									except:
										ws.send(send("[自动回复]\n笔记本是空的"))
										
								elif text=="*open":
									uwu=True
									ws.send(send("[自动回复]\n见到XC_开头的昵称就叉出去"))
									
								elif text=="*close":
									uwu=False
									ws.send(send("[自动回复]\n自动叉叉关闭了"))
			
						else:
							bb=f"[None] {nick}\n{text}"
			
						try:
							open(f"[chats]/[{chatroom}]/{chat}_{channel}.txt","a+").write(f"[{emit}]\n{bb}\n\n")
							tsmit["1"]=bb
			
						except:
							pass
							
						if f"@{botname} " in text:
							time.sleep(0.2)
							
							if text==f"@{botname} ":
								ws.send(send(f"[自动回复]\n如果我没及时回复就是在上学（周一到周五）\n所有@{botname} 的消息都会单独保存到笔记本\n有什么事就@{botname} 说吧 我周末会看的 uwu\n如果某天我掉线了 那就是服务器寄了"))
								
							else:
								ws.send(send(f"[自动回复]\n已经把留言塞到笔记本里了"))
								
							open(f"[notes]/{chat}_notebook.txt","a+").write(f"[{emit}]\n{bb}\n\n")

				elif cmd=="info" and wss.get("type")=="whisper":
					if "from" in wss:
						nick=str(wss["from"])
						text=wss["text"]
						tsmit["1"]=f"[{nick}]\n{text}"
	
			time.sleep(0.2)

	def room1_2():
		
		# 循环判定
		while True:
				
			if "2" in tsmit:
				try:
					ws.send(send(tsmit["2"]))
					del tsmit["2"]
					
				except:
					pass
	
			else:
				time.sleep(0.2)
			
	threading.Thread(target=room1_1).start()
	threading.Thread(target=room1_2).start()


def room2(socket,chatroom,channel):
	try:
		# 连接聊天室
		wws=websocket.WebSocket()
		wws.connect(socket)
	
	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	# 加入聊天室
	wws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname}))
	wws.send(send("/color 2D2D2D"))
	
	def room2_1():
	
		# 循环判定
		while True:
			try:
				# 接收到的json数据
				wwss=json.loads(wws.recv())
		
			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)
		
			if "cmd" in wwss:
				cmd=wwss["cmd"]
		
				if cmd=="chat":
					nick=wwss["nick"]
					text=wwss["text"]
		
					if nick!=botname and "trip" in wwss and wwss["trip"]=="eYFDHl" and text[0]!="-":
						if text[0]==" ":
							tsmit["2"]=text[1:]
							
						else:
							tsmit["2"]=text
		
			time.sleep(0.2)

	def room2_2():
		
		# 循环判定
		while True:
			
			if "1" in tsmit:
				try:
					wws.send(send(tsmit["1"]))
					del tsmit["1"]
					
				except:
					pass
				
			else:
				time.sleep(0.2)
			
	threading.Thread(target=room2_1).start()
	threading.Thread(target=room2_2).start()


# 同时启动两个聊天室
threading.Thread(target=room1,args=(ws_tc,tc,lo,)).start()
time.sleep(3)
threading.Thread(target=room2,args=(ws_hc,hc,"ycl",)).start()
