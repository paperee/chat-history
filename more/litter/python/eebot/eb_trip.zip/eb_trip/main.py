﻿# coding=utf-8
# python3 main.py

import websocket,json,time,random,sys,os

# 常用聊天室ws地址：hack.chat 十字街 XChat
ws_hc,ws_cc,ws_xc,ws_xcc="wss://hack.chat/chat-ws","wss://ws.crosst.chat:35197","ws://xq.kzw.ink:6060","wss://xq.kzw.ink/ws"

# 常用聊天室ws地址：Tchat 冬日小屋 zzChat
ws_tc,ws_tcc,ws_sc,ws_zc="ws://chat.thz.cool:6060","wss://chat.thz.cool/chat-ws","wss://sprchatport.run.goorm.io","wss://zzchat.cf/wss"

# 常用聊天室名称
hc,cc,xc,tc,sc,zc="hack.chat","十字街","XChat","Tchat","冬日小屋","zzChat"

# 常用频道
ma,ts,xq,cn,pu,lo,yc,ycl,ccc,bot,trip="main","test","xq102210","chinese","public","lounge","your-channel","your-channell","公共聊天室","bot","triptestawa"


# 识别码组合
l=open("main.txt","r").readlines()
x=random.randint(10,100)
y=random.sample(l,x)
z=''.join(y).replace('\n','')


# 设置聊天室ws地址
socket1=ws_hc

# 设置聊天室名称
chatroom1=hc

# 设置频道名称
channel=ts

# 设置bot昵称
botname="eebot"+str(random.randint(1,999))

# 设置bot密码
botpass=z


# 连接聊天室
ws=websocket.WebSocket()
ws.connect(socket1)
ws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botpass}))
ww=time.strftime("[Started-run1] %Y.%m.%d %H:%M:%S",time.localtime())
print(ww)


while True:

	# 接收到的json数据
	wss=json.loads(ws.recv())

	if "cmd" in wss:
		cmd=wss["cmd"]

		if cmd=="warn":
			time.sleep(30)

		elif cmd=="onlineSet":
			aa=wss["users"][-1]["trip"]
			bb=f"[{aa}]\n{botpass}\n\n"

			if aa.isalpha()==True:
				if aa.isupper()==True or aa.islower()==True or aa.istitle()==True:
					cc=open(f"[pass]/[{chatroom1}]/[A].txt","a+")
					cc.write(bb)
					cc.close()

				else:
					cc=open(f"[pass]/[{chatroom1}]/[B].txt","a+")
					cc.write(bb)
					cc.close()

			elif aa.isnumeric()==True:
				cc=open(f"[pass]/[{chatroom1}]/[A].txt","a+")
				cc.write(bb)
				cc.close()

			else:
				cc=open(f"[pass]/[{chatroom1}]/[C].txt","a+")
				cc.write(bb)
				cc.close()

	try:
		# 自动重启代码
		time.sleep(10)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	except:
		time.sleep(60)
		py=sys.executable
		os.execl(py,py,*sys.argv)
