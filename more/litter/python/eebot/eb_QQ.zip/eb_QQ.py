import botpy
from botpy import logging,BotAPI,Intents,Client
from botpy.user import Member
from botpy.message import Message
from botpy.ext.command_util import Commands
from time import strftime,localtime,sleep
from datetime import datetime

log=logging.get_logger()
config={"appid":"","secret":"","name":"eebot","nick":"eb","master":"ee","push":}

@Commands("help","帮助")
async def help(api:BotAPI,message:Message,params:None):
    return await message.reply(content="查看所有指令：help/帮助\n查看个人资料：info/信息\n查看时间：time/时间\n查看机器人介绍：about/关于")

@Commands("info","信息")
async def info(api:BotAPI,message:Message,params:None):
    joined=message.member.joined_at.split('T')
    return await message.reply(content=f"你的昵称：{message.author.username}\n加入时间：{joined[0]} {joined[1].split('+')[0]}")

@Commands("time","时间")
async def time(api:BotAPI,message:Message,params:None):
    return await message.reply(content=strftime("现在时间：%Y-%m-%d %H:%M:%S",localtime()))

@Commands("about","关于")
async def about(api:BotAPI,message:Message,params:None):
    return await message.reply(content=f"{config['name']}路过 也可以被称作{config['nick']}哦~\n在此代表制作人{config['master']}祝{message.author.username}玩得愉快！")

class eebot(Client):
    def valid_time(uwu,now=datetime.now().time()):
        return now<=datetime.strptime('00:00:00','%H:%M:%S').time() or now>=datetime.strptime('06:00:00','%H:%M:%S').time()

    def post(uwu,content,to=config["push"]):
        if uwu.valid_time():
            return uwu.api.post_message(to,content=content)
    
    async def on_ready(uwu):
        return await uwu.post(f"{config['nick']}准备好了！")

    async def on_guild_member_add(uwu,member:Member):
        return await uwu.post(f"欢迎{member.nick}加入频道！")
    
    async def on_at_message_create(uwu,message:Message):
        log.info(message)

        for handler in [help,info,time,about]:
            if await handler(api=uwu.api,message=message):
                return

        await message.reply(content="uwu")

if __name__ == "__main__":
    client=eebot(intents=Intents(public_guild_messages=True))
    client.run(appid=config["appid"],secret=config["secret"])