# *coding: UTF-8 *-

from json import dumps
from requests import post
from random import choice,randint
from re import sub,match,search
from colorama import init,Fore,Style

class eebot():
	def __init__(eb):
		eb.name="eebot"
		eb.nick="eb"
		eb.user="ee"
		eb.meme=["uwu"]
		eb.back=["哼哼哼啊啊啊","真的假的？","大概吧","好嘛","诶嘿"]

		eb.loop()

	def pull(eb,food):
		if food[-1].isalpha() or food[-1].isdigit():
			if len(food)%2:
				food=food+choice(["（","）"])

			elif randint(0,1):
				food+=" "+choice(eb.meme)

		elif randint(0,1):
			food+=choice(eb.meme)

		return sub(r"[“”‘’'\"]","",food).replace("，"," ").replace(","," ").replace("。","~")

	def pull_(eb,nick,food):
		return food.replace("你太美","&#x4F60;太美").replace("你好","&#x4F60;好").replace("你们","大家").replace("我们","我和你").replace("你",nick).replace("我",eb.nick).replace("人家",eb.name).replace("啥","什么").replace("咋","怎么").replace("哦","啊").replace("嗯","嘿").replace("嘻","哈").replace("呵","哼").replace("&#x4F60;太美","你太美").replace("&#x4F60;好","你好")

	def pull__(eb,food):
		return sub(r"[!?！？、（）()]","",food)

	def guru(eb,food):
		data={
			"token":"ZWVib3RZWURTLGxldHMgcmVzdGFydCBoZXIh",
			"context":dumps([food]),
			"p":0.5,"k":20,"t":0.5,"lp":1.5,
		}

		try:
			msg=post("http://8.140.116.233:8093/dialog",data=data,timeout=99).json()["msg"]

		except:
			msg=choice(eb.back+eb.meme)

		if "�" in msg or len(msg)>20:
			return choice(eb.back+eb.meme)

		return msg

	def send(eb,food):
		print("["+Fore.GREEN+f"{eb.name}{Style.RESET_ALL}] {food}\n")

	def loop(eb):
		nick=input("[你的昵称] ").strip() or "你"
		eb.send(f"好耶 这里是{eb.name}！")

		while True:
			text=input(f"[{nick}] ")
			text_=text.replace(" ","")
			text__=eb.pull__(text_)

			if not text_:
				msg=choice(["你有事吗","好耶 是你","欢迎和我聊天",f"找{eb.user}去吧"])

			elif text__ in ["yo","hi","hey","hello"]:
				msg=text_

			elif match(r"^[a-zA-Z]{3}$",text__) and text__[0]==text__[2]:
				msg=choice(eb.meme)

			elif search(r"^[hiyo]+$",text__):
				msg="hi y"+"o"*randint(1,9)

			elif search(r"^[guru]+$",text__):
				msg="guru"*randint(1,9)

			elif search(r"^[wuhu]+$",text__):
				msg="wuh"+"u"*randint(1,9)

			elif search(r"^[……,.，。、]+$",text_):
				msg=choice(["沉默总令人尴尬","哈哈 该说点什么好","不说话便是最好的回答","可爱的我来捧场了！","我死亡凝视ing"])

			else:
				msg=eb.guru(text__)

			eb.send(eb.pull(eb.pull_(nick,msg)))

init()

print("["+Fore.GREEN+f'''AIeebot{Style.RESET_ALL}]
Ver.uwu.1.00 By.Paperee
Date.2023-07-30

历时一年半 eebot终不再是Bot 而步入了AI阶段
这一路走来 少不了网友们的支持和鼓励

以下是感谢名单：
为初版eebot提供了Bot框架的Light 让eebot得以诞生
为本版eebot训练了GPT2模型的MelonFish 让AIeebot得以诞生
为本版eebot编写了eblib补丁的Maggie 让AIeebot得以优化
为训练本版eebot提供了技巧和灵感的yu22c和HelloOSMe
使用C#移植eebot的PaperDr0
以及使用NodeJS移植eebot的MrZhang365
更多我在互联网聊天室上遇到的伙伴-
''')

eebot()