from difflib import SequenceMatcher
from json import load,dump
from codecs import open

replies:dict

def load_data():
    global replies
    replies=load(open("dict.json","r","UTF-8-sig"))

def write_data():
    dump(replies,open("dict.json","w+","UTF-8-sig"))

load_data()

def similarity(a,b):
    return SequenceMatcher(None,a,b).ratio()

def add_new_reply(q,a):
    replies.update({q:a})
    write_data()

def call(q,callback=lambda x:"未指定escape callback",escape_value=0.8):
    max_val=(0,None)

    for i in replies.items():
        if similarity(i[0],q)>max_val[0]:
            max_val=(similarity(i[0],q),i[1])

    if max_val[0]<escape_value:
        return callback(q)
        
    return max_val[1]