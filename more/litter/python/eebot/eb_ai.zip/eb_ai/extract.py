import os
import re

list_=[]

# 遍历文件夹中的所有文件
for filename in os.listdir("[chat]"):
    Q=filename.replace(".txt","").replace("eebot","你").replace("eb","你")
    A=open("[chat]/"+filename,"r").read().split("\n")[0].replace("~","").replace(" ","").replace(",","，").replace("）","").replace("（","")

    if "](" not in A and "https" not in A and "^" not in A and 2<len(Q)<20 and 2<len(A)<20:
        list_.append([Q,A])

print(list_)
print(len(list_))