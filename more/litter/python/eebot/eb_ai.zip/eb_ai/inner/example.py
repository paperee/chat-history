import requests as req
import json

## 这里定义一些需要的配置
k = 20 # 这里对应的是top_k，为一个整数。意思是算法保留多少个最高概率的词作为候选。默认值为20，调整这个参数可以让回答有不同效果。
p = 0.5 # 对应top_p，为一个小数，默认值为0.45。已知生成各个词的总概率是1，如果top_p小于1，则从高到低累加直到top_p，取这前N个词作为候选。
t = 0.5 # 对应temperature，为一个小数，默认值为0.6。如果调试过程中发现模型胡言乱语，可以尝试修改这个值。
lp = 1.5 # 对应length_penalty，为一个小书。默认值为-0.3。若大于0鼓励模型生成短句子，小于0鼓励模型生成长句子。
# 以上参数可以不用传递，如果不传递则使用默认值。如果有兴趣建议尝试调整，可能会有更好的效果。


max_steps = 1 # 设置最长历史记录数量，也就是api考虑的历史记录个数，最长为10，大于10服务器将自动截断。
history_list = [] # 一个列表用于存放历史记录
while True:
    user_input = input('User >>> ')
    if user_input == '': # 输入为空跳出循环
        break
    history_list.append(user_input)
    
    if len(history_list)>=max_steps: # 手动截断，服务器上也是这样的代码。
        history_list = history_list[len(history_list)-max_steps:]
    
    send_data = {'token':'ZWVib3RZWURTLGxldHMgcmVzdGFydCBoZXIh', 'context':json.dumps(history_list), 'p':p,'k':k,'t':t,'lp':lp}# 构造请求
    d = req.post('http://8.140.116.233:8093/dialog',data=send_data).json() # 发送请求，这里使用post（因为get请求有长度限制）
    d = d['msg']
    history_list.append(d) # 记得要把机器人回答的内容也加入历史记录列表
    if '�' in d: # 因为当出现�符号的时候通常模型的回复都会开始有问题，所以判断一下，有这个内容就直接清空历史记录
        history_list = []
    print('Robot >>> ', d) # 输出啦

