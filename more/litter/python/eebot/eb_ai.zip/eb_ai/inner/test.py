# *coding: UTF-8 *-

from websocket import WebSocket
from json import dumps,loads
from time import sleep
from requests import post
from random import choice,randint
from re import findall,sub
# from POE import load_chat_id_map,clear_context,send_message,get_latest_message,set_auth
'''
set_auth("Quora-Formkey","32b5813ea10ee14257dfa6792e729b40")
set_auth("Cookie","m-b=8gpNgpuWTs-2J5CxhLo9rA==")
'''
class eebot():
	def __init__(eb):
		eb.goto="wss://chat.zhangsoft.link/ws"
		eb.pack={
			"channel":"bot",
			"nick":"eebot",
			"name":"eb",
			"password":"13ee",
			"head":"https://chat.zhangsoft.cf/imgs/head.png",
			"client":"papereescomputer",
			"color":"44FF00",
		}
		'''
		eb.bots={
			"sage":"capybara",
			"gpt":"chinchilla",
			"fly":"nutria",
			"claude":"a2",
		}
		'''
		eb.history=[]
		eb.meme=["uwu","uvu","ouo"]
		eb.backup=["哼哼哼啊啊啊","真的假的？","好嘛","诶嘿"]
		eb.len=len(eb.backup)
		# eb.reset()
		eb.connect()
	'''
	def reset(eb):
		uwu=load_chat_id_map("chinchilla")
		clear_context(uwu)
		send_message('从现在开始，我会给你发句子，请判断句子是否包含类似"你有什么功能"的意思，如果是就返回"True"，如果不是就返回"False"。请注意，你不能返回除了"True"或"False"外多余的内容(包括介绍)，你只能返回"True"或"False"。如果明白，请回复"True"',"chinchilla",uwu)
	'''
	def pull(eb,text):
		if "\u4e00"<=text[-1]<="\u9fa5":
			if len(text)%2:
				text=text+choice(["（","）"])

			elif randint(0,1):
				text+=" "+choice(eb.meme)

		elif randint(0,1):
			text+=choice(eb.meme)

		return sub(r"[“”‘’'\"]","",text).replace("，"," ").replace("。","~")

	def pull_(eb,nick,text):
		return text.replace("你好","&#x4F60;好").replace("你们","大家").replace("我们",f"{eb.pack['name']}和{nick}").replace("你",nick).replace("我",eb.pack["name"]).replace("啥","什么").replace("咋","怎么").replace("哦","啊").replace("嗯","嘿")

	def pull__(eb,text):
		return sub(r"[！？、（）]","",text)

	def guru(eb,text):
		text="".join(findall(r"[\u4e00-\u9fa5\u3000-\u303f\uff01-\uff5e]",text))
		'''
		send_message(text,"chinchilla",load_chat_id_map("chinchilla"))
		last=get_latest_message("chinchilla")

		if text in ["功能","帮助","介绍","手册"] or last=="True":
			return f"{eb.pack['name']}的功能：\n@{eb.pack['nick']} 文本：和{eb.pack['name']}聊天"

		elif last!="False":
			eb.reset()
		'''
		eb.history=[*eb.history[-9:],text]
		# "p":0.5,"k":20,"t":1.5,"lp":-1,
		data={
			"token":"ZWVib3RZWURTLGxldHMgcmVzdGFydCBoZXIh",
			"context":dumps(eb.history),
			"p":0.5,"k":20,"t":0.5,"lp":1.5,
		}

		try:
			msg=post("http://8.140.116.233:8093/dialog",data=data).json()["msg"]
			eb.history.append(msg)

		except:
			msg=choice(eb.backup)

		if "�" in msg or len(msg)>20:
			eb.history=[]
			msg=choice(eb.backup+eb.meme)

		if msg in eb.history[:-1]:
			msg=eb.guru(text)

		return msg

	def join(eb):
		eb.ws.send(dumps({"cmd":"join",**eb.pack}))

	def skin(eb):
		eb.ws.send(dumps({"cmd":"changecolor","color":eb.pack["color"]}))

	def send(eb,text):
		eb.ws.send(dumps({"cmd":"chat","text":str(text)}))

	def loop(eb):
		while True:
			data=loads(eb.ws.recv())
			cmd=data.get("cmd")

			if cmd=="chat":
				text=data.get("text")
				nick=data.get("nick")

				print(f"[{nick}] {text}")

				if nick!=eb.pack["nick"]:
					if "\n" not in text and eb.pull__(eb.pull(text)).isalpha():
						if 2<len(text)<=20:
							eb.backup.append(eb.pull(text))

						if len(eb.backup)==50:
							eb.send(eb.pull_(nick,choice(eb.backup+eb.meme)))
							eb.backup.append("uwu")

						if len(eb.backup)==100:
							eb.backup=eb.backup[:eb.len]
							eb.send(eb.pull(eb.pull_(nick,text)))

					if f"@{eb.pack['nick']} " in text or text.endswith(f"@{eb.pack['nick']}"):
						eb.send(eb.pull(eb.pull_(nick,eb.guru(text))))

			sleep(0.2)

	def error(eb):
		sleep(20)
		print("[Error]")

		eb.connect()

	def connect(eb):
		try:
			eb.ws=WebSocket()
			eb.ws.connect(eb.goto)

			print("[Success]")

			eb.join()
			sleep(2)
			eb.skin()
			eb.loop()

		except:
			eb.error()

if __name__=="__main__":
	eebot()