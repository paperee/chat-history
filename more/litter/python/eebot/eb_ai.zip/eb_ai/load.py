# *coding: UTF-8 *-

from json import dumps,loads
from requests import post
from codecs import open

# load_last_saved_model remove_model

uwu="load_last_saved_model"

print(open("save_id.txt","r","UTF-8-sig").read())

url=f"http://8.140.116.233:8093/dialog/{uwu}"
data={
    "token":"ZWVib3RZWURTLGxldHMgcmVzdGFydCBoZXIh",
    "save_id":"1690717158",
}

res=post(url,data=data,timeout=99999).json()
print(res)