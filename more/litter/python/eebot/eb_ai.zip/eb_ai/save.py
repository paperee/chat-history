# *coding: UTF-8 *-

'''
1V66Z5 Fin
第一个是reset_model和save_model后会返回一个save_id，这个id可以存一下，是保存的时间戳
save_model会把模型保存为一个新的文件，不覆盖原有的，但最多可以保存10个，超过10个则会删掉最早的那个

1V66Z5 Fin
第二个是，load_last_saved_model仍然可以用，用法相同
新增了一个save_model，需要提供一个save_id参数，把save_model或reset_model的save_id传进去。
时间戳是秒的，用time.time()去小数生成的

1V66Z5 Fin
等等，模型一次保存最多占用2个g，kzw的硬盘是2个t的，只用了1.1个t，意味着还有900g空间，我用掉100个g应该没问题，所以应该可以存50个

1V66Z5 Fin
（刚好你可以随便训练一点乱七八糟的数据然后试试保存再加载，是不是加载了想要加载的模型
以及load_last是否会加载最后那个模型
'''

from json import dumps,loads
from requests import post
from codecs import open

# save_model reset_model

uwu="save_model"
url=f"http://8.140.116.233:8093/dialog/{uwu}"
data={
    "token":"ZWVib3RZWURTLGxldHMgcmVzdGFydCBoZXIh",
}

res=post(url,data=data,timeout=99999).json()
print(res)

open("save_id.txt","a+","UTF-8-sig").write(res["save_id"]+"\n")