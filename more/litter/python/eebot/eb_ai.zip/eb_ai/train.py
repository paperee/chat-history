import os
import re

list_=[]

# 遍历文件夹中的所有文件
for dir_ in os.listdir():
    if not dir_.endswith(".py") and not dir_.endswith(".txt"):
        for filename in os.listdir(dir_):
            if filename!="[stat]":
                try:
                    uwu=open(dir_+"/"+filename,"r").read().split("\n\n[")

                    for chat in uwu:
                        if ">" in chat and ">>" not in chat:
                            try:
                                uwu_=chat.replace("~","").replace("nb","牛").replace("哈","").split("\n")
                                Q="".join(re.findall(r"[\d\u4e00-\u9fa5？！]",uwu_[3]))
                                A="".join(re.findall(r"[\d\u4e00-\u9fa5？！]",uwu_[-1]))
                                QA=[Q,A]

                                if QA not in list_ and Q!=A and 4<len(Q)<20 and 2<len(A)<20 and not Q.isdigit() and not A.isdigit() and len(re.findall(r"[\d]",Q))<len(re.findall(r"[\u4e00-\u9fa5]",Q)) and len(re.findall(r"[\d]",A))<len(re.findall(r"[\u4e00-\u9fa5]",A)):
                                    list_.append(QA)

                            except:
                                pass

                except:
                    pass

print(list_)
print(len(list_))