# *coding: UTF-8 *-

'''

[AIeebot]
Ver.uwu.1.00 By.Paperee
Date.2023-07-30

历时一年半 eebot终不再是Bot 而步入了AI阶段
这一路走来 少不了网友们的支持和鼓励

以下是感谢名单：
为初版eebot提供了Bot框架的Light 让eebot得以诞生
为本版eebot训练了GPT2模型的MelonFish 让AIeebot得以诞生
为本版eebot编写了eblib补丁的Maggie 让AIeebot得以优化
为训练本版eebot提供了技巧和灵感的yu22c和HelloOSMe
使用C#移植eebot的PaperDr0
以及使用NodeJS移植eebot的MrZhang365
更多我在互联网聊天室上遇到的伙伴-

'''

from websocket import WebSocket
from json import dumps,loads
from time import sleep
from requests import post
from random import choice,randint
from re import findall,sub,match,search
from threading import Thread

import eblib

class eebot():
	def __init__(eb,chatroom,channel):
		eb.chat={
			"HC":"wss://hack.chat/chat-ws",
			"ZHC":"wss://chat.zhangsoft.link/ws",
		}
		eb.room=chatroom.upper()
		eb.goto=eb.chat[eb.room]
		eb.name="eebot"
		eb.nick="eb"
		eb.user="ee"
		eb.pack={
			"channel":channel,
			"nick":eb.name+str(randint(18,57)),
			"password":"eebotIsCute",
			"head":"https://filebed.paperee.guru/templates/ee/eatFish.png",
			"client":"papereescomputer",
			"bot":True,
			"color":"44FF00",
		}
		eb.meme=["uwu"]
		eb.back=["哼哼哼啊啊啊","真的假的？","大概吧","好嘛","诶嘿"]
		eb.trip=["eYFDHl","1V66Z5","uwuu57","Zhang+","114514","k+R3I2","YuBFQG","AZ3jF7","8fVUfs"]
		eb.length=len(eb.back)

		eb.connect()

	def pull(eb,food):
		if food[-1].isalpha() or food[-1].isdigit():
			if len(food)%2:
				food=food+choice(["（","）"])

			elif randint(0,1):
				food+=" "+choice(eb.meme)

		elif randint(0,1):
			food+=choice(eb.meme)

		return sub(r"[“”‘’'\"]","",food).replace("，"," ").replace(","," ").replace("。","~")

	def pull_(eb,nick,food):
		return food.replace("你太美","&#x4F60;太美").replace("你好","&#x4F60;好").replace("你我","&#x4F60;我").replace("我你","我&#x4F60;").replace("你们","大家").replace("我们","我和你").replace("你",nick).replace("我",eb.nick).replace("人家",eb.name).replace("啥","什么").replace("咋","怎么").replace("哦","啊").replace("嗯","嘿").replace("嘻","哈").replace("呵","哼")

	def pull__(eb,food):
		return sub(r"[!?！？、（）()：]","",food)

	def guru(eb,food):
		data={
			"token":"ZWVib3RZWURTLGxldHMgcmVzdGFydCBoZXIh",
			"context":dumps([food]),
			"p":0.5,"k":20,"t":0.5,"lp":1.5,
		}

		try:
			msg=post("http://8.140.116.233:8093/dialog",data=data,timeout=99).json()["msg"]

		except:
			msg=choice(eb.back+eb.meme)

		if "�" in msg or len(msg)>20:
			return choice(eb.back+eb.meme)

		return msg

	def join(eb):
		eb.ws.send(dumps({"cmd":"join",**eb.pack}))

	def skin(eb):
		eb.ws.send(dumps({
			"cmd":"changecolor",
			"color":eb.pack["color"],
		}))

	def send(eb,food):
		eb.ws.send(dumps({
			"cmd":"chat",
			"text":str(food),
			"head":eb.pack["head"],
		}))

	def loop(eb):
		while True:
			data=loads(eb.ws.recv())
			cmd=data.get("cmd")

			if cmd=="onlineSet":
				print(f"[{eb.room}] [{eb.pack['channel']}] [Online] {' '.join(data.get('nicks'))}")

			elif cmd=="onlineAdd":
				nick=data["nick"]
				print(f"[{eb.room}] [{eb.pack['channel']}] [Join] {nick}")

				if eb.room=="ZHC" and not (data.get("bot") or data.get("isBot")):
					for i in range(randint(1,2)):
						sleep(randint(3,9)*0.1)
						eb.send(choice(["awa!","uwu!","来了老弟~","hi y"+"o"*randint(1,9)]))

				else:
					eb.send(choice(["hi","hi yo","hey","hey yo","hello"])+" "+nick)

			elif cmd=="onlineRemove":
				nick=data["nick"]
				print(f"[{eb.room}] [{eb.pack['channel']}] [Leave] {nick}")

			elif cmd=="emote":
				nick=data["nick"]
				text=data["text"]
				print(f"[{eb.room}] [{eb.pack['channel']}] [Emote] {nick}：{text.split(' ',1)[-1]}".replace("\n","\\n"))

			elif cmd=="chat":
				nick=data["nick"]
				text=data["text"]
				print(f"[{eb.room}] [{eb.pack['channel']}] [Chat] {nick}：{text}".replace("\n","\\n"))

				if nick!=eb.pack["nick"]:
					if "\n" not in text and eb.pull__(eb.pull(text)).isalpha():
						if 2<len(text)<=20:
							eb.back.append(eb.pull__(text))

						if len(eb.back)==25:
							msg=eb.pull(eb.pull_(nick,eb.guru(text)))
							eb.back.append(msg)
							eb.send(msg)

						if len(eb.back)==50:
							eb.back=eb.back[:eb.length]
							eb.send(eb.pull_(nick,choice(eb.back+eb.meme)))

					if f"@{eb.pack['nick']} " in text or text.endswith(f"@{eb.pack['nick']}"):
						text_=text.replace(" ","").replace("@","").replace(eb.pack["nick"],"")
						text__=eb.pull__(text_)
						trip=data.get("trip")

						if not text_:
							msg=choice(["你有事吗","好耶 是你",f"找{eb.user}去吧",f"欢迎到{eb.room}聊天",f"欢迎来{eb.pack['channel']}频道玩"])

						elif trip in eb.trip and text_.count("\n")>=2 and text_.split("\n")[0]=="学习：":
							uwu_=[uwu.split("\n")[:2] for uwu in text_.split("\n",1)[1].split("\n\n")]

							for uwu in uwu_:
								eblib.add_new_reply(*uwu)

							try:
								data={
									"token":"ZWVib3RZWURTLGxldHMgcmVzdGFydCBoZXIh",
									"train_data":dumps(uwu_),
									"epochs":"5",
								}
								json=post("http://8.140.116.233:8093/dialog/train",data=data,timeout=999).json()
								eb.send(f"/w {nick} >\n`{json}`")

								msg=choice(["我努力学习……学完了！","好耶 我记住了"])

							except:
								msg=choice(["我尝试学习 但是失败了","啊哈 不知道为何记不住"])

						elif trip in eb.trip and "\n" in text_ and text_.split("\n")[0]=="老师：":
							trip_=text.split("\n",1)[1]

							if len(trip_)==6:
								eb.trip.append(trip_)
								eb.send(f"/w {nick} >\n`{eb.trip}`")
								msg=choice(["我会向他看齐的！","好 我会努力跟着他学习"])

						elif text__ in ["yo","hi","hey","hello"]:
							msg=text_

						elif match(r"^[a-zA-Z]{3}$",text__) and text__[0]==text__[2]:
							msg=choice(eb.meme)

						elif search(r"^[hiyo]+$",text__):
							msg="hi y"+"o"*randint(1,9)

						elif search(r"^[guru]+$",text__):
							msg="guru"*randint(1,9)

						elif search(r"^[wuhu]+$",text__):
							msg="wuh"+"u"*randint(1,9)

						elif search(r"^[……,.，。、]+$",text_):
							msg=choice(["沉默总令人尴尬","哈哈 该说点什么好","不说话便是最好的回答","可爱的我来捧场了！","我死亡凝视ing"])

						else:
							msg=choice([eblib.call(text__,eb.guru),eb.guru(text__)])

						msg=eb.pull(eb.pull_(nick,msg))

						if msg[0] not in ["/","^"] and "\n" not in text and len(text)<20:
							if eb.room=="ZHC" and trip and  not randint(0,3):
								msg=f">[{trip}] {nick}：\n>"+"\n>".join(text.split("\n"))+"\n\n"+f"@{nick} {msg}"

							elif not randint(0,2):
								msg=f"@{nick} {msg}"

						eb.send(msg)
 
			sleep(0.4)

	def error(eb):
		print("[Error]")

		sleep(20)
		eb.connect()

	def connect(eb):
		try:
			eb.ws=WebSocket()
			eb.ws.connect(eb.goto)

			print("[Success]")

			eb.join()
			sleep(1)
			eb.skin()
			sleep(1)
			eb.send(f"好耶 这里是{eb.name}！")
			eb.loop()

		except:
			eb.error()

if __name__=="__main__":
	args=[("hc","guru"),("zhc","chat")]

	for arg in args:
		Thread(target=eebot,args=arg).start()
		sleep(1)