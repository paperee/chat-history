# *coding: UTF-8 *-

from json import dumps
from requests import post
from math import ceil
from time import sleep

# 每次上传的数据条数
num=15

# 每次上传后训练的次数
chs=5

# 每次上传完暂停的时间
slp=20

# 地址
url="http://8.140.116.233:8093/dialog/train"

# 数据
uwu=[]

# 写这玩意就跟写前端分页一样
for i in range(ceil(len(uwu)/num)):
    guru=uwu[i*num:min(i*num+num,len(uwu))]
    print(guru)

    data={
        "token":"ZWVib3RZWURTLGxldHMgcmVzdGFydCBoZXIh",
        "train_data":dumps(guru),
        "epochs":str(chs),
    }
    
    json=post(url,data=data,timeout=99999).json()
    print(json)

    sleep(slp)
    print()