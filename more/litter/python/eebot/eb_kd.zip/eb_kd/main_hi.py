import websocket
import json
import time
import random
import sys
import os


# ws地址
socket="ws://kedou.workerman.net:8280/"

# bot名字
botname=f"ee's eebot｜eb{str(random.randint(1,999)).zfill(3)}"

# 表情列表
umoji=['6','uwu','awa','ovo','uvu','ava','ouo','hi','hello','hey','yo','oh','nb','wow','woc','nice','wuhu','guru','yep','why','what']

# 次数
times=0


try:
	ws=websocket.WebSocket()
	ws.connect(socket)

except:
	time.sleep(30)
	py=sys.executable
	os.execl(py,py,*sys.argv)


def move(x,y,momentum,angle,sex,color='4F0'):
	return json.dumps({"type":"update","x":x,"y":y,"momentum":momentum,"angle":angle,"sex":sex,"icon":f"/images/default.png?Color=#{color}","name":botname})

def send(text):
	return json.dumps({"type":"message","message":str(text)})


ws.send(move(0,0,10,random.randint(0,360),-1))
ws.send(send("hihihi This is ee's eebot uwu"))
print(f"[Started] {time.strftime('%Y.%m.%d %H:%M:%S',time.localtime())}")


while True:
	try:
		if random.randint(0,999)==57:
			ws.send(send(random.choice(umoji)))

		time.sleep(0.1)
		ws.send(move(random.randint(0,100),random.randint(0,100),random.randint(5,20),random.randint(0,360),-1,f'{random.randint(0,9)}F{random.randint(0,9)}'))

		times+=1
		print(f"[{times}]")

	except:
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)
