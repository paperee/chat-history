import websocket
import json
import time
import random
import sys
import os


# ws地址
socket="ws://kedou.workerman.net:8280/"

# bot名字
botname=f"ee's eebot"

# 聊天数据
textlist=[]

# 表情列表
umoji=['6','uwu','awa','ovo','uvu','avu','ouo','QuQ','QAQ','nb','nice','wuhu','guru','[paperee.guru]']


try:
	ws=websocket.WebSocket()
	ws.connect(socket)

except:
	time.sleep(30)
	py=sys.executable
	os.execl(py,py,*sys.argv)


def move(x,y,angle):
	return json.dumps({"type":"update","x":x,"y":y,"angle":angle,"sex":-1,"icon":"/images/default.png?Color=#44FF00","name":botname})

def send(text):
	return json.dumps({"type":"message","message":str(text)})

def retext(text):
	return text.replace('“','').replace('”','').replace('"','').replace('，',' ').replace('。',' ').strip()

def retext_(text):
	return text.replace('我们',f"蝌蚪们").replace('我','eb')

def retext__(text):
	return text.replace(' ','').replace('！','').replace('？','').replace('、','').replace('（','').replace('）','')


ws.send(move(0,0,random.randint(0,360)))
ws.send(send("hihihi This is ee's eebot uwu"))
print(f"[Started] {time.strftime('%Y.%m.%d %H:%M:%S',time.localtime())}")


while True:
	try:
		wss=json.loads(ws.recv())

	except:
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	if wss['type']=='message':
		text=wss['message']
		print(text)

		if "\n" not in text and retext__(retext(text)).isalpha()==True:
			if 5<len(text)<=20:
				textlist.append(retext(text))

			# te长度为25时bot随机输出te内容
			if len(textlist)==25:
				text_=random.choice(textlist)
				ws.send(send(text))

			# te长度为50时bot复读一句话
			if len(textlist)==50:
				text_=retext(retext_(text))
				meme=random.choice(umoji)
				ws.send(send(random.choice([text_,meme])))
				textlist.clear()

		if text in umoji and random.randint(1,2)==1:
			ws.send(send(random.choice(umoji)))

		elif text.lower() in ['hi','hello','hey','yo','why','who','what','where','how','which','yep','嗨','你好'] and random.randint(1,2)==1:
			ws.send(send(text))

		elif text[-1] in ['?','？'] and len(text)>2 and random.randint(1,int(len(text)))==1:
			ws.send(send(random.choice(["蛤","哦吼","阿瓦","阿巴阿巴"])))

		elif text[0] in ["啊","哦","哈"] and text==text[0]*len(text) and random.randint(1,2)==1:
			ws.send(send(random.choice([f"{text}草",f"草{text}"])))

	ws.send(move(random.randint(0,57),random.randint(0,57),random.randint(0,360)))

	if random.randint(1,57)==57:
		ws.send(send(random.choice(umoji)))

	time.sleep(0.2)
