import websocket,requests,json,time,random,sys,os,re,datetime,sb,morse_code
from langconv import *
from threading import Thread


def online_code(text,nick,trip):

	# 引用函数外变量
	global botpass

	fp=open("variable.txt","r+")
	pf=fp.read()
	dk=os.listdir("record/[online] code")

	botpa=botpass
	botpass='no'
	code=text.replace("print","send").replace("    ","	").replace('“','"').replace('”','"').replace('‘',"'").replace('’',"'")

	if code=="cll":
		fp.truncate(0)
		fp.close()
		send("已清空所有变量")

	elif code=="all":
		if pf=='':
			send("目前还没有全局变量")

		else:
			send(f"所有全局变量如下：\n{pf}")

	elif code=='clear':
		if trip==None:
			send('请带上识别码后再查找存档-')

		elif f"{trip}.txt" in dk:
			a=open(f"record/[online] code/{trip}.txt","r+")
			a.truncate(0)
			send(f"已清空{nick}的个人存档")

		else:
			send(f"{nick}还没有存过档哦")

	elif code=='mine':
		if trip==None:
			send('请带上识别码后再查找存档-')

		elif f"{trip}.txt" in dk:
			a=open(f"record/[online] code/{trip}.txt","r").read()
			send(f"/w {nick} .\n{a}")
			time.sleep(0.2)
			send(f"已发送{nick}的个人存档")

		else:
			send(f"{nick}还没有存过档哦")

	elif "\n" in code:
		xx=code.split("\n",1)
		x1=xx[1]

		if xx[0]=='save':
			if trip==None:
				send('请带上识别码后再存档-')

			else:
				try:
					exec(pf+x1)
					time.sleep(0.2)
					send("代码运行成功")

					try:
						a=open(f"record/[online] code/{trip}.txt","a+")
						a.write(f"{x1}\n")
						a.close()
						send("存档成功")

					except:
						send("含有无法识别的字符 存档失败")

				except Exception as eee:
					send(eee)
					time.sleep(0.2)
					send("代码运行失败 存档失败")

		elif xx[0]=='load':
			if trip==None:
				send('请带上识别码后再存档-')

			elif f"{trip}.txt" in dk:
				try:
					a=open(f"record/[online] code/{trip}.txt","r").read()
					exec(pf+a+x1)
					time.sleep(0.2)
					send("代码运行成功")

				except Exception as eee:
					send(eee)
					time.sleep(0.2)
					send("代码运行失败")

			else:
				try:
					exec(pf+x1)
					time.sleep(0.2)
					send("代码运行成功")

				except Exception as eee:
					send(eee)
					time.sleep(0.2)
					send("代码运行失败")

		else:
			try:
				exec(pf+code)
				time.sleep(0.2)
				send("代码运行成功")

			except Exception as eee:
				send(eee)
				time.sleep(0.2)
				send("代码运行失败")

	else:
		try:
			exec(pf+code)
			time.sleep(0.2)
			send("代码运行成功")

			if "send" not in code and "=" in code and ";" not in code:
				try:
					fp.write(f"{code}\n")
					fp.close()
					send("变量已成功保存")

				except:
					send("无法写入 含有无法识别的字符")

		except Exception as eee:
			send(eee)
			time.sleep(0.2)
			send("代码运行失败")

	# 结束进程
	botpass=botpa
	sys.exit(0)


while True:

	# 常用聊天室ws地址
	ws_hc="wss://hack.chat/chat-ws"
	ws_cc="wss://ws.crosst.chat:35197"
	ws_xc="ws://xq.kzw.ink:6060"
	ws_xcc="wss://xq.kzw.ink/ws"
	ws_tc="ws://chat.thz.cool:6060"
	ws_tcc="wss://chat.thz.cool/chat-ws"
	ws_sc="wss://sprchatport.run.goorm.io"

	# 常用聊天室名称
	hc="hack.chat"
	cc="十字街"
	xc="XChat"
	tc="Tchat"
	sc="SprinkleChat"

	# 常用频道
	ma="main"
	ts="test"
	xq="xq102210"
	cn="chinese"
	fk="fuckmsg"
	tx="TEXT_xq102210"
	vd="VOICE_xq102210"
	yc="your-channel"
	ycl="your-channell"
	ccc="公共聊天室"
	bot="bot"


	# 设置聊天室ws地址
	socket1=ws_xc
	socket2=ws_hc

	# 设置聊天室名称
	chatroom1=xc
	chatroom2=hc

	# 设置频道名称
	channel1=xq
	channel2=yc


	# 设置xc头像
	head="https://s1.ax1x.com/2022/04/30/Oppn5n.png"

	# 设置bot昵称
	botname="eebot"

	# 设置bot密码
	botpass="纸片君"

	# bot的简称
	botnick="eb"

	# 使用者的称呼
	username="ee"

	# 昵称备用（勿改）
	rese=botname


	# 手动发消息开关
	sendms=True

	# 时间线开关
	timeline=True

	# 在线窥屏开关
	peep=True

	# 屏蔽bot自身消息
	block_bot=True

	# 使用者发送命令中（勿改）
	using=False

	# bot参与游戏开关（可内部设置）
	botto=True

	# 打招呼开关（可内部设置）
	hiyo=True

	# 广告开关（可内部设置）
	ad=True

	# 消息传递开关（可内部设置）
	transmit=False

	# 精简模式（可内部设置）
	simplify=False

	# 精简模式备用（勿改）
	resee=simplify


	# 生草机是否启用
	greengl=True

	# 真心话是否启用
	trueword=True

	# 飞花令是否启用
	flower=True

	# 词语接龙是否启用
	idioms=True


	# 在线用户昵称
	nicks1=[]
	nicks2=[]

	# 跨服消息列表
	tsmit=[]
	tsend=[]

	# 加入过聊天室的人
	joined=[]

	# 保存聊天语句
	chatlist=[]
	textlist=[]

	# 推荐列表
	sites1=[]
	sites2=[]

	# 计时器列表
	reckon=[]

	# afk成员
	afklist={}

	# 游戏数据及游戏成员
	gamename=[]
	gamedate=[]
	gameby=[]

	# 生草机数据
	greenda=[]

	# 飞花令数据
	flowerd=[]


	# 接收到的聊天条数
	chat_date=0


	try:
		# 连接聊天室
		ws=websocket.WebSocket()
		ws.connect(socket1)
		wss=''
		wws=''
		wsss=''

	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)


	def send(text):
		text=str(text)

		try:
			if '/w' in text[:2] or '/me' in text[:3] or '/color' in text[:6] or "r" in text[0] or using==True:
				ws.send(json.dumps({'cmd':'chat','text':text,"head":head}))

			else:
				ws.send(json.dumps({'cmd':'chat','text':f' {text}',"head":head}))

		except:
			time.sleep(0.2)

	def sendd(text):
		text=str(text)
		
		try:
			if '/w' in text[:2] or '/me' in text[:3] or '/color' in text[:6] or "r" in text[0] or using==True:
				wsss.send(json.dumps({'cmd':'chat','text':text,"head":head}))

			else:
				wsss.send(json.dumps({'cmd':'chat','text':f' {text}',"head":head}))

		except:
			time.sleep(0.2)


	try:
		# 获取每日信息
		api="https://api.iyk0.com/jr/"
		se=requests.get(api)
		res=se.json()
		ress=res["today"].replace('，',' ')

	except:
		ress="好好学习 天天向上"


	# 表示开始
	ww=time.strftime("%Y.%m.%d %H:%M:%S",time.localtime())
	yy=time.time()
	print(f"[Started] {ww}")

	# bot问候
	ws.send(json.dumps({"cmd":"join","channel":channel1,"nick":botname,"password":botpass,"token":"papereebot"}))
	send("/color 44FF00")
	time.sleep(0.2)
	send(ww)
	time.sleep(0.4)
	send(f"·\n{ress}\n更多玩法请输入：功能")

	# 用于排除bot昵称
	fp=open("record/[chat] block_name.txt","r")
	bot=fp.readlines()

	# 随机表情
	fp=open("record/[random] meme.txt","r")
	me=fp.readlines()


	def main_1():

		'''
			优先级：simplify（模式）>gamename（游戏）>while（睡眠）>hiyo（打招呼）>peep（窥屏）
		'''

		# 引用函数外变量
		global wss,botname,botnick
		global peep,block_bot,using,botto,hiyo,transmit,simplify,greengl,trueword,flower,idioms,gamename,gamedate,gameby,greenda,flowerd,chat_date

		socket=socket1
		chatroom=chatroom1
		channel=channel1

		def test_timer(t_time,nick,text):
			time.sleep(t_time)

			if text==None and greengl==False and len(greenda)!=0 and nick==greenda[-1]:
				send(f"/w {nick} {nick}的输入时间超时 {rese}来代写了")
				del greenda[-1]
				greenda.append(f"替{nick}写的{rese}")
				g1=greenda[-1]
				ta=len(gamedate)

				if ta==0:
					n=random.randint(1,5)
					cc=random.choice(nicks1)
					bb=random.choice(bot).strip("\n")
					aa=random.choice([nick,botnick,rese,username])

					if n==1:
						dd=random.choice([f"{aa}和{bb}",f"{aa}和{cc}",f"{bb}和{cc}"])

					else:
						send(f"/w {botname} {aa}")

				elif ta==1:
					aa=sb.sbs()
					send(f"/w {botname} {aa}")

				elif ta==2:
					aa=sb.sbsb()
					send(f"/w {botname} {aa}")

				else:
					fp=open("record/[random] text.txt","r").readlines()
					hh=random.choice(fp).strip("\n").replace('我们','bot').replace('你们',nick).replace('我',botnick).replace('你',nick)
					send(f"/w {botname} {hh}")

			elif nick in reckon:
				y=divmod(t_time,60)
				d=divmod(y[0],60)
				s=d[0]
				i=d[1]
				m=y[1]

				if text=='' and nick in nicks1:
					send(f"@{nick} {s}h {i}min {m}s倒计时已结束了")

				elif text!=None and nick in nicks1:
					send(f"@{nick} 已经过去{s}h {i}min {m}s了 快去{text}")

					if nick not in afklist:
						time.sleep(1)
						send(f"@{nick} 已被{botnick}标记为{text}状态")
						afklist[nick]=text

				else:
					send(f"诶{nick}人呢 已经去{text}了吧")

				del reckon[reckon.index(nick)]

			# 结束进程
			sys.exit(0)

		# 循环判定
		while True:

			# 保存文件的时间
			chat=time.strftime("%Y.%m.%d")
			write=open(f"chats/{chatroom}/[{chat}] {channel}.txt","a+")

			# bot打招呼
			hi = random.choice(["hi","hey","yo","hello","hi yo","hey yo"])
			hii = random.choice(["hii","heey","yoo","helloo","hi yoo","hey yoo"])

			# 随机等待时间
			zz=random.choice([0.1,0.15,0.2])
			ee=random.choice([0.3,0.35,0.4])

			try:
				# 接收到的json数据
				wss=json.loads(ws.recv())

			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)

			if f"{botname}\n" not in bot:
				bot.append(f"{botname}\n")

			# 当wu中的数据为10
			if len(sites1)==10:

				# 自动清空wu
				time.sleep(zz)
				send("已自动清空推荐记录")
				sites1.clear()
				
			# 当si中的数据为10
			if len(sites2)==10:

				# 自动清空si
				time.sleep(zz)
				send("已自动清空随机记录")
				sites2.clear()

			if "cmd" in wss:
				cmd=wss["cmd"]

				if cmd=="warn":
					text=wss["text"]

					if "name" in text or "昵称重复" in text or "已经有人" in text:
						taken=str(random.randint(1,999))
						botname_taken=f"{botname}_{taken}"
						ws.close()
						ws.connect(socket)
						ws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname_taken,"password":botpass,"token":"papereebot"}))
						botname=botname_taken
						send("/color 44FF00")
						time.sleep(zz)
						send(f"awa {botnick}的昵称卡在里面了")

				if cmd=="onlineSet":

					# 开始记录日志
					nicks=wss["nicks"]

					for nick in nicks:
						if "｜" not in nick:
							if chatroom==hc or chatroom==cc:
								if "XC_" not in nick:
									nicks1.append(nick)

							else:
								nicks1.append(nick)

					aa=", ".join(nicks1)
					bb=f"[Online] {aa}\n"
					dd="[Records]"
					print(bb)
					print(dd)

				elif cmd=="onlineAdd":
					nick=wss["nick"]
					emit=time.strftime("%H:%M:%S",time.localtime())
					aa=f"[{emit}]\n{nick} joined\n"
					print(aa)

					nj=os.listdir("record/[come] trip")
					jn=os.listdir("record/[come] nick")

					if chatroom==hc or chatroom==cc:
						if "XC_" not in nick:
							nicks1.append(nick)

					else:
						nicks1.append(nick)

					# 为防止刷屏而屏蔽bot昵称
					if f"{nick}\n" not in bot:
						time.sleep(ee)

						if "trip" in wss and wss["trip"].strip()!="" and wss["trip"] in f"{nj}.txt":
							time.sleep(zz)
							trip=wss["trip"]
							fp=open(f"record/[come] trip/{trip}.txt","r")
							ck=fp.read()
							send(ck)
							fp.close()

						elif f"{nick}\n" in f"{jn}.txt":
							time.sleep(zz)
							fp=open(f"record/[come] nick/{nick}.txt","r")
							ck=fp.read()
							send(ck)
							fp.close()

						elif hiyo==True:
							time.sleep(zz)

							# 如果此用户来过聊天频道
							if nick in joined:
								send(f"{hii} {nick}")

							else:
								# 昵称是第一次出现
								send(f"{hi} {nick}")
								joined.append(nick)

				elif cmd=="onlineRemove":
					nick=wss["nick"]
					emit=time.strftime("%H:%M:%S",time.localtime())
					aa=f"[{emit}]\n{nick} left\n"
					print(aa)

					if nick in nicks1:
						nicks1.remove(nick)

					if rese!=botname and len(gamename)==0:
						time.sleep(zz)

						if nick==rese:
							send(f"被卡掉的昵称走了 {botnick}马上回来")

							# 自动重启
							py=sys.executable
							os.execl(py,py,*sys.argv)

						elif rese not in nicks1:
							send(f"看到有人离开了 {botnick}才想起重启")

							# 自动重启
							py=sys.executable
							os.execl(py,py,*sys.argv)

				elif cmd=="chat":
					nick=wss["nick"]
					text=wss["text"]
					leve=wss["level"]
					aa=time.strftime("[%H:%M:%S]",time.localtime())

					# 增加一条聊天条数
					chat_date+=1

					# bot私聊用
					per=f"/w {nick} .\n·\n"

					if "trip" in wss and wss["trip"].strip()!='':
						trip=wss["trip"]
						bb=f"[{trip}] {nick}\n{text}"
						dd=f"{aa}\n{bb}\n"
						print(dd)

						try:
							write.write(f"{dd}\n")

						except:
							time.sleep(0.2)

					else:
						bb=f"[None] {nick}\n{text}"
						dd=f"{aa}\n{bb}\n"
						print(dd)

						try:
							write.write(f"{dd}\n")

						except:
							time.sleep(0.2)

					if transmit==True and nick!=botname and f"{nick}\n" not in bot:
						if "trip" in wss and wss["trip"].strip()!='':
							trip=wss["trip"]
							ff=f"[{trip}] {nick}\n{text}"
							tsmit.append(ff)

						else:
							ff=f"[None] {nick}\n{text}"
							tsmit.append(ff)

					# 如果是正常模式
					if simplify==False:

						if f"{nick}\n" in bot and f"@{botname}" in text[:len(botname)+1]:
							if "别" in text and "屏蔽" in text or "不要" in text and "屏蔽" in text or "理我" in text:
								del bot[bot.index(f"{nick}\n")]
								send(random.choice([f"诶 真拿{nick}没办法-","已解除~没问题了"]))

						# 为防止刷屏而屏蔽bot昵称
						if f"{nick}\n" not in bot and "eebot" not in nick:
							block_bot=True

						else:
							block_bot=False

						if using==True:
							if f"[{username}]" in text[:len(username)+3]:
								text=text[len(username)+3:]

						if block_bot==True or using==True:
							using=False

							# 聊天记录统计用
							fp=open(f"chats/{chatroom}/statistics/{nick}.txt","a+")

							try:
								fp.write(text.replace('\n','\\n')+"\n")

							except:
								fp.write("1\n")

							tx_now=text.replace("```","").replace("~~~>","")

							# 暂时保存聊天记录
							if "\n" in text:
								chatlist.append(f"{aa} [{nick}]\n{tx_now}\n\n")

							else:
								chatlist.append(f"{aa} [{nick}] {tx_now}\n\n")

							# 如果频道是hc
							if chatroom==hc:
								if text=="hc":
									fp=open("record/[room] hc.txt","r")
									ch=fp.read()
									send(per+ch)

							# 如果频道是cc或xc
							if chatroom==cc or chatroom==xc:
								if text=="2room":
									fp=open("record/[room] 2room.txt","r")
									rm=fp.read()
									send(per+rm)

							# 如果频道是cc
							if chatroom==cc:
								if text=="cc":
									fp=open("record/[room] cc.txt","r")
									cd=fp.read()
									send(per+cd)

							# 如果频道是xc或tc
							if chatroom==xc or chatroom==tc:
								if text[:4]=="ban-":
									if leve>100:
										if text[4:].strip()=="":
											send("请勿留空哦")

										else:
											a=str(text[4:]).replace(" ",'').replace("@",'')
											ws.send(json.dumps({"cmd":"ban","nick":a}))

									else:
										send("没有足够的权限")

								if text[:5]=="dumb-":
									if leve>100:
										if text[5:].strip()=="":
											send("请勿留空哦")

										else:
											a=str(text[5:]).replace(" ",'').replace("@",'')
											ws.send(json.dumps({"cmd":"dumb","nick":a}))

									else:
										send("没有足够的权限")

								if text[:5]=="kick-":
									if leve>100:
										if text[5:].strip()=="":
											send("请勿留空哦")

										else:
											a=str(text[5:]).replace(" ",'').replace("@",'')
											ws.send(json.dumps({"cmd":"kick","nick":a}))

									else:
										send("没有足够的权限")

								if text[:9]=="moveuser-":
									if leve>100:
										if text[9:].strip()=="":
											send("请勿留空哦")

										else:
											a=str(text[9:]).replace(" ",'').replace("@",'')
											ws.send(json.dumps({"cmd":"moveuser","nick":a}))

									else:
										send("没有足够的权限")

								if text[:6]=="speak-":
									if leve>100:
										if text[6:].strip()=="":
											send("请勿留空哦")

										else:
											a=str(text[6:]).replace(" ",'')
											ws.send(json.dumps({"cmd":"speak","hash":a}))

									else:
										send("没有足够的权限")

								if text[:6]=="unban-":
									if leve>100:
										if text[6:].strip()=="":
											send("请勿留空哦")

										else:
											a=str(text[6:]).replace(" ",'')
											ws.send(json.dumps({"cmd":"kick","hash":a}))

									else:
										send("没有足够的权限")

								if text=="unbanall-":
									if leve>100:
										ws.send(json.dumps({"cmd":"unbanall"}))

									else:
										send("没有足够的权限")

							# 如果频道是xc
							if chatroom==xc:
								if text[:5]=="kill-":
									if leve>100:
										if text[5:].strip()=="":
											send("请勿留空哦")

										else:
											a=str(text[5:]).replace(" ",'').replace("@",'')
											ws.send(json.dumps({"cmd":"kill","nick":a}))

									else:
										send("没有足够的权限")

								if text[:6]=="limit-":
									if leve>100:
										if text[6:].strip()=="":
											send("请勿留空哦")

										elif text[6:]=="true":
											ws.send(json.dumps({"cmd":"limit","open":text[6:]}))
											send("已开启房间频率限制")

										elif text[6:]=="false":
											ws.send(json.dumps({"cmd":"limit","open":text[6:]}))
											send("已关闭房间频率限制")

										else:
											send("无效的开关命令")

									else:
										send("没有足够的权限")

								if text[:7]=="unkill-":
									if leve>100:
										if text[7:].strip()=="":
											send("请勿留空哦")

										else:
											a=str(text[7:]).replace(" ",'').replace("@",'')
											ws.send(json.dumps({"cmd":"unkill","nick":a}))

									else:
										send("没有足够的权限")

								if text[:6]=="video-":
									if leve>100:
										if text[6:].strip()=="":
											ws.send(json.dumps({"cmd":"set_video","url":"none"}))
											send("已清空播放视频")

										else:
											ws.send(json.dumps({"cmd":"set_video","url":text[6:]}))

									else:
										send("没有足够的权限")

								if text[:11]=="addskipcap-":
									if leve>100:
										if text[11:].strip()=="":
											send("请勿留空哦")

										else:
											ws.send(json.dumps({"cmd":"addskipcap","trip":text[7:]}))

									else:
										send("没有足够的权限")

								if text=="xc":
									fp=open("record/[room] xc.txt","r")
									a=['z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','i','h','g','f','e','d','c','b','a']
									b=['0','1','2','3','4','5','6','7','8','9']
									c=random.sample(a+b,8)
									d="".join(c)
									cx=fp.read().replace('——',d)
									send(per+cx)

								if text=="mod":
									fp=open("record/[room] xc_mod.txt","r")
									mo=fp.read()
									send(per+mo)

							# 如果频道是tc
							if chatroom==tc:
								if text=="tc":
									fp=open("record/[room] tc.txt","r")
									ct=fp.read()
									send(per+ct)

								if text=="mod":
									fp=open("record/[room] tc_mod.txt","r")
									mo=fp.read()
									send(per+mo)

							# 如果频道是sc
							if chatroom==sc:
								if text=="sc":
									fp=open("record/[room] sc.txt","r")
									cs=fp.read()
									send(per+cs)

							if text in ["功能","order"]:
								fp=open("record/[main] order_normal.txt","r")
								er=fp.read().replace('——',botname)
								er=er.replace('t—',str(trueword)).replace('f—',str(flower)).replace('i—',str(idioms)).replace('g—',str(greengl))

								if peep==True:
									er=er.replace('e—',f'@{botname} 跨服聊天开｜关：是否接通隔壁聊天室\n')

								else:
									er=er.replace('e—','')

								if "ZhangHelper" in nicks1:
									er=er.replace('u—','漂流瓶｜drift：让bot随机扔漂流瓶')

								else:
									er=er.replace('u—','')

								if chatroom==hc:
									a="如果想了解hack.chat：hc"
									send(f"{per}{er}\n·\n{a}")

								elif chatroom==cc:
									a="如果想了解十字街：cc"
									b="cc与xc的虚构和约：2room"
									send(f"{per}{er}\n·\n{a}\n{b}")

								elif chatroom==xc:
									a="如果想了解XChat：xc"
									b="辅助管理使用方法：mod"
									c="xc与cc的虚构和约：2room"
									send(f"{per}{er}\n·\n{a}\n{b}\n{c}")

								elif chatroom==tc:
									a="如果想了解Tchat：tc"
									b="辅助管理使用方法：mod"
									send(f"{per}{er}\n·\n{a}\n{b}")

								elif chatroom==sc:
									a="如果想了解SprinkleChat：sc"
									send(f"{per}{er}\n·\n{a}")

							if text in ["自定义","re"]:
								fp=os.listdir("record/[custom] chat")
								ve='\n'.join(fp).replace('.txt','')
								er=f"可@{botname} 的问题：\n"
								send(per+er+ve)

							if text in ["揭示板","board"]:
								da=os.listdir("record/[board] board")
								date=', '.join(da).replace('.txt','')
								te="可查询的日期：\n"

								if date=="":
									send("None")

								else:
									send(per+te+date)

							if text in ["留言板","ees"]:
								es=open("record/[main] ees.txt","r")
								se=es.read()
								send(per+se)

							if text[:3]=="CA-":

								# 判断字数是否小于3
								if len(text[3:].strip())<3:
									send("内容至少3个字 请不要氵哦")

								else:
									# 把留言写入揭示板中
									fp=open(f"record/[board] board/{chat}.txt","a+")
									ch=time.strftime("%H:%M:%S",time.localtime())
									t3=text[3:]
									an=f"·\n[From.{chatroom}｜{channel}]\n[{ch}] {nick}\n{t3}\n\n".replace("```","").replace("~~~>","")

									try:
										fp.write(an)
										fp.close()
										send(f"已成功把{nick}的话写入公开揭示板")

									except:
										send("无法写入 含有无法识别的字符")

							if text[:2]=="B-":

								# 把日期字符串化
								da=os.listdir("record/[board] board")
								date=', '.join(da)
								t2=text[2:]

								# 留空则查询今日的揭示板
								if t2.strip()=="":
									if f"{chat}.txt" in da:
										fp=open(f"record/[board] board/{chat}.txt","r")
										ca=fp.read()
										send(f"{per}今日的揭示板\n（管理员 {username}）\n{ca}")

									else:
										send("今天的板空空如也")

								elif f"{t2}.txt" in da:
									fp=open(f"record/[board] board/{t2}.txt","r")
									ca=fp.read()
									send(f"{per}{t2}揭示板\n（管理员 {username}）\n{ca}")

								else:
									send("请检查日期是否正确")

							if text[:2] == "Z-":
								tex2=text[2:]

								# 设置为空时无效
								if tex2.strip()=="":
									send("请勿留空哦")

								elif str(text).count("\n")>=1:
									hd=os.listdir("record/[custom] chat")
									dh=tex2.split('\n',1)
									a=dh[0].strip()
									b=dh[1].replace('，',' ')

									# 设置为空时无效
									if a=="" or b=="":
										send("请勿留空哦")

									else:
										try:
											aa=a.strip('\n')
											fpp=open(f"record/[custom] chat/{aa}.txt","w")
											fpp.write(f"{b}\n")
											fpp.close()

											if f"{aa}.txt" in hd:
												send("已重新设置这个问题的回答")

											else:
												# 如果是第一次设置这个问题
												send(f"{botnick}记住要这么回答了")

											fp=open(f"record/[custom] user/{aa}.txt","a+")
											fp.write(f"{nick}\n")
											fp.close()

											xz=open(f"record/[custom] user/{aa}.txt","r")
											zx=xz.readlines()
											xx=', '.join(zx).replace('\n','')
											c=len(zx)
											time.sleep(ee)
											send(f"·\n问题：{a}\n经过{c}次修改：{xx}")

										except:
											send("无法写入 含有无法识别的字符")

								else:
									send("第一行是问题 从第二行开始是回答")

							if text[:2]=="E-":
								t2=text[2:]
								dd=f"{t2}\n"
								aa=''
								fp=''

								# 如果用户有识别码
								if "trip" in wss and wss["trip"].strip()!='':
									trip=wss["trip"]
									aa=f"record/[come] trip/{trip}.txt"
									fp=open(aa,"w")

								else:
									aa=f"record/[come] trip/{nick}.txt"
									fp=open(aa,"w")

								# 设置为空时重置
								if t2.strip()=="":
									fp.close()
									os.remove(aa)

								else:
									try:
										# 把欢迎语写入
										fp.write(dd)
										fp.close()
										send("设置成功 此昵称将在下次进入聊天室时生效")

									except:
										send("无法写入 含有无法识别的字符")

							if text[:2]=="R-":
								if text[2:].strip()=="":
									a=''.join(chatlist[-100:])
									send(per+a)

								elif text[2:].isnumeric()==True:
									a=int(text[2:])
									b=len(chatlist)

									if a>b:
										send(f"目前仅有{b}条聊天记录")

									elif a>100:
										send("最大只能查询100条聊天记录")

									elif a<1:
										send("那不就是没记录了嘛")

									elif b<1:
										send("当前没有记录")

									else:
										c=''.join(chatlist[-a:])
										send(per+c)

								else:
									send("无效的条数")

							if text[:2] == "G-":
								tex2=text[2:]

								# 设置为空时无效
								if tex2.strip()=="":
									send("请勿留空哦")

								else:
									t2=tex2.split("\n")
									jz=[]

									if len(t2)<3:
										send("应该这样写：\nG-（某人） （某人） ……\n（某地） （某地） ……\n（某事） （某事） ……")

									else:
										a=t2[0].split(" ")
										b=t2[1].split(" ")
										c=t2[2].split(" ")
										ra=random.choice(a)
										rb=random.choice(b)
										rc=random.choice(c)

										send(f"{ra}在{rb}{rc}")

										for aa in a:
											for bb in b:
												for dd in c:
													jz.append(f"{aa}在{bb}{dd}")

										jj=len(jz)
										time.sleep(zz)

										if jj>10:
											zj='\n'.join(jz[:10])
											send(f"{per}共有{jj}种结果 此处为前10~\n{zj}")

										else:
											zj='\n'.join(jz)
											send(f"{per}共有{jj}种结果~\n{zj}")

							if text[:3]=="CC-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									aa=[]

									for i in text[3:]:
										if i.isdigit()==True:
											aa.append(i)

									if len(aa)!=0:
										try:
											t3=text[3:]
											send(eval(t3))

										except:
											send("计算失败")

									else:
										send("无效字符 计算失败")

							if text[:2]=="O-":

								# 判断词后是否留空
								if text[2:].strip()=="":
									send("请勿留空哦")

								elif "os" in text or "sys" in text or "ws" in text or "open" in text:
									send("咳咳 想对代码和文件做什么")

								elif "while" in text or "for" in text:
									send("死循环是不被允许的")

								elif "input" in text or "sleep" in text or "getpass" in text or "main" in text or "exit" in text or "filter" in text:
									send("卡机是不被允许的")

								elif "trip" in wss and wss["trip"].strip()!='':
									trip=wss["trip"]
									Thread(target=online_code,args=(text[2:],nick,trip,)).start()

								else:
									Thread(target=online_code,args=(text[2:],nick,None,)).start()

							if text[:3]=="TI-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								elif nick in reckon:
									send(f"{nick}已经有自己的计时器了 不能多开")

								elif " " in text[3:]:
									t3=text[3:].split(" ",1)

									if t3[0].isnumeric()==False:
										send("无效的时长")

									else:
										Thread(target=test_timer,args=(int(t3[0]),nick,t3[1],)).start()
										send(f"OK {botnick}收到 到时会提醒{nick}的")
										reckon.append(nick)

								elif text[3:].isnumeric()==False:
									send("无效的时长")

								else:
									Thread(target=test_timer,args=(int(text[3:]),nick,'',)).start()
									send(f"OK {botnick}收到 到时会提醒{nick}的")
									reckon.append(nick)

							if text[:3] == "TU-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("哦空留勿请")

								else:
									t3=reversed(list(text[3:]))
									tx=''.join(t3)
									send(tx)

							if text[:4] == "MIX-":

								# 判断词后是否留空
								if text[4:].strip()=="":
									send("勿哦请空留")

								else:
									t4=list(text[4:])
									tx=''.join(random.sample(t4,len(t4)))
									send(tx)

							if text[:3]=="MS-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									a=[]

									for i in text[3:].replace(' ',''):
										if '\u4e00'<=i<='\u9fff' or i.isalpha()==False and i.isnumeric()==False:
											a.append(i)

									if len(a)!=0:
										send("摩斯电码的转换只能是英文或数字")

									else:
										send(morse_code.Turn_Morse_code(text[3:]))

							if text[:2]=="T-":

								# 判断词后是否留空
								if text[2:].strip()=="":
									send("请勿留空哦")

								else:
									a=[]

									for i in text[2:].replace(' ',''):
										if '\u4e00'<=i<='\u9fff' or i.isalpha()==False and i.isnumeric()==False:
											a.append(i)

									if len(a)!=0:
										send("标题转换只能是英文或数字")

									else:
										send(text[2:].title())

							if text[:3]=="IP-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 韩小韩API
									url="https://api.vvhan.com/api/getIpInfo"
									data={"ip":text[3:]}
									se=requests.get(url,data)
									res=se.json()

									# 如果失败
									if res["success"]==False:
										send("请求失败 请检查IP地址")

									else:
										a=res["info"]
										b="·\n地址："+res["ip"]+"\n所属："+a["lsp"]

										if a["prov"]=="":
											send(b)

										elif a["city"]=="":
											c="\n·\n国家："+a["country"]+"\n省份："+a["prov"]
											send(b+c)

										else:
											c="\n·\n国家："+a["country"]+"\n省份："+a["prov"]+"\n城市："+a["city"]
											send(b+c)

							if text[:4]=="ICP-":

								# 判断词后是否留空
								if text[4:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 零七生活API
									url="https://api.oick.cn/icp/api.php"
									data={"url":text[4:]}
									se=requests.get(url,data)
									res=se.json()

									# 如果状态码为200 则成功
									if res["code"]==200:
										a="·\n"+res["site_name"]+"（"+res["site_index"]+"）"
										b="\n·\n单位："+res["name"]+"\n类型："+res["nature"]
										c="\n·\n备案信息："+res["icp"]+"\n备案时间："+res["site_time"]
										send(a+b+c)

									# 如果状态码为201 无记录
									elif res["code"]==201:
										send("API出错或未有此域名ICP备案记录")

									else:
										send("获取失败 请检查域名")

							if text[:3]=="QQ-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 搏天api
									url="http://api.btstu.cn/qqxt/api.php"
									data={"qq":text[3:]}
									se=requests.get(url,data)
									res=se.json()

									if res["code"]==1 and res["name"]!="":
										send("·\n"+res["name"]+"\n"+text[3:])

									else:
										send("查询失败 请检查QQ号")

							if text[:5]=="CITY-":

								# 判断词后是否留空
								if text[5:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 木小果API
									url="https://api.muxiaoguo.cn/api/tianqi"
									data={"city":text[5:],"type":1,"api_key":"9410e360a940cb5e"}
									se=requests.get(url,data)
									res=se.json()
									a=res["data"]

									# 如果状态码为200 则成功
									if res["code"]==200:
										b="·\n城市："+text[5:]+"（"+a["weather"]+"）"
										c="\n温度："+a["temp"]+"°C\n湿度："+a["SD"]
										d="\n·\n风向："+a["WD"]+"\n风级："+a["WS"]+"\n风速："+a["wse"]
										e="\n·\n更新时间："+a["time"]
										send(b+c+d+e)

									else:
										send("查询失败 请检查城市")

							if text[:3]=="DU-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 木小果API
									url="https://api.muxiaoguo.cn/api/Baike"
									data={"type":"Baidu","word":text[3:],"api_key":"cb28182953ac4557"}
									se=requests.get(url,data)
									res=se.json()
									a=res["data"]

									# 如果状态码为200 则成功
									if res["code"]==200:
										b="·\n查询："+text[3:]+"\n·\n百度："+a["content"]
										c=b.replace('。','。\n').replace('"','').replace('(','（').replace(')','）').replace('“','「').replace('”','」')
										send(c)

									else:
										send("查询失败 无此百科")

							if text[:2]=="F-":

								# 判断词后是否留空
								if text[2:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 网易有道翻译
									url="http://fanyi.youdao.com/translate"
									head={"User-Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0"}

									if len(text[2:])>200:
										send("超出最大字符数200")

									else:
										data={"doctype":"json","type":"AUTO","i":text[2:]}
										se=requests.get(url,params=data,headers=head,timeout=10)
										res=se.json()

										# 如果状态码为0 则成功
										if res["errorCode"]==0:
											send(res["translateResult"][0][0]["tgt"])

										else:
											send("请求失败 请稍后再试")

							if text[:3]=="PT-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									# api: SuixinAPI
									url="http://api.botwl.cn/api/sjhgsd"
									data={"sjh":text[3:]}
									se=requests.get(url,data)
									res=se.json()

									# 如果状态码为1 则成功
									if res["code"]==1:
										a="·\n手机号："+res["手机号"]
										b="\n·\n归属地："+res["归属地"]+"\n卡类型："+res["卡类型"]
										send(a+b)

									else:
										send("获取失败 请检查手机号")

							if text[:2]=="L-":

								# 判断词后是否留空
								if text[2:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 搏天api
									url="https://api.vvhan.com/api/la.ji"
									data={"lj":text[2:]}
									se=requests.get(url,data)
									res=se.json()

									if res["sort"]!="俺也不知道是什么垃圾~":
										send(res["sort"])

									else:
										send("所以这是什么垃圾")

							if text[:3]=="WY-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 优客API
									url="https://api.iyk0.com/wymusic/"
									data={"msg":text[3:].replace(' ',''),"n":"1"}
									se=requests.get(url,data)
									res=se.text

									if "请稍后重试或换个关键词试试" in res:
										send("找不到此关键词相关歌曲")

									else:
										ress=se.json()
										a=requests.get(ress["url"])
										b=a.url
										c="\n·\n歌曲："+ress["song"]+"\n歌手："+ress["singer"]
										d=int(ress["url"].index('='))
										e=ress["url"][d:]
										f="\n·\n封面："+ress["img"]+f"\n地址：https://music.163.com/song?id{e}"
										g=f"\n解析：{b}"
										if chatroom==xc:
											send(c+f)
											ws.send(json.dumps({"cmd":"set_video","url":b}))

										else:
											send(c+f+g)

							if text[:3]=="ID-":
								t3=text[3:]

								# 判断词后是否留空
								if t3.strip()=="":
									send("请勿留空哦")

								else:
									# api: 零七生活API
									url="https://api.oick.cn/wyy/api.php"
									data={"id":t3}
									se=requests.get(url,data)
									res=se.url
									if "https://music.163.com/404"==res:
										send("网易云ID获取失败 请检查")

									else:
										a=f"·\n地址：https://music.163.com/song?id={t3}"
										b=f"\n解析：{res}"
										if chatroom==xc:
											send(a)
											ws.send(json.dumps({"cmd":"set_video","url":res}))

										else:
											send(a+b)

							if text[:3]=="BI-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								elif "http" in text or text[3:].isnumeric()==True:
									send("请输入BV号")

								else:
									# api: 优客API
									url="https://api.iyk0.com/bili_cover"
									data={"msg":text[3:]}
									se=requests.get(url,data)
									res=se.json()

									# 如果状态码为200 则成功
									if res["code"]==200:

										# api: INJAHOW
										urll="https://api.injahow.cn/bparse/"
										dataa={"bv":text[3:],"format":"mp4","type":"video","p":"1","q":"64","otype":"url"}
										see=requests.get(urll,dataa)
										ress=see.text
										a="\n·\nUP主："+res["name"]+"\n标题："+res["title"]+"\n简介："+res["desc"]
										b="\n·\n封面："+res["pic"]+"\n地址："+"https://www.bilibili.com/video/"+text[3:]
										c=f"\n解析：{ress}"
										if chatroom==xc:
											send(a+b)
											ws.send(json.dumps({"cmd":"set_video","url":ress}))

										else:
											send(a+b+c)

									else:
										send("获取失败 请检查BV号")

							if f"@{botname}" in text[:len(botname)+1]:

								# @botname后的字符串索引
								a=len(botname)+1
								b=text[a:]
								z=b.replace(' ','')

								# 用户自定义对话
								ct=os.listdir("record/[custom] chat")

								if botname in afklist:
									bn=afklist[botname]

									if "工作" in text or "取消" in text or "回" in text:
										send(f"/me 现在没在{bn}了")
										del afklist[botname]

									else:
										send(f"/me 现在还在{bn}")

								# 如果@的后面为空
								elif z=="":
									time.sleep(zz)
									send(random.choice([f"{nick}有事吗",f"欢迎来?{channel}聊天",f"欢迎来{chatroom}聊天","找ee去吧",f"好耶 是{nick}"]))

								# 用户自定义输出
								elif f"{z}.txt" in ct:

									try:
										fp=open(f"record/[custom] chat/{z}.txt","r")
										zn=fp.read()
										nz=zn.replace('我们',"bot").replace('你们',nick).replace('我',botnick).replace('你',nick)
										send(nz)

									except:
										send("无法读取 含有无法识别的字符")

								# 以下都是自设的部分
								elif z=="重启":
									if len(gamename)!=0:
										send("不行——还在玩游戏呢")

									elif chatroom==hc:
										if "trip" in wss and wss["trip"]=="eYFDHl":
											send(f"{botnick}收到！")
											py=sys.executable
											os.execl(py,py,*sys.argv)

										else:
											send("没有足够的权限")

									elif chatroom==cc:
										if "trip" in wss and wss["trip"]=="7eeHEV":
											send(f"{botnick}收到！")
											py=sys.executable
											os.execl(py,py,*sys.argv)

										else:
											send("没有足够的权限")

									elif chatroom==xc or chatroom==tc:
										if leve>100:
											send(f"{botnick}收到！")
											py=sys.executable
											os.execl(py,py,*sys.argv)

										else:
											send("没有足够的权限")

									elif chatroom==sc:
										if "trip" in wss and wss["trip"]=="4W3SXM":
											send(f"{botnick}收到！")
											py=sys.executable
											os.execl(py,py,*sys.argv)

										else:
											send("没有足够的权限")

								elif z=="退出":
									if len(gamename)!=0:
										send("不行——还在玩游戏呢")

									elif chatroom==hc:
										if "trip" in wss and wss["trip"]=="eYFDHl":
											send(f"{botnick}收到！")
											ws.close()
											sys.exit(0)

										else:
											send("没有足够的权限")

									elif chatroom==cc:
										if "trip" in wss and wss["trip"]=="7eeHEV":
											send(f"{botnick}收到！")
											ws.close()
											sys.exit(0)

										else:
											send("没有足够的权限")

									elif chatroom==xc or chatroom==tc:
										if leve>100:
											send(f"{botnick}收到！")
											ws.close()
											sys.exit(0)

										else:
											send("没有足够的权限")

									elif chatroom==sc:
										if "trip" in wss and wss["trip"]=="4W3SXM":
											send(f"{botnick}收到！")
											ws.close()
											sys.exit(0)

										else:
											send("没有足够的权限")

								elif "打招呼" in b and "开" in b:
									send(f"{botnick}收到 向全体用户打招呼")
									hiyo=True

								elif "打招呼" in b and "关" in b:
									send(f"{botnick}收到 只向登记欢迎语的用户打招呼")
									hiyo=False

								elif "广告" in b and "开" in b:
									send(f"{botnick}收到 非个性化友链推荐开启")
									ad=True

								elif "广告" in b and "关" in b:
									send(f"{botnick}收到 非个性化友链推荐关闭")
									ad=False

								elif "跨服聊天" in b and "开" in b:
									send(f"{botnick}收到 接收并向 [{chatroom2}｜{channel2}] 发送消息")
									transmit=True

								elif "跨服聊天" in b and "关" in b:
									send(f"{botnick}收到 不再接收和向 [{chatroom2}｜{channel2}] 发送消息")
									transmit=False

								elif "睡" in b or "困" in b:
									if len(gamename)!=0:
										send(random.choice(["不行——正在和大家玩游戏呢","不能睡不能睡（睁"]))

									else:
										send(random.choice([f"awa {nick}晚安！{botnick}要睡了",f"好啦好啦 {botnick}去睡了","晚安—— 明天见"]))

										# 自动打开精简模式
										simplify=True

										# 关闭消息传输
										transmit=False

										while True:
											try:
												# 接收到的json数据
												wss=json.loads(ws.recv())

											except:
												# 自动重启
												time.sleep(30)
												py=sys.executable
												os.execl(py,py,*sys.argv)

											if "cmd" in wss:
												cmd=wss["cmd"]

												if cmd=="onlineAdd":
													nick=wss["nick"]
													emit=time.strftime("%H:%M:%S",time.localtime())
													aa=f"[{emit}]\n{nick} joined\n"
													print(aa)
													time.sleep(ee)
													send(f"Good Night {nick}")

												elif cmd=="onlineRemove":
													nick=wss["nick"]
													emit=time.strftime("%H:%M:%S",time.localtime())
													aa=f"[{emit}]\n{nick} left\n"
													print(aa)

												elif cmd=="chat":
													nick=wss["nick"]
													text=wss["text"]
													aa=time.strftime("[%H:%M:%S]\n",time.localtime())

													if "trip" in wss and wss["trip"].strip()!='':
														trip=wss["trip"]
														bb=f"[{trip}] {nick}\n{text}"
														dd=f"{aa}{bb}\n"
														print(dd)

														try:
															write.write(f"{dd}\n")

														except:
															time.sleep(0.2)

													else:
														bb=f"[None] {nick}\n{text}"
														dd=f"{aa}{bb}\n"
														print(dd)

														try:
															write.write(f"{dd}\n")

														except:
															time.sleep(0.2)

													if f"@{botname}" in text[:len(botname)+1]:
														time.sleep(ee)

														if "醒" in text or "起" in text:
															send(random.choice([f"{botnick}起床了！",f"早安~{nick}","早呀 该接着工作了呢"]))

															# 自动关闭精简模式
															simplify=False

															break

														else:
															send(random.choice(["Zzzz好困",f"（{botnick}休息中）","少女入睡中Z"]))

												elif cmd=="info" and wss.get("type")=="whisper":
													if "from" in wss:
														nick=str(wss["from"])
														text=wss["text"][len(nick)+12:]
														aa=f"[{nick}][/w]\n{text}\n"
														bb=random.choice([f"{nick}也快点去睡觉吧",f"{botnick}已经睡着了（",f"{botnick}好困"])
														print(aa)
														send(f"/w {nick} {bb}")

								elif "屏蔽" in b and "我" in b:
									send(random.choice([f"OK 暂时屏蔽{nick}了哦",f"没关系 要解除时记得喊{botnick}"]))
									bot.append(f"{nick}\n")

								elif "来" in b and "一起玩" in b:
									send(f"yeeeees {botnick}会参与真心话游戏")
									botto=True

								elif "别" in b and "一起玩" in b:
									send(f"ah 那{botnick}就不参与真心话了")
									botto=False

								elif "去" in z[:1] and z[1:]!="":
									z1=z[1:].replace('，',' ').strip('。').strip('！').strip('？').strip('!').strip('?')

									if z1=="工作":
										send(f"当然 {botnick}现在就在工作呀")

									else:
										send(f"OK! {botnick}现在在{z1}")
										afklist[botname]=z1

								elif "昵称" in z[:2] and z[2:]!="":
									z2=z[2:].replace(' ','')

									if len(z[2:])>len(rese):
										send("昵称不可以比名字长")

									elif z2.isalpha()==False and z2.isnumeric()==False:
										send("昵称只能是中文或英文或数字")

									else:
										botnick=z2
										send(f"好耶！{rese}喜欢{botnick}这个昵称")

								elif "介绍" in b and "自己" in b or "介绍" in b and "你" in b:
									send(f"这里是{rese} 制作者是{username}\n——永远保持可爱与活力！{nick}也要天天快乐")

								elif "好" in b and "吧" in b:
									send(random.choice(["那不就没问题了嘛（","这就对了","嗯嗯"]))

								elif "好" in b and "不" in b:
									send(random.choice([f"靠在{nick}身边）","啊哈",f"/me 歪着头看{nick}"]))

								elif "好" in b and "看" in b or "好" in b and "康" in b:
									send(random.choice([f"{botnick}觉得不错呀","哇哦"]))

								elif "好" in b and "大家" in b or "好" in b and "你" in b:
									send(random.choice([f"欢迎来到?{channel}",f"欢迎来到{chatroom}","你好你好","ooooy ih"]))

								elif "你" in b and "妈" in b and "是" in b or "你" in b and "娘" in b and "是":
									send(random.choice([f"{botnick}是{username}的女儿",f"{botnick}的亲妈是{username} 亲爹也是{username}"]))

								elif "你" in b and "爸" in b and "是" or "你" in b and "爹" in b and "是":
									send(random.choice(["这个呀 也许只有妈吗哦",f"{botnick}是{username}的女儿"]))

								elif "你" in b and "哥" in b or "你" in b and "弟" in b or "你" in b and "姐" in b or "你" in b and "妹" in b:
									send(random.choice(["bot都是兄弟姐妹",f"{botnick}是独生女",f"{botnick}也想要有"]))

								elif "你" in b and "爷" in b and "是" or "你" in b and "奶" in b and "是":
									send(random.choice([f"{botnick}只记得有妈妈",f"{botnick}也可以有吗？",f"{nick}想当吗？"]))

								elif "你" in b and "朋友" in b:
									a=random.choice(bot).strip('\n')
									send(random.choice([f"{nick}在和{botnick}聊天 那么我们就是朋友啦",f"{a}是{botnick}的朋友"]))

								elif "你" in b and "女" in b and "是" or "你" in b and "萝莉" in b and "是":
									send(random.choice(["毫无疑问是呢~",f"{nick}觉得{botnick}可爱吗？","椰丝！"]))

								elif "你" in b and "男" in b and "是" or "你" in b and "正太" in b and "是":
									send(random.choice(["NONO 是女孩子哟",f"不是哦",f"虽然不是 但{nick}认为是就是啦"]))

								elif "你" in b and "对象" in b or "你" in b and "老公" in b or "你" in b and "老婆" in b:
									send(random.choice([f"比如说{nick}",f"{botnick}还小",f"（把{nick}加入候补名单"]))

								elif "你" in b and "爱好" in b:
									send("吹电风扇 和CPU搞好关系（指CPU因为过于激动而发烫） 有些时候会抽烟（尤其是低配电脑）")

								elif "没" in b and "人" in b:
									send(random.choice([f"不 还有{botnick}",f"有{botnick}在呢","有bot","来了来了"]))

								elif "绿" in b or "44FF00" in b:
									send(random.choice(["ww绿！","44FF00是最棒的颜色","大自然之荧光绿"]))

								elif "可怕" in b or "吓人" in b or "害怕" in b:
									send(random.choice(["（摸摸）","富强民主文明和谐……","社会主义核心价值观"]))

								elif "胶水" in b or "glue" in b:
									send(random.choice([f"{botnick}来派发jill glue了",f"一天一胶水~{nick}远离人世间"]))

								elif "加油" in b:
									send(random.choice([f"{nick}也加油","加油吧！少年","向着那明日的朝阳前进吧","鼓起勇气 迈向未来"]))

								elif "复读机" in b:
									send(random.choice(["才不是复读机啦！",f"哼哼 不仅bot是 {nick}也是（"]))

								elif "柠檬" in b or "酸了" in b:
									send(random.choice(["柠檬树下柠檬果",f"柠檬树下{nick}和{botnick}","（托腮.jpg）"]))

								elif "延迟" in b or "反应" and "慢" in b:
									send(random.choice([f"这不是{botnick}的错","因为代码太长了）",f"{username}还在研究多线程"]))

								elif z in ["机器人","bot"]:
									send(random.choice([f"{rese}是bot","@fOoLishbIrD ","@Wcy_Bot ","@zzChumo "]))

								elif z in ["纸片君","ee",username]:
									send(random.choice([f"{botnick}的妈妈 {nick}的朋友",f"{botnick}的制作者",f"找{botnick}的母亲大人有事吗"]))

								else:
									# api: 图灵机器人
									# url="http://www.tuling123.com/openapi/api"
									# data={"key":"77f2530f4d83405bb3a01a30014f6117","info":text[a:].replace(' ','')}
									# se=requests.get(url,data)
									# res=se.json()
									# l=res["text"]

									# api: SuixinAPI
									url="http://api.botwl.cn/api/aick"
									data={"msg":text[a:].replace(' ','')}
									se=requests.get(url,data)
									res=se.json()
									l=res["msg"]

									# 判断状态码是否成功
									# if res["code"]==100000 or l!="":

									if res["code"]=="1" or l!="":

										# 打开aick文件
										fp=open("record/[chat] block_word.txt","r")
										ai=fp.readlines()

										# 以列表的形式读取text
										fpp=open("record/[random] text.txt","r")
										xt=random.choice(fpp.readlines())
										tx=xt.replace('我们',"bot").replace('你们',nick).replace('我',botnick).replace('你',nick)
										tx=tx.replace('，',' ').strip('。')

										# 屏蔽aick中的关键字
										if f"{text[a:]}\n" not in ai:

											# 如果l中存在{}
											if "{" in l and "}" in l  or "无聊" in l or "什么意思" in l or "说详细点" in l or "说明白点" in l:
												send(tx)

											else:
												# 替换和简繁转换
												c=l.replace('随心',rese).replace('我们',"bot").replace('你们',nick).replace('help','功能')
												c=c.replace('我',botnick).replace('你',nick).replace('，',' ').strip('。')
												d=Converter('zh-hans').convert(c)
												e=d.replace('啥','什么').replace('咋','怎么').replace('“','').replace('”','').replace('"','')

												# 如果字符串的长度为偶数
												if e!='' and '\u4e00'<=e[-1]<='\u9fff':
													if (len(e)%2)==0:
														f=e+random.choice(["（","）"])
														send(f)

													else:
														send(e)

												else:
													send(e)

									else:
										# 随机一句话
										send(random.choice(["芜湖","好诶好诶",f"{nick}觉得呢？","此地有鱼 其名为李桂鱼","烹饪鱼需要两个烧烤架~"]))

							# 排除bot昵称在text的情况 nick里有bot昵称的情况
							if "\n" not in text and "@" not in text and "-" not in text and botname not in text and f"{nick}\n" not in bot:

								# 判断内容是否有意义
								if text!=text[0]*len(text):

									if len(textlist)==25 or len(textlist)==75:

										# 判断te的长度和text的长度
										if len(text)<=20 and len(text)>=3:

											# api: 图灵机器人
											# url="http://www.tuling123.com/openapi/api"
											# data={"key":"77f2530f4d83405bb3a01a30014f6117","info":text.replace(' ','')}
											# se=requests.get(url,data)
											# res=se.json()
											# a=res["text"]

											# api: SuixinAPI
											url="http://api.botwl.cn/api/aick"
											data={"msg":text.replace(' ','')}
											se=requests.get(url,data)
											res=se.json()
											a=res["msg"]

											# 替换和简繁转换
											b=a.replace('随心',rese).replace('我们',"bot").replace('你们',nick).replace('help','功能')
											b=b.replace('我',botnick).replace('你',nick).replace('，',' ').strip('。')
											c=Converter('zh-hans').convert(b)
											d=c.replace('啥','什么').replace('咋','怎么').replace('“','').replace('”','').replace('"','')

											textlist.append(text.replace('，'," "))

											# 如果l中存在{}
											if "{" in a and "}" in a or "无聊" in a or "什么意思" in a or "说详细点" in a or "说明白点" in a:
												e=random.choice(["诶嘿哟","好耶好耶","如果是这样的话（？","一瞬间有一百万个可能","怀揣着梦想 向着朝阳"])
												send(e)

											# 如果字符串c的长度为奇数
											elif d!='' and '\u4e00'<=d[-1]<='\u9fff':
												if (len(d)%2)==0:
													e=d+random.choice(["（","）"])
													send(e)

												else:
													send(d)

											else:
												send(d)

									if len(textlist)==40 or len(textlist)==60:
										sbs=sb.sb().replace('你',nick).replace('我',botnick).replace('e—',username).replace('c—',chatroom)
										send(sbs)
										textlist.append(sbs)

									if len(text)<=20 and len(text)>5:

										# 判断未有游戏进行
										if len(gamename)==0:
											time.sleep(zz)
											textlist.append(text.replace('，',' '))

											# te长度为50时bot随机输出te内容
											if len(textlist)==50:
												t=random.choice(textlist)
												t=t.replace('我们','bot').replace('你们',nick).replace('我',botnick).replace('你',nick)
												send(t)

											# te长度为100时bot复读一句话
											if len(textlist)==100:
												t=text.replace('，',' ').replace('我们','bot').replace('我',botnick)
												send(t)
												textlist.clear()

											# 复读或发送me中的表情
											if text in me:
												t=text.replace('我们','bot').replace('你们',nick).replace('我',botnick).replace('你',nick)
												t=t.replace('，',' ').strip('。')
												meme=random.choice(me)
												send(random.choice([t,meme]))

									if len(text)<=30 and len(text)>5:
										a=text.replace('，',' ').replace('。',' ')

										# 判断是否是中文和英文
										if a.replace(' ','').replace('！','').replace('？','').replace('、','').isalpha()==True:

											# 将话写入text文件
											fp=open("record/[random] text.txt","r+")
											tx=fp.readlines()
											if f"{a}\n" not in tx:

												try:
													fp.write(f"{a}\n")
													fp.close()

												except:
													time.sleep(0.2)

							if f"{text}\n" in me:
								meme=random.choice(me)
								send(meme)

							if text==text[0]*len(text):
								a=random.randint(1,int(len(text)))

								# 如果是句号或省略号
								if text[0]=="…" or text[0]=="。" or text[0]=="、" or text[0]=="，":

									# 如果用户有识别码
									if "trip" in wss and wss["trip"].strip()!='':
										sbs=sb.sb().replace('你',nick).replace('我',botnick).replace('e—',username).replace('c—',chatroom)
										send(sbs)

									elif a==1:
										send(random.choice(["原来是沉默吗","不说话便是最好的回答",f"句号和省略号让{botnick}摸不着头脑"]))

								if text[0]=="e" and a==1:
									y=open("record/[random] coon.txt","r").readlines()
									w=random.choice(y).strip("\n")
									send(f"![]({w})")

								elif len(text) > 1:
									if a==1:
										if '\u4e00'<=text[0]<='\u9fff':
											if text[0]=="哈":
												a=f"{text}嗝-"
												b=f"{text}草"
												c=f"草{text}"
												send(random.choice([a,b,c]))

											else:
												a=text[0]*(len(text)+1)
												send(a)

							if "http" in text:
								text=text.replace("USERSENDVOICE_static","https://xq.kzw.ink/oss")

								# api: 远昔API
								a=re.findall(r'(https?://[^\s]+)',text)
								d=[]

								# 单独存放连接
								fp=open("record/[record] web.txt","r+")
								bc=fp.readlines()

								if len(a)!=0:
									for aaa in a:
										b=aaa.replace('(','').replace(')','').replace('[','').replace(']','')
										url="https://yuanxiapi.cn/api/info/"
										data={"url":b}
										se=requests.get(url,data)
										res=se.json()

										# 如果状态码为200 则成功
										if res["code"]==200:
											tit=res["title"]
											c=f"@{nick} {tit}\n{b}"
											d.append(c)

											if f"{b}\n" not in bc:
												ch=time.strftime("%Y.%m.%d %H:%M:%S",time.localtime())
												sm=f"·\n[From.{chatroom}｜{channel}]\n[{ch}]\n{c}\n\n"

												try:
													fp.write(sm)
													fp.close()

												except:
													send("无法写入 含有无法识别的字符")

											fp.close()

										else:
											send("wow")

									aa=list(set(d))
									e='\n·\n'.join(aa)
									send(e)

							# 防止多个游戏同时进行
							if text in ["生草机","真心话","飞花令","词语接龙"]:
								if len(gamename)!=0 and text not in gamename:
									ga=gamename[0]

									fp=open("record/[game] over.txt","r")
									a=fp.read()
									send(a.replace('——',ga))

							# 如果想玩的游戏已经开始了
							if text in gamename:
								send(f"{text}已经开始了")

							# 在有游戏进行的情况下
							if len(gamename)!=0:
								ga=gamename[0]

								if text=="结算":

									# 如果真心话开关开启
									if trueword==False:

										# 游戏成员<2人
										if len(gameby)<2:
											send("人数不足 至少要有2个人")

										else:
											# 获取pl中最大和最小的数字
											j=max(gamedate)
											k=min(gamedate)

											# 获取pl中分别对应最大和最小的成员
											v=gameby[gamedate.index(j)]
											m=gameby[gamedate.index(k)]

											# 将数字字符串化
											a=f"最大：{str(j)}（{v}）"
											b=f"最小：{str(k)}（{m}）"

											# 发送并清空by和pl
											send(f"·\n本次参与人数：{str(len(gameby))}\n·\n{a}\n{b}")
											time.sleep(zz)
											send(f"@{v} 向@{m} 提问")
											time.sleep(ee)
											gameby.clear()
											gamedate.clear()

											if m==botname:
												send(random.choice(["上（","问吧","来吧"]))

											elif v==botname:
												fp=open("record/[random] ques.txt","r").readlines()
												vv=random.choice(fp).strip("\n")
												time.sleep(ee)

												if (len(vv)%2)==0:
													vb=vv+random.choice(["（","）"])
													send(f"@{m} {vb}")

												else:
													send(f"@{m} {vv}")

									# 如果成语接龙开关开启
									if idioms==False:

										# 如果pl中没有数据
										if len(gamedate)==0:
											send("不允许在游戏未开始前结束")

										else:
											# 发送游戏数据后清空
											a='\n'.join(gamedate)
											j=f"·\n{a}"
											f=', '.join(gameby)
											k=f"\n·\nby.{f}"
											q=f"（{str(len(gameby))}）"
											send(str(j+k+q))
											gameby.clear()
											gamedate.clear()

								if text=="结束游戏":
									send(f"{ga}已结束")

									# 清空所有游戏数据
									gameby.clear()
									gamedate.clear()
									flowerd.clear()
									greenda.clear()
									gamename.clear()

									# 重置所有开关
									greengl=True
									trueword=True
									idioms=True
									flower=True
								
								if text=="重置游戏":
									send(f"{ga}已重置")

									# 清空游戏内容
									gameby.clear()
									gamedate.clear()
									flowerd.clear()
									greenda.clear()

									# 在飞花令开关打开的情况下
									if flower==False:
										time.sleep(ee)
										send("请重新使用P-设置关键字")

									if greengl==False:
										time.sleep(ee)
										send("请输入1重新报数")

								# 如果生草机开关开启
								if greengl==False:
									if len(greenda)==0:
										if text=="1":
											if nick in gameby:
												send(f"{nick}已经报过数了 现在有{len(gameby)}人")

											else:
												gameby.append(nick)
												send(f"{nick}成功加入 现在有{len(gameby)}人")

										elif text=="信息":
											send("生草机游戏报数中")

										elif text=="开始游戏":
											if len(gameby)<3:
												send("人数不足 至少要有3个人")

											else:
												a=''
												random.shuffle(gameby)

												for b in gameby:
													a+=f"@{b} "

												send("生草机游戏开始")
												time.sleep(zz)
												send(f"{a}\n注意查看私聊 由于是按顺序来 部分人的私聊通知还在等待中-")

												greenda.append(len(gameby))
												greenda.append(gameby[0])
												g1=greenda[-1]
												del gameby[0]

												time.sleep(zz)
												send(f"/w {g1} 轮到{g1}啦 使用/w {botname} 输入一个人物名")

												Thread(target=test_timer,args=(60,g1,None,)).start()
												
									elif text=="信息":
										aa=[]
										dd=[]

										if len(greenda[1:-1])!=0:
											for n in greenda[1:-1]:
												aa.append(n)

										else:
											aa.append("None")

										if len(gameby)!=0:
											for n in gameby:
												dd.append(n)

										else:
											dd.append("None")

										b=greenda[-1]
										a='\n'.join(aa)
										d='\n'.join(dd)
										send(f"{per}已完成：\n{a}\n·\n输入中：\n{b}\n·\n等待中：\n{d}")

									elif text=="开始游戏":
										send("生草机已经开始了")

								# 如果飞花令开关开启
								if flower==False:
									if len(flowerd)==0:
										if "P-" in text[:2]:

											# 获取特定位置的字
											t2=text[2:]

											if len(text)<=3:
												a=random.randint(1,8)

												if t2.strip()=="":
													flowerd.append("花")
													flowerd.append(a)

												else:
													flowerd.append(t2)
													flowerd.append(a)

												f0=flowerd[0]
												f1=str(flowerd[1])
												f11=flowerd[1]

												send("飞花令游戏开始")
												time.sleep(ee)
									
												if f11==8:
													send(f"·\n关键字：{f0}（{nick}）\n·\n模式：轮流\n位置：第n句的关键词出现在第n个字上")
													time.sleep(zz)
													send(f"下句的{f0}在第1个字上")

												else:
													send(f"·\n关键字：{f0}（{nick}）\n·\n模式：固定\n位置：关键词在每句的第{f1}个字上")
													time.sleep(zz)
													send(f"每句的{f0}在第{f1}个字上")

											else:
												send("关键字只能有一个")

									else:
										# 获取特定位置的字
										z=len(gamedate)+2
										v=str(gamedate).count(f0)

										f0=flowerd[0]
										f1=str(flowerd[1])
										f11=flowerd[1]

										# 如果z列表的长度为9
										if z==9:
											c='\n'.join(gamedate)
											d=', '.join(gameby)
											send(f"·\n{c}\n·\nby.{d}（{z}）")
											time.sleep(ee)

											# 清空游戏数据并结束游戏
											gameby.clear()
											gamedate.clear()
											flowerd.clear()
											gamename.clear()
											flower=True

											# 如果字多于14个
											if v>14:
												send(f"游戏结束 飞出了{str(v)}个{f0}")

											else:
												# 直接结束
												send("游戏结束 完美撒花！")

										# z列表的长度不为9且P-存在的情况下
										elif z!=9 and "P-" in text[:2] and str(text).count("-")==1:

											# 获取特定位置的字
											t2=text[2:]
											yz=random.randint(1,7)

											# 如果文本长度为9
											if len(text)==9:
												if f11==8:
													if text[z]==f0:
														gamedate.append(t2)

														# 如果昵称不在by中
														if nick not in gameby:
															gameby.append(nick)

														# 如果z列表的长度不为8
														if z!=8:
															send(f"@{nick} {t2}\n下句的{f0}字在第{str(z)}个字上")

														# 如果z列表的长度为8
														if z==8:
															send("七句诗成功输出")

													else:
														# 如果关键字没有在固定位置上
														send("关键词没在固定位置上")

												else:
													# 如果关键字在固定位置上
													if text[f11+1]==f0:
														gamedate.append(t2)

														# 如果昵称不在by中
														if nick not in gameby:
															gameby.append(nick)

														# 如果z列表的长度不为8
														if z!=8:
															send(f"@{nick} {t2}\n下句的{f0}字在第{f1}个字上")

														# 如果z列表的长度为8
														if z==8:
															send("七句诗成功输出")

													else:
														# 如果关键字没有在固定位置上
														send("关键词没在固定位置上")
									
											else:
												# 文本长度不是9
												send("请输入七言律诗")
							
								# 如果成语接龙开关开启
								if idioms==False:

									# P-存在的情况下
									if "P-" in text[:2] and str(text).count("-")==1:

										# 获取特定位置的字
										t2=text[2:]
										t1=text[-1]
										z=len(gamedate)
										a=f"@{nick} {t2}\n下一词的开头是：{t1}"

										# 如果文本长度为6
										if len(text)==6:

											# 如果pl中没有数据
											if z==0:
												gamedate.append(t2)

												# 昵称已在by的情况下
												if nick in gameby:
													send(a)

												else:
													# 昵称不在by
													send(f"就由{nick}开始吧")
													time.sleep(zz)
													send(a)

													# 清空by中的昵称再将新昵称写入
													gameby.clear()
													gameby.append(nick)

											else:
												# 判断文本中的第三个字是否为前成语的末尾
												if text[2] in gamedate[z-1][-1]:
													send(a)
													gamedate.append(t2)

													# 如果昵称不在by中
													if nick not in gameby:
														gameby.append(nick)

												else:
													# 成语的头尾接不上
													send("请检查头尾是否接上")

										else:
											# 文本长度不是6
											send("请输入四字词哦")

							# 在没有游戏进行的情况下
							if len(gamename)==0:
								tt=f"{text}已被{username}关闭"

								if text=="生草机":

									# 如果游戏未开启
									if greengl==True:

										# 生草机说明
										fp=open("record/[game] greengl.txt","r")
										send(fp.read())
										time.sleep(zz)
										send("请用1报数")
										gamename.append(text)

										# 生草机开关打开
										greengl=False

									else:
										send(f"{tt}（太生草了")

								if text=="真心话":

									# 如果游戏未开启
									if trueword==True:

										# 真心话说明
										fp=open("record/[game] trueword.txt","r")
										send(fp.read())
										time.sleep(zz)
										send("真心话游戏开始")
										gamename.append(text)

										# 真心话开关打开
										trueword=False

									else:
										send(f"{tt}（{botnick}的真心话")

								if text=="飞花令":

									# 如果游戏未开启
									if flower==True:

										# 飞花令说明
										fp=open("record/[game] flower.txt","r")
										a=fp.read()
										send(a)
										time.sleep(zz)
										send("请用P-输入关键字")
										gamename.append(text)

										# 飞花令开关打开
										flower=False

									else:
										send(f"{tt}（天女散花-")
									
								if text=="词语接龙":

									# 如果游戏未开启
									if idioms==True:

										# 词语接龙说明
										fp=open("record/[game] idioms.txt","r")
										a=fp.read()
										send(a)
										time.sleep(zz)
										send(f"请{nick}开一个好头吧")
										gamename.append(text)
										gameby.append(nick)

										# 词语接龙开关打开
										idioms=False

									else:
										send(f"{tt}（接")

						if "r" in text[:1]:

							# 随机1~999的数字
							r=random.randint(1,999)

							if text[1:]!="" and text[1]==" ":
								t2=text[2:]

								if " " in t2:
									tt2=t2.split(" ",1)

									if tt2[0].isdigit()==True and tt2[1].isdigit()==True:
										t0=int(tt2[0])
										t1=int(tt2[1])

										if t0>t1:
											send(random.randint(t1,t0))

										if t0<t1:
											send(random.randint(t0,t1))

										if t0==t1:
											send(t0)

									else:
										send(r)

								elif t2=="0":
									send("清凌memset0")

								elif t2=="07":
									send("154的回忆")

								elif t2=="11":
									send("纸片君ee")

								elif t2=="13":
									send("纸片君ee的拾叁君13")

								elif t2=="27":
									send("祝27好运")

								elif t2=="49":
									send("死尸酒")

								elif t2=="123":
									send("ee见过至少14个123")

								elif t2=="154":
									send("大帅比 江苏大猛1")

								elif t2=="404":
									send("4n0n4me打不开网页")

								elif t2 in nicks1:
									send(f"@{t2} "*random.randint(1,5)+"被r了")

								elif t2.isdigit()==True and int(t2)!=0:

									# 随机计算
									a=int(t2)
									b=random.randint(1,a)
									send(random.choice([a*r,a+b,a-b]))

								elif t2[0]=="-" and t2[1:].isdigit()==True and int(t2[1:])!=0:
									send(abs(int(t2)))

								else:
									send(r)

							# 如果真心话开关开启
							elif trueword==False and len(gamename)!=0:

								# 无效在by中的昵称
								if nick in gameby:
									a=str(gamedate[gameby.index(nick)])
									send(f"@{nick} 已经r出了{a}")

								else:
									# 发送r数字并记录值和昵称
									gameby.append(nick)
									gamedate.append(int(r))
									send(r)

									if botto==True and botname not in gameby:
										time.sleep(zz)
										send("r")

							else:
								# 如果真心话开关关闭
								send(r)

				elif cmd=="info" and wss.get("type")=="whisper":
					if "from" in wss:
						nick=str(wss["from"])
						tex1=wss["text"]
						text=''

						if chatroom==hc or chatroom==xc or chatroom==sc:
							text=wss["text"][len(nick)+12:]

						if chatroom==tc:
							text=wss["text"][len(nick)+8:]

						aa=f"[{nick}][/w]\n{text}\n"
						print(aa)

						# 为防止刷屏而屏蔽bot昵称
						if "You whispered to" not in tex1 and "你悄悄对" not in tex1:
							if f"{nick}\n" not in bot:
								if greengl==True:
									if simplify==False:
										time.sleep(zz)
										send(f"/w {nick} 暂不支持私聊哦~")

									else:
										time.sleep(zz)
										send(f"/w {nick} {botnick}休息中")

							# 如果生草机开关开启
							if greengl==False and len(gamename)!=0:
								time.sleep(zz)

								if len(greenda)>1:
									if nick==greenda[-1] or nick==botname:
										g0=greenda[0]
										text=text.replace('，',' ').replace('。',' ')
										tx=text.replace(' ','').replace('！','').replace('？','').replace('、','')
										aa=[]

										for i in tx:
											if i.isalpha()==False and i.isnumeric()==False:
												aa.append(i)

										if len(aa)==0:
											if len(gamedate)==1:
												tx=text.replace('在','')
												gamedate.append(f"在{tx}")

											elif len(gamedate)>=3:
												gamedate.append(f" {text}")

											else:
												gamedate.append(text)

											if len(gameby)!=0:
												greenda.append(gameby[0])
												g1=greenda[-1]
												del gameby[0]

												ta=len(gamedate)
												aa=''.join(gamedate)

												if nick!=botname:
													if ta<=3:
														send(f"/w {nick} OK 目前的故事为：{aa}")

													else:
														send(f"/w {nick} OK {botnick}收到")

												if ta==1:
													send(f"/w {g1} 轮到{g1}啦 使用/w {botname} 输入一个地点或时间点")
													Thread(target=test_timer,args=(60,g1,None,)).start()

												elif ta==2:
													send(f"/w {g1} 轮到{g1}啦 使用/w {botname} 输入一个事件")
													Thread(target=test_timer,args=(60,g1,None,)).start()

												else:
													send(f"/w {g1} 轮到{g1}啦 目前的故事为：\n{aa}")
													time.sleep(zz)
													send(f"/w {g1} 使用/w {botname} 给后面的内容续写1~n句话")
													Thread(target=test_timer,args=(120,g1,None,)).start()

												if g1==username:
													ur=f"@{username} "*3
													print(f"[{botname}]\n{ur}轮到你了\n")

											else:
												send("嗨害嗨 故事新鲜出炉啦")
												time.sleep(ee)
												aa=''.join(gamedate)
												send(aa)
												time.sleep(zz)

												bb=[]
												ff=[]

												for nn in greenda[1:]:
													if len(bb)<3:
														dd=gamedate[greenda.index(nn)-1]
														bb.append(f"{dd}（{nn}）")

													else:
														dd=gamedate[greenda.index(nn)-1][1:]
														ff.append(f"{dd}（{nn}）")

												b='\n'.join(bb)
												f='\n'.join(ff)

												if g0==3:
													send(f"·\n详细信息：\n{b}\n·\n本次参与人数：{g0}")

												else:
													send(f"·\n开头：\n{b}\n·\n续写：\n{f}\n·\n本次参与人数：{g0}")

												gameby.clear()
												gamedate.clear()
												greenda.clear()

										else:
											send(f"/w {nick} 失败 包含无效的字符")

									elif nick in gameby:
										send(f"/w {nick} {nick}别急-排好队等待吧")

									else:
										send(f"/w {nick} {nick}快坐回观众席 发jill胶水咯")

								else:
									send(f"/w {nick} 别急-游戏还没开始呢")


	def main_2():

		socket=socket1
		chatroom=chatroom1
		channel=channel1

		def main_more():

			'''
				优先级：simplify（模式）
			'''

			# 引用函数外变量
			global wss,wws,botname,botpass,botnick,simplify,block_bot,using

			# 循环判定
			while True:

				# 随机等待时间
				zz=random.choice([0.1,0.15,0.2])
				ee=random.choice([0.3,0.35,0.4])

				if wws!=wss:
					wws=wss

					if "cmd" in wss:
						cmd=wss["cmd"]

						if cmd=="chat":
							nick=wss["nick"]
							text=wss["text"]
							leve=wss["level"]

							# bot私聊用
							per=f"/w {nick} .\n·\n"

							# 为防止刷屏而屏蔽bot昵称
							if f"{nick}\n" not in bot and "eebot" not in nick:
								block_bot=True

							else:
								block_bot=False

							if using==True:
								if f"[{username}]" in text[:len(username)+3]:
									text=text[len(username)+3:]

							if block_bot==True or using==True:
								using=False

								if text in ["统计","sts"]:
									fp=os.listdir(f"chats/{chatroom}/statistics")
									pf={}
									ff=[]
									pp=0

									for oos in fp:
										a=open(f"chats/{chatroom}/statistics/{oos}","r").readlines()
										pf[oos.replace('.txt','')]=len(a)

									f=sorted(pf.items(),key=lambda pf:pf[1],reverse=True)

									for key,values in f:
										pp+=values

									for key,values in f:
										kk=100*int(values)/int(pp)
										nn=''

										if kk==0.0:
											nn='0%'

										else:
											nn=f'%.2f%%'%kk

										mm=len(ff)+1
										kk=f"{mm}.{key}: {values}（{nn}）"
										ff.append(kk)
										
									p='\n'.join(ff)
									y=divmod(round(time.time()-yy),60)
									d=divmod(y[0],60)
									s=d[0]
									i=d[1]
									m=y[1]
									send(f"{per}启动时间：{ww}\n存活时长：{s}h {i}min {m}s\n·\n总排行：\n{p}\n·\n总条数：{pp}\n本次条数：{chat_date}")

								if text in ["功能","order"] and simplify==True:
									er=''

									if resee==False:
										fp=open("record/[main] order_terse.txt","r")
										er=fp.read().replace('——',botname)

									elif resee==True:
										fp=open("record/[main] order_tersee.txt","r")
										er=fp.read().replace('——',botname)

									if "ZhangHelper" in nicks1:
										er=er.replace('u—','漂流瓶｜drift：让bot随机扔漂流瓶')

									else:
										er=er.replace('u—','')

									send(per+er)

								if text in ["帮助","help"]:
									fp=open("record/[main] help.txt","r")
									he=fp.read()
									send(per+he)

								if text in ["开源","eebot"]:
									fp=open("record/[main] eebot.txt","r")
									bo=fp.read()
									send(per+bo)

								if text in ["网站","web"]:
									fp=open("record/[record] web.txt","r")
									wb=fp.read()
									we=wb.split("·")

									if len(we)<=30:
										bw='·'.join(we)
										send(per+bw)

									else:
										bw='·'.join(we[-30:])
										send(per+bw)

								if text in ["机器人","bot"]:
									fp=open("record/[main] bot.txt","r")
									bo=fp.read()
									send(per+bo)

								if text in ["漂流瓶","drift"] and "ZhangHelper" in nicks1:

									# api: SuixinAPI
									api="http://api.botwl.cn/api/yhyl"
									se=requests.get(api)
									see=se.text.replace('。',' ').replace('，',' ')
									send(f"/w ZhangHelper ^cb 「{see}」")
									send("已发送~不知道会被谁捡到")

								if text in ["在线","online"]:
									a='\n'.join(nicks1)
									b=len(nicks1)
									c='\n'.join(nicks2)
									d=len(nicks2)
									e=f"[{chatroom}｜{channel}]（{b}）\n{a}"
									send(per+e)

									if peep==True and d!=0:
										g=f"[{chatroom2}｜{channel2}]（{d}）\n{c}"
										send(per+g)

								if text in ["时间","time"]:

									# 获取计算机时间
									send(time.strftime("Time %a %Y.%m.%d %H:%M:%S",time.localtime()))

								# 查看af列表
								if text in ["挂机列表","list"]:

									# 若af的长度为0
									if len(afklist)==0:
										send("None")

									else:
										listt=[]

										for a in afklist:
											b=afklist[a]
											c=random.choice(["怎么可以-","不是吧-","不-","天哪-"])

											if "操" in b or "草" in b or "屎" in b:
												listt.append(f"@{a} 现在在{b}（{c}")

											else:
												listt.append(f"@{a} 现在在{b}")

										# 输出列表
										c='\n'.join(listt)
										d=len(listt)
										time.sleep(zz)
										send(f"·\n挂机列表（{d}）：\n{c}")

								# 如果昵称在列表里
								if nick in afklist:
									a=afklist[nick]

									# 不能重复挂机
									if "afk" in text[:3]:
										send(f"@{nick} 已经在{a}了")

									else:
										# 把昵称从列表中移除
										send(random.choice([f"@{nick} 停止了{a}",f"@{nick} 现在没在{a}了"]))
										del afklist[nick]

								# 如果昵称不在列表里
								if nick not in afklist:
									if "afk" in text[:3]:
										t3=text[3:]
										t4=text[4:]

										if t3.strip()=="":
											send(f"@{nick} 现在在离开键盘")
											afklist[nick]="离开键盘"

										elif text[3]==" ":
											send(f"@{nick} 现在在{t4}")
											afklist[nick]=t4

										# 退出真心话游戏
										if trueword==False and len(gamename)!=0 and nick in gameby:
											a=gameby.index(nick)
											time.sleep(ee)
											send(f"@{nick} 已离开真心话游戏")
											del gamedate[a]
											del gameby[a]

								if f"@{botname}" not in text:

									# 如果有人提到了挂机成员
									for name in afklist:

										# 提示该成员在afk状态
										if f"@{name}" in text:
											a=afklist[name]
											send(f"@{name} 现在在{a}")

		def main_send():

			# 一直循环
			while True:

				# 如果收到窥屏消息
				if transmit==True and len(tsend)!=0:
					send(tsend[0])
					tsend.clear()

				else:
					time.sleep(0.2)

		ths = []

		# 开启多线程
		for func in [main_more,main_send]:
		    ths.append(Thread(target=func))
		    ths[-1].start()

		for th in ths:
			th.join()


	def send_message():

		'''
			优先级：sendms（手动）>using（使用）
		'''

		# 引用函数外变量
		global sendms,using

		# 如果允许手动发送消息
		if sendms==True:

			# 一直循环
			while True:
				try:
					aa=open("send_message.txt","r+")
					bb=aa.read()

				except:
					time.sleep(0.2)

				if bb!="":
					using=True

					if "O-" in bb[:2]:
						Thread(target=online_code,args=(bb[2:],username,'eeeeee',)).start()

					elif "/" in bb[0] or "^" in bb[0]:
						send(bb)

					else:
						send(f"[{username}] {bb}")

					aa.truncate(0)
					aa.close()

				else:
					aa.close()
					time.sleep(0.2)

		else:
			# 结束进程
			sys.exit(0)


	def heart_beat():
		while True:
			try:
				time.sleep(30)
				ws.send(json.dumps({'cmd':'ping'}))

				if transmit==True:
					wsss.sendd(json.dumps({'cmd':'ping'}))

			except:
				time.sleep(30)


	def time_line():

		'''
			优先级：timeline（时间线）>simplify（模式）>ad（广告）
		'''

		# 引用函数外变量
		global timeline,ad,simplify

		# 如果时间线通知打开
		if timeline==True:

			socket=socket1
			chatroom=chatroom1
			channel=channel1

			# 一直循环
			while True:	

				# 用来判断星期几
				dah=time.strftime("%H:%M",time.localtime())
				daw=time.strftime("%M",time.localtime())
				wek=datetime.date(int(time.strftime("%Y")),int(time.strftime("%m")),int(time.strftime("%d"))).weekday()

				if timeline==True and simplify==False:
					if wek<5:
						if dah=="07:40" or dah=="13:40":
							send(random.choice([f"{username}已经去上学啦",f"{username}现在已经在学校了",f"已自动标记{username}为早读状态"]))

						elif dah=="11:40" or dah=="18:20":
							send(random.choice([f"{username}已经放学了 不知道什么时候回来",f"{username}正在回家的路上",f"{username}差不多快回家了"]))

					if wek>=5 and dah=="23:00":
						send(random.choice(["已结0点了 在线的各位快去睡！","不能当夜猫子哦（doge",f"{botnick}好困",f"{botnick}也该去睡觉了"]))

					if wek==6 and dah=="15:00" or wek==6 and dah=="17:00":
						send(random.choice([f"@{username} 快去写作业！",f"@{username} 作~业·写·完·了·吗？",f"@{username} 别忘了作业哦"]))

					if ad==True:
						if dah=="12:00":
							fp=open("record/[random] paper.txt","r")
							z=fp.readlines()
							p=random.choice(z)
							j=p.strip('\n')
							send(f"![]({j})")

						if daw=="13":
							fp=open("record/[random] trees.txt","r")
							t=fp.readlines()
							r=random.choice(t)
							e=r.replace('\\n','\n')
							send(f"·\n{e}")

					timeline=False

				else:
					time.sleep(60)
					timeline=True

		else:
			# 结束进程
			sys.exit(0)


	def second_main():

		'''
			优先级：peep（窥屏）>transmit（跨服）
		'''

		# 引用函数外变量
		global wsss,chatroom1,channel1,peep,transmit

		# 如果窥屏开关打开
		if peep==True:

			try:
				# 连接聊天室
				wsss=websocket.WebSocket()
				wsss.connect(socket2)
				send(f"本聊天室已连通 [{chatroom2}｜{channel2}] ")

			except:
				# 结束进程
				send(f"无法连接至 [{chatroom2}｜{channel2}]")
				peep==False
				sys.exit(0)

			taken=str(random.randint(1,999))
			botname_taken=f"{botname}_{taken}"
			wsss.send(json.dumps({"cmd":"join","channel":channel2,"nick":botname_taken,"password":botpass,"token":"papereebot"}))
			sendd("/color 44FF00")
			sendd(f"本聊天室已连通 [{chatroom1}｜{channel1}]")

			def second_peep():

				# 一直循环
				while True:

					# 保存文件的时间
					chat=time.strftime("%Y.%m.%d")
					write=open(f"chats/{chatroom2}/[{chat}] {channel2}.txt","a+")

					try:
						# 接收到的json数据
						wssss=json.loads(wsss.recv())

					except:
						wssss=''
						time.sleep(1)

					if "cmd" in wssss:
						cmd=wssss["cmd"]

						if cmd=="onlineSet":

							# 开始记录日志
							nicks=wssss["nicks"]

							for nick in nicks:
								if "｜" not in nick:
									if chatroom2==hc or chatroom2==cc:
										if "XC_" not in nick:
											nicks2.append(nick)

									else:
										nicks2.append(nick)

						elif cmd=="onlineAdd":
							nick=wssss["nick"]

							if chatroom2==hc or chatroom2==cc:
								if "XC_" not in nick:
									nicks2.append(nick)

							else:
								nicks2.append(nick)

						elif cmd=="onlineRemove":
							nick=wssss["nick"]

							if nick in nicks2:
								nicks2.remove(nick)

						elif cmd=="chat":
							nick=wssss["nick"]
							text=wssss["text"]

							if transmit==True and nick!=botname_taken and f"{nick}\n" not in bot:
								if "trip" in wssss and wssss["trip"].strip()!='':
									trip=wssss["trip"]
									ff=f"[{trip}] {nick}\n{text}"
									tsend.append(ff)

								else:
									ff=f"[None] {nick}\n{text}"
									tsend.append(ff)

			def second_send():
				while True:

					# 如果是正常模式
					if simplify==False and transmit==True and len(tsmit)!=0:
						sendd(tsmit[0])
						tsmit.clear()

					else:
						time.sleep(0.2)

			ths = []

			# 开启多线程
			for func in [second_peep,second_send]:
			    ths.append(Thread(target=func))
			    ths[-1].start()

			for th in ths:
				th.join()

		else:
			# 结束进程
			sys.exit(0)


	ths = []

	# 开启多线程
	for func in [main_1,main_2,send_message,heart_beat,time_line,second_main]:
	    ths.append(Thread(target=func))
	    ths[-1].start()

	for th in ths:
	    th.join()
