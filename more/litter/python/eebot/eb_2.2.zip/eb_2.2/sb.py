﻿import random

# 初始化
with open("record/[maggie] sbres.txt","r") as f:
	text=f.read().split("\n·\n")
	who=text[0].split("\n")
	where=text[1].split("\n")
	sth=text[2].split("\n")

def sb():
	ra=random.choice(who)
	rb=random.choice(where)
	rc=random.choice(sth)
	return f"{ra}在{rb}{rc}"

def sbs():
	rb=random.choice(where)
	return rb

def sbsb():
	rc=random.choice(sth)
	return rc

def showall():
	jz=[]
	jzstr=""

	for a in who:
		for b in where:
			for c in sth:
				jz.append(f"{a}在{b}{c}")

	for i in jz:
		jzstr+=i
		jzstr+="\n"

	jzstr+="共有"
	jzstr+=str(len(jz))
	jzstr+="种组合。"
	return jzstr
