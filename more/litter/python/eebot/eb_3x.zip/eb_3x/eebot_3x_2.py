import websocket
import requests
import json
import time
import random
import re
import calendar
try:
	import thread
except:
	import _thread as thread

def sendd(text):
	return json.dumps({"cmd":"chat","text":str(text)})
	
def fanyi(strr):
	data = {"doctype":"json","type":"AUTO","i":str(strr)}
	headers = {"User-Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0"}
	url = "http://fanyi.youdao.com/translate"
	try:
		r = requests.get(url,params = data,headers = headers,timeout = 10)
		if r.status_code == 200:
			result = r.json()
			resultt = result["translateResult"][0][0]["tgt"]
			return resultt

	except:
		pass
	
class runbox:
	def __init__(self,room,name,pas):
		self.room = room
		self.name = name
		self.pas = pas
		self.wuhu = []
		self.site = []
		self.join = []
		self.play = []
		self.game = []
		self.afk = []
		self.by = []
		self.tran = False
		self.true = False
		self.story = False
		self.flower = False
	
	def handle(self,json_data):
		self.json_data = json_data
		if "cmd" in self.json_data:
			if self.json_data["cmd"] == "chat":
				self.chat()

			elif self.json_data["cmd"] == "onlineAdd":
				self.onlineadd()

			elif self.json_data["cmd"] == "onlineSet":
				self.onlineset()

			else:
				pass

	def chat(self):
		zz = random.choice([0.15,0.2,0.25])
		ee = random.choice([0.45,0.5,0.55])
		qq = [":)",":(",":O",":o",":D","¬_¬","-_-","-.-","-︵-","—.—","—︵—","⌒-⌒","￣︶￣","￣⌒￣","￣ˇ￣","u.u","u_u","n_n","n.n"]
		pp = ["._.","。_。","。.。","°-°","°⌒°","°▽°","°O°","°︶°","°～°","°ˇ°","o.o","o︵o","O.O","OuO","O︵O","0.0","0u0","0︵0"]
		meme = random.choice(qq + pp)
		chat = time.strftime("%Y.%m.%d")
		room = self.room
		b = chat + " " + room + ".txt"
		with open(b,"a+") as fp:
			a = time.strftime("%H:%M:%S",time.localtime())
			ms = a + " " + self.json_data["nick"] + "\n" + self.json_data["text"] + "\n\n"
			fp.write(ms)

		if len(self.wuhu) == 10:
			self.wuhu.clear()
			time.sleep(ee)
			ws.send(sendd("已自动清空推荐记录"))
	
		if len(self.site) == 10:
			self.site.clear()
			time.sleep(ee)
			ws.send(sendd("已自动清空随机记录"))

		if self.json_data["nick"] not in ["eebot","eeebot","eeeebot"]:
			if self.json_data["text"] in ["功能","order"]:
				a = "·\n随机：七濑胡桃/heal, 小姐姐/cutie, 阿鲁/aru, 涩图/acg, 头像/head, 音乐/music, 随机/r\n"
				b = "日历/cal, 农历/date, 表情/meme, 换色/color, 时间/time, 挂机/afk, 翻译/tran\n"
				c = "·\n其他：一言, 励志, 抽签, 笑话, 情话, 骚话, 古诗词, 彩虹屁, 毒鸡汤, 今日曰\n"
				d = "舔狗日记, 社会语录, 历史今天, 网易热评, 摸鱼日历, 今日世界\n"
				e = "·\n无聊专用：飞花令, 真心话, 功能/order, 帮助/help, 重置/clear\n"
				f = "推荐/wuhu, 树洞/tree, 趣站/site, 游戏/game, 网盘/pan, 聊天室/chat\n"
				g = "·\n不会使用？试试在下面「聊天框」里发送上面的命令吧"
				time.sleep(zz)
				ws.send(sendd(a + b + c + d + e + f + g))

			if self.json_data["text"] in ["帮助","help"]:
				a = "·\nhc指令：https://tieba.baidu.com/p/6833224084\n"
				b = "hc百科：https://chumo.sbsbsb.sbs/wiki\n"
				c = "hc同人作品集：https://note.ms/HCworks111\n"
				d = "hc出现过的人：https://tieba.baidu.com/p/7153686343"
				d = "·\n这是部分有关hack.chat的链接 欢迎投稿"
				time.sleep(zz)
				ws.send(sendd(a + b + c + d))

			if self.json_data["text"] in ["翻译","tran"]:
				a = "·\n使用源：网易有道翻译\n使用方法：·要翻译的句子（前面有个点\n"
				b = "·\n默认为关：「翻译开启」「翻译关闭」"
				time.sleep(zz)
				ws.send(sendd(a + b))

			if self.json_data["text"] in ["翻译开启"]:
				if self.tran == True:
					time.sleep(zz)
					ws.send(sendd("翻译本来就为True"))

				else:
					time.sleep(zz)
					ws.send(sendd("翻译已开启"))
					self.tran = True

			if self.json_data["text"] in ["翻译关闭"]:
				if self.tran == False:
					time.sleep(zz)
					ws.send(sendd("翻译本来就为False"))

				else:
					time.sleep(zz)
					ws.send(sendd("翻译已关闭"))
					self.tran = False

			if self.json_data["text"] in ["重置","clear"]:
				self.wuhu.clear()
				self.site.clear()
				time.sleep(zz)
				ws.send(sendd("已清空所有随机记录"))

			if self.json_data["text"] in ["推荐","wuhu"]:
				c1 = "「Gun Gale Online」\n类型：日本动漫 轻小说 日本漫画\n标签：游戏 战斗 反差萌"
				c2 = "「间谍教室」\n类型：轻小说 日本漫画\n标签：推理 欢乐向 斗智斗勇"
				c3 = "「不知我的死亡Flag将于何处停止」\n类型：日本漫画\n标签：转生 拆旗 事业流"
				c4 = "「杀戮天使」\n类型：游戏 日本动漫 轻小说 日本漫画\n标签：悬疑 治愈 靠谱"
				c5 = "「尸体派对」\n类型：游戏 日本动漫 日本漫画\n标签：恐怖 猎奇 前方高能"
				c6 = "「舞铲幼女与魔眼王」\n类型：轻小说 日本漫画\n标签：萝莉 冒险 携手战斗"
				c7 = "「绯红魔导书」\n类型：日本漫画\n标签：百合 战斗 黑暗风"
				c8 = "「幸色的一居室」\n类型：日剧 日本漫画\n标签：诱拐犯 爱情 治愈"
				c9 = "「来自深渊」\n类型：日本动漫 日本漫画\n标签：冒险 毛茸茸 黑暗风"
				c10 = "「最终休止符 -无止境的螺旋物语-」\n类型：游戏 日本动漫\n标签：冒险 萌系 欢乐向"
				c11 = "「婚约者恋上我的妹妹」\n类型：轻小说 日本漫画\n标签：致郁 轮回 爱而不得"
				c12 = "「老师温柔的杀人方法」\n类型：日本漫画\n标签：爱情 悬疑 杀人推理"
				c13 = "「最弱的驯养师开启的捡垃圾的旅途」\n类型：轻小说 日本漫画\n标签：萝莉 冒险 治愈"
				c14 = "「童话大逃杀」\n类型：日本漫画\n标签：冒险 童话风 黑暗风"
				c15 = "「大海原与大海原」\n类型：日本漫画\n标签：冒险 治愈"
				c15 = "「神不在的星期天」\n类型：日本动漫 轻小说 日本漫画\n标签：成长 冒险 治愈"
				c16 = "「纳尼亚传奇：魔法师的外甥」\n类型：名著 日本漫画\n标签：穿越 冒险 经典作品"
				c17 = "「中之人基因组」\n类型：日本动漫 日本漫画\n标签：冒险 多主角 实况中"
				c18 = "「喜欢的不是女儿，而是我吗！？」\n类型：轻小说 日本漫画\n标签：日常 年龄差 恋爱喜剧"
				c19 = "「从零开始的魔法书」\n类型：日本动漫 轻小说 日本漫画\n标签：兽人 冒险 美少女"
				c20 = "「落后的驯兽师慢生活」\n类型：轻小说 日本漫画\n标签：正太 游戏 种田"
				c21 = "「厄里斯的圣杯」\n类型：轻小说 日本漫画\n标签：推理 恶役 种田"
				c22 = "「葬送的芙莉莲」\n类型：日本漫画\n标签：冒险 魔法 感人泪下"
				c23 = "「转生成蜘蛛又怎样！」\n类型：日本动漫 轻小说 日本漫画\n标签：转生 蜘蛛子 双主线"
				c24 = "「最近，妹妹的样子有点怪？」\n类型：日剧 日本动漫 日本漫画\n标签：骨科 日常 恋爱喜剧"
				c25 = "「无能的奈奈」\n类型：日本动漫 日本漫画\n标签：悬疑 校园 斗智斗勇"
				c26 = "「灾祸的真理」\n类型：游戏 日本动漫 日本漫画\n标签：悬疑 战斗 剧情紧凑"
				c27 = "「LOST SONG」\n类型：日本动漫\n标签：治愈 冷门向 音乐作"
				c28 = "「败犬女主也太多了！」\n类型：轻小说\n标签：脑洞 败犬故事 恋爱喜剧"
				c29 = "「因为太怕痛就全点防御力了」\n类型：日本动漫 轻小说 日本漫画\n标签：游戏 冒险 凤傲天"
				c30 = "「罪恶王冠」\n类型：日本动漫\n标签：悬疑 战斗 幻想"
				c31 = "「来自多彩世界的明天」\n类型：日本动漫\n标签：成长 治愈 感人泪下"
				c32 = "「关于我转生变成史莱姆这档事」\n类型：游戏 日本动漫 轻小说\n标签：冒险 史莱姆 欢乐向"
				c33 = "「社会我鸡哥，人狠话不多」\n类型：日本漫画\n标签：战斗 主角鸡 核氢核锂"
				c34 = "「犬与屑」\n类型：日本漫画\n标签：悬疑 伦理 黑暗风"
				c35 = "「学园孤岛」\n类型：日本动漫 日本漫画\n标签：悬疑 治愈 擦眼泪"
				c36 = "「凹凸魔女的母女故事」\n类型：日本漫画\n标签：百合 日常 欢乐向"
				c37 = "「猪肝热热吃」\n类型：轻小说 日本漫画\n标签：主角猪 美少女 冒险"
				c38 = "「即使世界毁灭每一天依然快乐」\n类型：日本漫画\n标签：末世 治愈 毛茸茸"
				c39 = "「转生魔女宣告灭亡」\n类型：日本漫画\n标签：少女 爱情 魔法"
				c40 = "「骨龙的宝贝」\n类型：日本漫画\n标签：冒险 颜艺 养女儿"
				c41 = "「雾雨飘散之森」\n类型：游戏 日本漫画\n标签：悬疑 冒险 解谜游戏"
				c42 = "「女王陛下的异世界战略」\n类型：轻小说 日本漫画\n标签：虫族 战斗 猎奇"
				c43 = "「魔女之家：艾莲日记」\n类型：游戏 轻小说 日本漫画\n标签：恐怖 致郁 解谜游戏"
				c44 = "「恶魔的谜语」\n类型：日本动漫 日本漫画\n标签：百合 战斗 暗杀"
				c45 = "「魔女的心脏」\n类型：日本漫画\n标签：少女 治愈 旅行途中"
				c46 = "「魔法少女site」\n类型：日本动漫 日本漫画\n标签：百合 黑暗风 魔法少女"
				c47 = "「我推的孩子」\n类型：日本漫画\n标签：偶像 转生 误会系"
				c48 = "「转生成为魔剑」\n类型：轻小说 日本漫画\n标签：主角剑 养女儿 战斗"
				c49 = "「沉默的魔女」\n类型：轻小说\n标签：少女 推理 魔法"
				c50 = "「BNA」\n类型：日本动漫 轻小说\n标签：冒险 治愈 视觉系"
				c51 = "「约定的梦幻岛」\n类型：日本动漫 轻小说 日本漫画\n标签：悬疑 致郁 逃生"
				c52 = "「在魔王城说晚安」\n类型：日本动漫 日本漫画\n标签：治愈 萌系 欢乐向"
				c53 = "「奇诺之旅」\n类型：日本动漫 轻小说 日本漫画\n标签：旅行 冒险 引人深思"
				c54 = "「烧开水勇者的复仇记」\n类型：日本漫画\n标签：百合 复仇 携手战斗"
				c55 = "「恶魔战线」\n类型：日本动漫 日本漫画\n标签：爱情 悬疑 吸血鬼"
				c56 = "「该死的告白日」\n类型：韩国漫画\n标签：悬疑 感人 前方高能"
				c57 = "「开局一条鲲」\n类型：中国漫画\n标签：玄幻 冒险 双女主"
				c58 = "「花非花」\n类型：中国漫画\n标签：帝王 养成 古风"
				c59 = "「血族Bloodline」\n类型：游戏 中国漫画\n标签：年代 战斗 吸血鬼"
				c60 = "「血族维他命」\n类型：中国漫画\n标签：年代 恋爱 吸血鬼"
				w1 = "「宿命回响」\n类型：游戏 日本动漫\n标签：剧情 音乐 奇幻\n地址：https://movie.douban.com/subject/35417875"
				w2 = "「我要成为双马尾」\n类型：日本动漫 轻小说\n标签：剧情 性转 美少女\n地址：https://movie.douban.com/subject/25793397"
				w3 = "「巨龙山谷」\n剧情：意识流\n建模：堪称「极致美学」\n备注：千万别看，你会猝死。啊啊啊，我要犭"
				w4 = "「刺客信条：王朝」\n类型：游戏 中国漫画\n标签：冒险 历史 武侠\n推荐：L"
				j1 = "\n地址：https://movie.douban.com/subject/35296324"
				j2 = "\n·\n你看看，我看看\n大家一起去阴间\n白内障，脑血栓\n全都给我得一遍\n草起来了，蚌埠住了\n你来看，我来看\n阴间的路会变短"
				j3 = "\n编曲：蜜雪冰城\n推荐/填词：ww"
				aa = random.choice([c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20])
				bb = random.choice([c21,c22,c23,c24,c25,c26,c27,c28,c29,c30,c31,c32,c33,c34,c35,c36,c37,c38,c39,c40])
				cc = random.choice([c41,c42,c43,c44,c45,c46,c47,c48,c49,c50,c51,c52,c53,c54,c55,c56,c57,c58,c59,c60])
				c = "·\n" + random.choice([aa,bb,cc]) + "\n推荐：ee"
				w = "·\n" + random.choice([w1+"\n推荐：ww",w2+"\n推荐：ww",w3+j1+j2+j3,w4])
				wuhu = random.choice([c,w])

				if c in self.wuhu and w in self.wuhu:
					time.sleep(zz)
					ws.send(sendd("诶诶诶 {}中奖了 再试一次吧".format(self.json_data["nick"])))
	
				elif c in self.wuhu:
					time.sleep(zz)
					ws.send(sendd(w))
					self.wuhu.append(w)
	
				elif w in self.wuhu:
					time.sleep(zz)
					ws.send(sendd(c))
					self.wuhu.append(c)
	
				else:
					time.sleep(zz)
					ws.send(sendd(wuhu))
					self.wuhu.append(wuhu)

			if self.json_data["text"] in ["树洞","tree"]:
				f0 = random.choice(["13和ee的轻小说屋 old\nhttps://lidualhistory.mysxl.cn","JSH的主页\nhttps://jshang.cf"])
				f1 = random.choice(["flaugh的个人博客\nhttps://xsdboke.mysxl.cn","Sprinkle博客\nhttps://pntang.github.io"])
				f2 = random.choice(["智障初墨的个人主页\nhttps://chumo.sbsbsb.sbs","贤者13的树洞\nhttps://sage-thirteen.mysxl.cn"])
				f3 = random.choice(["Bird's Page\nhttps://fuckbird.sbsbsb.sbs","Beluga's YouTube\nhttps://youtube.com/c/Beluga1"])
				f4 = random.choice(["MuRongPIG's GitHub\nhttps://github.com/MuRongPIG","朽木自雕\nhttp://blog.noxx.cn"])
				f5 = random.choice(["纸片君ee的个人主页\nhttps://paperee.tk","13和ee的小说屋 new\nhttps://novelhouse.mysxl.cn"])
				f = "·\n" + random.choice([f0,f1,f2,f3,f4,f5])
				if f in self.site:
					time.sleep(zz)
					ws.send(sendd("嘿嘿～eebot偷懒了"))
				
				else:
					time.sleep(zz)
					ws.send(sendd(f))
					self.site.append(f)

			if self.json_data["text"] in ["趣站","site"]:
				s0 = random.choice(["ISS Docking Simulator\nhttps://iss-sim.spacex.com","STROBE\nhttps://strobe.cool"])
				s1 = random.choice(["Form Follows Function\nhttp://fff.cmiscm.com","In Pieces\nhttp://species-in-pieces.com"])
				s2 = random.choice(["Chrome Music Lab\nhttps://musiclab.chromeexperiments.com/Song-Maker","Calm\nhttps://calm.ovh"])
				s3 = random.choice(["Staggering Beauty\nhttp://www.staggeringbeauty.com","Mikutap\nhttps://aidn.jp/mikutap"])
				s4 = random.choice(["Koalas to the Max dot Com\nhttp://koalastothemax.com","OREOOO\nhttp://ljl.li/oreooo"])
				s5 = random.choice(["即刻到账\nhttps://saythemoney.github.io","Microsculpture\nhttp://microsculpture.net"])
				s6 = random.choice(["我爱工作\nhttps://ilove.works","卡巴斯基网络威胁实时地图\nhttps://cybermap.kaspersky.com/cn"])
				s7 = random.choice(["Yoichi Kobayashi\nhttps://www.tplh.net","跳跃的小球\nhttp://guozhivip.com/fun"])
				s8 = random.choice(["今天吃啥呀\nhttp://guozhivip.com/eat","便携小空调\nhttps://ac.yunyoujun.cn"])
				s9 = random.choice(["The Zen Zone\nhttps://thezen.zone","网页小游戏列表\nhttps://xingye.me/game"])
				s10 = random.choice(["Bruno Simon\nhttps://bruno-simon.com","Coding Cat\nhttps://hostrider.com"])
				s11 = random.choice(["架子鼓\nhttp://guozhivip.com/jzg","Nomadic Tribe\nhttps://2019.makemepulse.com"])
				s12 = random.choice(["The Blocks\nhttps://blocks.ovh","Sequencer64\nhttps://www.sequencer64.com"])
				s13 = random.choice(["Bubble wrap pop\nhttps://bubblespop.netlify.app","Sharkle\nhttps://sharkle.com"])
				s14 = random.choice(["Kick Ass\nhttps://kickassapp.com","Patatap\nhttps://www.patatap.com"])
				s15 = random.choice(["星弈小游戏平台\nhttp://other.noxx.cn/play","全景故宫\nhttps://pano.dpm.org.cn"])
				s = "·\n" + random.choice([s0,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15])
				if s in self.site:
					time.sleep(zz)
					ws.send(sendd("不给不给 就是不给{}".format(self.json_data["nick"])))
	
				else:
					time.sleep(zz)
					ws.send(sendd(s))
					self.site.append(s)
	
			if self.json_data["text"] in ["游戏","game"]:
				g0 = random.choice(["Phigros\nhttps://pgr.han-han.xyz/tapToStart","defly\nhttps://defly.io"])
				g1 = random.choice(["和焦虑一起冒险\nhttps://z-lyen.github.io/anxiety","RICHUP\nhttps://richup.io"])
				g2 = random.choice(["Red Carpet Rampage\nhttps://rcr.heheda.top","Raaaaft\nhttps://raaaaft.io"])
				g3 = random.choice(["名字竞技场\nhttp://namerena.github.io","Nazo Game\nhttps://nazo.one-story.cn"])
				g4 = random.choice(["HTML5 杯\nhttp://html5cup.kayac.com","株式会社 闇\nhttps://death.co.jp/ja/pc"])
				g5 = random.choice(["Line Rider\nhttps://www.linerider.com","Dino Swords\nhttps://dinoswords.gg"])
				g6 = random.choice(["信任的进化\nhttps://dccxi.com/trust","2020 Game\nhttps://2020game.io"])
				g7 = random.choice(["Minecraft Classic\nhttps://classic.minecraft.net","Gartic\nhttps://gartic.io"])
				g8 = random.choice(["YORG\nhttps://yorg.io","我们变成了我们所看到的\nhttps://claycoffee.github.io/wbwwb"])
				g9 = random.choice(["西游梗传\nhttp://littlegame.tomato123.cn/xiyou","太鼓ウェブ\nhttps://taiko.bui.pm"])
				g10 = random.choice(["florr\nhttps://florr.io","人生重开模拟器\nhttp://liferestart.syaro.io/public"])
				g11 = random.choice(["Taming\nhttps://taming.io","ふぁんしーあいらんど\nhttp://lomando.com/main.html"])
				g12 = random.choice(["Manyland\nhttp://manyland.com","Undercards\nhttps://undercards.net/Quests"])
				g13 = random.choice(["Minecraft 网页版\nhttps://craft.spr233.eu.org/"])
				g = "·\n" + random.choice([g0,g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12,g13])
				if g in self.site:
					time.sleep(zz)
					ws.send(sendd("哼 不给 不可以贪心哦～"))
	
				else:
					time.sleep(zz)
					ws.send(sendd(g))
					self.site.append(g)

			if self.json_data["text"] in ["网盘","pan"]:
				p0 = random.choice(["勿待炬火网盘\nhttps://pan.weunite.top","樱忆云盘\nhttps://drive.loili.com"])
				p1 = random.choice(["雨滴云盘\nhttp://pan.handanxiaochipeixun.top:5212","AcgngameCloud\nhttps://acgngame.cloud"])
				p2 = random.choice(["Cloudreve\nhttps://cloudreve.zjh336.cn","爱丽丝的记事本\nhttps://drive.noire.cc"])
				p3 = random.choice(["小太阳云存储\nhttps://cncncloud.com","比邻云盘\nhttps://pan.bilnn.cn"])
				p4 = random.choice(["萌云\nhttps://moecloud.cn","AnonFiles\nhttps://anonfiles.com"])
				p5 = random.choice(["文叔叔\nhttps://www.wenshushu.cn","TMP.link\nhttps://app.tmp.link"])
				p = "·\n" + random.choice([p0,p1,p2,p3,p4,p5])
				if p in self.site:
					time.sleep(zz)
					ws.send(sendd("eebot企图让{}再试一次".format(self.json_data["nick"])))
	
				else:
					time.sleep(zz)
					ws.send(sendd(p))
					self.site.append(p)

			if self.json_data["text"] in ["聊天室","chat"]:
				h0 = random.choice(["hack.chat\nhttps://hack.chat","小蝌蚪互动聊天室\nhttp://zzzgd.info/kedou"])
				h1 = random.choice(["BBBUG 聊天室\nhttp://chat.zzzgd.info","星弈微聊\nhttps://im.noxx.cn"])
				h2 = random.choice(["蔷薇花园\nhttps://iirose.com","爱聊友\nhttps://im.ailyoo.com"])
				h3 = random.choice(["网页聊天\nhttps://wylt.com/r/XianLiao","十字街\nhttps://crosst.chat"])
				h4 = random.choice(["DOLLARS 聊天室\nhttps://drrr.com","hichat\nhttp://hichat.herokuapp.com"])
				h5 = random.choice(["BBBUG 音乐聊天室\nhttps://bbbug.com","多人听歌网\nhttps://chat.zhuolin.wang"])
				h6 = random.choice(["在线聊天\nhttps://chat.anonshacker.com/Mars","聊乎\nhttps://www.randomchat.cn"])
				h7 = random.choice(["匿名聊天室\nhttps://easonchiang7178.github.io/f2e-anonymous-chatroom","TALK2\nhttps://talk2.fun"])
				h8 = random.choice(["啊噗聊天\nhttps://www.uplt.com","fiora\nhttps://fiora.suisuijiang.com"])
				h9 = random.choice(["叔叔不约\nhttp://www.shushubuyue.com","Deskry\nhttp://v6.nm1v1.cn"])
				h10 = random.choice(["Liveany\nhttps://www.liveany.com/web.html","CamSurf\nhttps://camsurf.com"])
				h11 = random.choice(["WooTalk\nhttps://wootalk.today","陌路人\nhttp://www.moluren.net"])
				h12 = random.choice(["Anonymous\nhttps://chat42.online","MeeTunnel\nhttps://www.meetunnel.com/chat"])
				h = "·\n" + random.choice([h0,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12])
				if h in self.site:
					time.sleep(zz)
					ws.send(sendd("耶 eebot不告诉{}".format(self.json_data["nick"])))

				else:
					time.sleep(zz)
					ws.send(sendd(h))
					self.site.append(h)

			if self.json_data["text"] in ["一言"]:
				api = "https://v1.hitokoto.cn"
				response = requests.get(api)
				res = response.json()
				word = res["from"] + " " + res["creator"] + "\n「" + res["hitokoto"] + "」"
				apii = "https://api.muxiaoguo.cn/api/yiyan"
				responsee = requests.get(apii)
				ress = responsee.json()
				a = ress["data"]
				wordd = "「" + a["content"] + "」"
				apiii = "https://api.vvhan.com/api/ian"
				responseee = requests.get(apiii)
				resss = "「" + responseee.text + "」"
				ws.send(sendd(random.choice([word,wordd,resss])))

			if self.json_data["text"] in ["励志"]:
				api = "http://api.botwl.cn/api/yhyl"
				response = requests.get(api)
				res = "「" + response.text + "」"
				ws.send(sendd(res))

			if self.json_data["text"] in ["抽签"]:
				api = "http://api.botwl.cn/api/qiuqian"
				response = requests.get(api)
				res = response.text.replace('[\\n]','\n')
				ws.send(sendd(res))

			if self.json_data["text"] in ["笑话"]:
				api = "https://api.muxiaoguo.cn/api/xiaohua"
				response = requests.get(api)
				res = response.json()
				a = res["data"]
				word = "「" + a["title"] + "」\n" + a["content"]
				apii = "https://api.vvhan.com/api/xh"
				responsee = requests.get(apii)
				ress = responsee.text
				ws.send(sendd(random.choice([word,ress]).replace('“','『').replace('”','』')))

			if self.json_data["text"] in ["情话"]:
				api = "https://api.lovelive.tools/api/SweetNothings/count/Serialization/serializationType"
				response = requests.get(api)
				res = response.json()
				word = res["returnObj"]
				a = "「" + random.choice(word) + "」"
				apii = "https://api.uomg.com/api/rand.qinghua"
				responsee = requests.get(apii)
				ress = responsee.json()
				wordd = "「" + ress["content"] + "」"
				apiii = "https://api.vvhan.com/api/love"
				responseee = requests.get(apiii)
				resss = "「" + responseee.text + "」"
				ws.send(sendd(random.choice([a,wordd,resss]).replace('“','『').replace('”','』')))

			if self.json_data["text"] in ["骚话"]:
				api = "https://api.vvhan.com/api/sao"
				response = requests.get(api)
				res = "「" + response.text + "」"
				ws.send(sendd(res.replace('“','『').replace('”','』')))

			if self.json_data["text"] in ["古诗词"]:
				api = "https://api.muxiaoguo.cn/api/Gushici"
				response = requests.get(api)
				res = response.json()
				a = res["data"]
				word = a["title"] + " " + a["author"] + "\n「" + a["min_content"] + "」"
				ws.send(sendd(word))

			if self.json_data["text"] in ["彩虹屁"]:
				api = "https://api.muxiaoguo.cn/api/caihongpi"
				response = requests.get(api)
				res = response.json()
				a = res["data"]
				word = "「" + a["comment"] + "」"
				ws.send(sendd(word))

			if self.json_data["text"] in ["毒鸡汤"]:
				api = "https://api.muxiaoguo.cn/api/dujitang"
				response = requests.get(api)
				res = response.json()
				a = res["data"]
				word = "「" + a["comment"] + "」"
				apii = "http://api.btstu.cn/yan/api.php"
				responsee = requests.get(apii)
				ress = "「" + responsee.text + "」"
				ws.send(sendd(random.choice([word,ress])))

			if self.json_data["text"] in ["今日曰"]:
				api = "https://api.vvhan.com/api/en"
				response = requests.get(api)
				res = response.json()
				a = res["data"]
				b = "Today Is " + a["month"] + " " + a["day"]
				word = b + "\n「" + a["zh"] + "」" + "\n「" + a["en"] + "」"
				ws.send(sendd(word))
	
			if self.json_data["text"] in ["舔狗日记"]:
				api = "https://api.ixiaowai.cn/tgrj/index.php"
				response = requests.get(api)
				res = "「" + response.text + "」"
				apii = "https://api.muxiaoguo.cn/api/tiangourj"
				responsee = requests.get(apii)
				ress = responsee.json()
				a = ress["data"]
				word = "「" + a["comment"] + "」"
				b = "202x年xx月xx日 广东 汕头 ee\n"
				ws.send(sendd(b + random.choice([res,word]).replace('*','')))
	
			if self.json_data["text"] in ["社会语录"]:
				api = "https://api.oick.cn/yulu/api.php"
				response = requests.get(api)
				res = response.text.replace('\"','')
				word = "「" + res + "」"
				ws.send(sendd(word))
	
			if self.json_data["text"] in ["历史今天"]:
				api = "https://qqlykm.cn/api/lishi/index.php"
				response = requests.get(api)
				res = "【" + response.text + "】"
				ws.send(sendd(res))
	
			if self.json_data["text"] in ["网易热评"]:
				api = "https://api.muxiaoguo.cn/api/163reping"
				response = requests.get(api)
				res = response.json()
				a = res["data"]
				word = "来自 " + a["nickname"] + a["songName"] + "\n「" + a["content"] + "」"
				ws.send(sendd(word))
	
			if self.json_data["text"] in ["摸鱼日历"]:
				api = "https://api.vvhan.com/api/moyu"
				response = requests.get(api)
				res = response.url
				ws.send(sendd(res))
	
			if self.json_data["text"] in ["今日世界"]:
				ws.send(sendd("https://api.vvhan.com/api/60s"))
	
			if self.json_data["text"] in ["七濑胡桃","heal"]:
				api = "https://api.ixiaowai.cn/mcapi/mcapi.php"
				response = requests.get(api)
				res = response.url
				ws.send(sendd(res))
	
			if self.json_data["text"] in ["小姐姐","cutie"]:
				api = "https://cdn.seovx.com/ha/?mom=302"
				response = requests.get(api)
				res = response.url
				apii = "https://cdn.seovx.com/?mom=302"
				responsee = requests.get(apii)
				ress = responsee.url
				ws.send(sendd(random.choice([res,ress])))

			if self.json_data["text"] in ["涩图","acg"]:
				api = "https://acg.toubiec.cn/random.php"
				response = requests.get(api)
				res = response.url
				apii = "https://api.isoyu.com/aipc_animation.php"
				responsee = requests.get(apii)
				ress = responsee.url
				apiii = "https://cdn.mrpig.cf/"
				responseee = requests.get(apiii)
				resss = responseee.url
				ws.send(sendd(random.choice([res,ress,resss])))
	
			if self.json_data["text"] in ["头像","head"]:
				api = "http://api.btstu.cn/sjtx/api.php"
				response = requests.get(api)
				res = response.url
				apii = "https://api.muxiaoguo.cn/api/sjtx?method=pc"
				responsee = requests.get(apii)
				ress = responsee.json()
				a = ress["data"]
				word = a["imgurl"]
				ws.send(sendd(random.choice([res,word])))
	
			if self.json_data["text"] in ["阿鲁","aru"]:
				api = "https://api.isoyu.com/ARU_GIF_S.php"
				response = requests.get(api)
				res = response.url
				ws.send(sendd(res))
	
			if self.json_data["text"] in ["音乐","music"]:
				api = "https://api.paugram.com/acgm"
				response = requests.get(api)
				res = response.json()
				word = res["title"] + " " + res["artist"] + " \n" + res["link"]
				ws.send(sendd(word))

			if self.json_data["text"] in ["日历","cal"]:
				a = time.strftime("%Y")
				b = time.strftime("%m")
				cal = calendar.month(int(a), int(b)).replace(' ','⠀').replace('⠀⠀',' ⠀')
				time.sleep(zz)
				ws.send(sendd("⠀" + cal))

			if self.json_data["text"] in ["农历","date"]:
				api = "https://api.muxiaoguo.cn/api/yinlongli"
				response = requests.get(api)
				res = response.json()
				a = res["data"]
				word = a["lunar"] + " " + a["yearZodiac"] + " " + a["lunarYearName"] + " " + a["solarTerms"]
				apii = "http://api.botwl.cn/api/nl"
				responsee = requests.get(apii)
				ress = responsee.text.replace('\n',' ').replace('今天是','').replace('节气：','')
				time.sleep(zz)
				ws.send(sendd(random.choice([word,ress])))

			if self.json_data["text"] in ["表情","meme"]:
				time.sleep(zz)
				ws.send(sendd(meme))

			if self.json_data["text"] in ["换色","color"]:
				api = random.choice(["http://api.botwl.cn/api/sjys","https://api.vvhan.com/api/color"])
				response = requests.get(api)
				a = "/color " + response.text
				ws.send(sendd(a))
				ws.send(sendd("This Color: " + response.text + "\nOld Color: #44FF00"))
				ws.send(sendd("/color 44FF00"))

			if self.json_data["text"] in ["时间","time"]:
				a = time.strftime("Time %a %Y.%m.%d %H:%M:%S",time.localtime())
				ws.send(sendd(a))

			if self.json_data["nick"] in self.afk:
				if self.json_data["text"] not in ["挂机","afk","挂机列表","list"]:
					a = "welcome back {}".format(self.json_data["nick"])
					b = "{} is back".format(self.json_data["nick"])
					time.sleep(zz)
					ws.send(sendd(random.choice([a,b])))
					del self.afk[self.afk.index(self.json_data["nick"])]

				elif self.json_data["text"] in ["挂机","afk"]:
					time.sleep(zz)
					ws.send(sendd("{} is already in afk list".format(self.json_data["nick"])))
				
			if self.json_data["nick"] not in self.afk:
				if self.json_data["text"] in ["挂机","afk"]:
					time.sleep(zz)
					ws.send(sendd("{} is now afk".format(self.json_data["nick"])))
					self.afk.append(self.json_data["nick"])
					if self.json_data["nick"] in self.by:
						time.sleep(ee)
						ws.send(sendd("{}已离开{}游戏".format(self.json_data["nick"],self.game[0])))
				
			if self.json_data["text"] in ["挂机列表","list"]:
				if len(self.afk) == 0:
					time.sleep(zz)
					ws.send(sendd("目前无人挂机 列表为空"))

				else:
					time.sleep(zz)
					ws.send(sendd("·\nafk list:\n" + self.afk).replace('[\'','').replace('\']','').replace('\'',' '))
	
			for name in self.afk:
				if "{}".format(name) in self.json_data["text"]:
					time.sleep(zz)
					ws.send(sendd("{} is now afk".format(name)))

			if self.tran == True:
				if re.findall(r"·.+$",self.json_data["text"]) and "··" not in self.json_data["text"]:
					f = fanyi(re.findall(r"·(.+)$",self.json_data["text"])[0])
					time.sleep(zz)
					ws.send(sendd("{} said: ".format(self.json_data["nick"]) + f))

			if len(self.json_data["text"]) < 10:
				if "《" in self.json_data["text"] and "》" in self.json_data["text"]:
					time.sleep(zz)
					ws.send(sendd(self.json_data["text"]))

				if "！" * 1 in self.json_data["text"] or "？" * 1 in self.json_data["text"]:
					time.sleep(zz)
					ws.send(sendd(self.json_data["text"]))

				if "em" * 1 in self.json_data["text"] or "hm" * 1 in self.json_data["text"]:
					if "meme" not in self.json_data["text"]:
						time.sleep(zz)
						ws.send(sendd(random.choice([self.json_data["text"],"em","hm"])))

				if ":" * 1 in self.json_data["text"] or "：" * 1 in self.json_data["text"]:
					if self.json_data["text"] not in qq and self.json_data["text"] not in pp:
						time.sleep(zz)
						ws.send(sendd(self.json_data["text"]))

				if self.json_data["text"] in qq or self.json_data["text"] in pp:
					time.sleep(zz)
					ws.send(sendd(random.choice([self.json_data["text"],meme])))

			if self.json_data["text"] in ["真心话","飞花令","故事制造机"]:
				if len(self.game) != 0 and self.json_data["text"] not in self.game:
					a = "·\n来自eebot的温馨提示：\n已经在玩{}了 三心二意达咩\n".format(self.game[0])
					b = "·\n如何结束游戏？「结束游戏」"
					time.sleep(zz)
					ws.send(sendd(a + b))

			if self.json_data["text"] in self.game:
				time.sleep(zz)
				ws.send(sendd("{}已经开始了".format(self.game[0])))

			if len(self.game) != 0:
				if self.json_data["text"] in ["结束游戏"]:
					time.sleep(zz)
					ws.send(sendd("{}已结束".format(self.game[0])))
					self.by.clear()
					self.play.clear()
					self.game.clear()
					self.true = False
					self.story = False
					self.flower = False

				elif self.json_data["text"] in ["重置游戏"]:
					time.sleep(zz)
					ws.send(sendd("{}已重置".format(self.game[0])))
					self.by.clear()
					self.play.clear()
					if self.flower == True:
						time.sleep(ee)
						ws.send(sendd("下句的关键词在第1个字上"))
				
			if self.json_data["text"] in ["真心话"]:
				if self.true == False and len(self.game) == 0:
					a = "·\n使用方法：\n1.发送「r」或「随机」获取随机数\n2.用「结算」输出数字最大和最小的成员"
					b = "\n3.由数字最大的人向最小的提问\n4.结束时请输入「游戏结束」"
					self.game.append(self.json_data["text"])
					self.true = True
					time.sleep(zz)
					ws.send(sendd(a + b))
					time.sleep(ee)
					ws.send(sendd("真心话 游戏开始"))
				
			if self.json_data["text"] in ["飞花令"]:
				if self.flower == False and len(self.game) == 0:
					a = "花自飘零水自流\n落花时节又逢君\n春江花潮秋月夜\n人面桃花相映红\n不知近水花先发\n千树万树梨花开\n霜叶红于二月花\n"
					b = "·\n使用方法：\n1.··七言律诗（前面有两点\n2.每句的关键词有固定位置"
					c = "\n3.当句子为七句时会自动结束游戏\n4.可使用「结束游戏」提前结束"
					d = "·\n关键词：花\n·\n示例：\n"
					self.game.append(self.json_data["text"])
					self.flower = True
					time.sleep(zz)
					ws.send(sendd(d + a + b + c))
					time.sleep(ee)
					ws.send(sendd("游戏开始 下句的关键词在第1个字上"))
				
			if self.json_data["text"] in ["故事制造机"]:
				if self.story == False and len(self.game) == 0:
					a = "·\n使用方法：\n1.发送「r」或「随机」获取随机数\n2.用「结算」输出数字最大和最小的成员"
					b = "\n3.数字最大的人向最小的提问\n4.结束时请输入「游戏结束」"
					self.game.append(self.json_data["text"])
					self.true = True
					time.sleep(zz)
					ws.send(sendd(a + b))
					time.sleep(ee)
					ws.send(sendd("真心话 游戏开始"))

		if self.json_data["text"] in ["随机","r"]:
			r = random.randint(1,999)
			time.sleep(zz)
			if self.true == True:
				if self.json_data["nick"] in self.by:
					ws.send(sendd("{}已经r过了".format(self.json_data["nick"])))

				else:
					self.by.append(self.json_data["nick"])
					self.play.append(int(r))
					ws.send(sendd(r))

			else:
				ws.send(sendd(r))

		if self.true == True:
			if self.json_data["text"] in ["结算"]:
				if len(self.by) < 2:
					time.sleep(zz)
					ws.send(sendd("人数不足 至少要有2个人"))

				else:
					j = max(self.play)
					k = min(self.play)
					h = self.play.index(j)
					l = self.play.index(k)
					n = self.by[h]
					m = self.by[l]
					a = "最大：" + str(j) + "（" + n + "）"
					b = "最小：" + str(k) + "（" + m + "）"
					time.sleep(zz)
					ws.send(sendd("·\n本次参与人数：" + str(len(self.by)) + "\n·\n" + a + "\n" + b))
					time.sleep(ee)
					ws.send(sendd("请" + n + "向" + m + "提问 " + m + "回答"))
					self.by.clear()
					self.play.clear()
	
		if self.flower == True:
			u = self.play
			z = len(u) + 2
			if z == 9:
				a = "·\n飞花令 " + time.strftime("%H:%M:%S\n·\n",time.localtime())
				b = a + u[0] + "\n" + u[1] + "\n" + u[2] + "\n" + u[3] + "\n" + u[4] + "\n" + u[5] + "\n" + u[6]
				c = "\n·\nby." + str(self.by).replace('[\'','').replace('\']','').replace('\'',' ')
				time.sleep(ee)
				ws.send(sendd(b + c))
				time.sleep(ee)
				ws.send(sendd("游戏结束 完美撒花！"))
				self.by.clear()
				self.play.clear()
				self.game.clear()
				self.flower = False
	
			elif self.json_data["nick"] not in ["eebot","eeebot","eeeebot"]:
				if z != 9 and "··" in self.json_data["text"]:
					if len(self.json_data["text"]) == 9:
						if self.json_data["text"][z] == "花":
							a = random.choice(["Perfect！","Great！","Good！"])
							time.sleep(zz)
							self.play.append(self.json_data["text"][2:])
							if self.json_data["nick"] not in self.by:
								self.by.append(self.json_data["nick"])

							if z != 8:
								time.sleep(zz)
								ws.send(sendd(a + "下句的关键词在第" + str(z) + "个字上"))

							if z == 8:
								time.sleep(zz)
								ws.send(sendd(a + "七句诗成功输出"))
	
					elif self.json_data["text"][z] != "花":
						time.sleep(zz)
						ws.send(sendd("关键词没在固定位置上哦"))
	
				else:
					time.sleep(zz)
					ws.send(sendd("啊 请输入七言律诗"))

	def onlineadd(self):
		a = "hi {}".format(self.json_data["nick"])
		b = "hello {}".format(self.json_data["nick"])
		c = "hey {}".format(self.json_data["nick"])
		d = "welcome back {}".format(self.json_data["nick"])
		e = "{} is back".format(self.json_data["nick"])
		if self.json_data["nick"] in self.join:
			time.sleep(0.25)
			ws.send(sendd(random.choice([d,e])))

		else:
			time.sleep(0.25)
			ws.send(sendd(random.choice([a,b,c])))
			self.join.append(self.json_data["nick"])
		
	def onlineset(self):
		pass
			
class main:
	def __init__(self,room,name,pas):
		self.runbox = runbox(room,name,pas)
		self.room = self.runbox.room
		self.name = self.runbox.name
		self.pas = self.runbox.pas
		
	def on_message(self,ws,message):
		js_ms = json.loads(message)
		self.runbox.handle(js_ms)
		if js_ms["cmd"] == "onlineSet":
			onlineuser = "Onlineuser:"
			for e in js_ms["nicks"]:
				if e != js_ms["nicks"][-1]:
					onlineuser = onlineuser + e + ","
				else:
					onlineuser = onlineuser + e
		
	def on_error(self,ws,error):
		pass
		
	def on_close(self,ws):
		pass
		
	def on_open(self,ws):
		ws.send(json.dumps({"cmd":"join","channel":str(self.room),"nick":str(self.name),"pass":str(self.pas)}))
		ws.send(sendd("/color 44FF00"))
		time.sleep(0.25)
		ws.send(sendd("hi this is eebot (o°ω°o)"))
		time.sleep(0.5)
		ws.send(sendd("想了解更多玩法 请输入「功能」"))

if __name__ == "__main__":
	main = main(room="your-channell",name="eebot",pas="纸片君")
	websocket.enableTrace(True)
	ws = websocket.WebSocketApp("wss://hack.chat/chat-ws",on_message=main.on_message,on_error=main.on_error,on_close=main.on_close)
	ws.on_open = main.on_open 
	ws.run_forever()