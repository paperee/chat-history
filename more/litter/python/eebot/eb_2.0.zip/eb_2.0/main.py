import websocket,requests,json,time,random,sys,os,re,datetime
from langconv import *
from threading import Thread


# 常用聊天室ws地址
hc="wss://hack.chat/chat-ws"
cc="wss://ws.crosst.chat:35197"
xc="ws://xq.kzw.ink:6060"
xcc="wss://xq.kzw.ink/ws"


# 设置聊天室
chatroom=hc

# 设置频道
channel="lounge"

# 设置bot昵称
botname="Aleex"

# 设置bot密码
botpass="ee13"


# text: 发送的内容
def send(text):
	ws.send(json.dumps({'cmd':'chat','text':str(text)}))


# 连接聊天室
ws=websocket.WebSocket()
ws.connect(chatroom)
ws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botpass}))
ww=time.strftime("[Started] %Y.%m.%d %H:%M:%S",time.localtime())
print(ww)


# bot打招呼
send("/color 131313")


def run1():

	# 循环判定
	while True:

		# 保存文件的时间
		chat=time.strftime("%Y.%m.%d")
		write=open(f"chats/[{chat}] {channel}.txt","a+")

		# 随机等待时间
		zz=random.choice([0.1,0.15,0.2])
		ee=random.choice([0.3,0.35,0.4])

		# 接收到的json数据
		wss=json.loads(ws.recv())

		try:
			if "cmd" in wss:
				cmd=wss["cmd"]

				if cmd=="onlineSet":

					# 开始记录日志
					nicks=wss["nicks"]
					aa=str(nicks).replace("'","").replace("[","").replace("]","")
					bb=f"[Online] {aa}\n"
					cc="[Records]"
					print(bb)
					print(cc)

				elif cmd=="onlineAdd":
					nick=wss["nick"]
					emit=time.strftime("%H:%M:%S",time.localtime())

					if "trip" in wss:
						trip=wss["trip"]
						aa=f"[{emit}]\n[{trip}] {nick} joined"
						print(aa)

					else:
						aa=f"[{emit}]\n[None] {nick} joined"
						print(aa)

				elif cmd=="onlineRemove":
					nick=wss["nick"]
					aa=time.strftime(f"[%H:%M:%S]\n[None] {nick} left",time.localtime())
					print(aa)
					write.write(f"{aa}\n\n")

				elif cmd=="chat":
					text=wss["text"]
					nick=wss["nick"]
					leve=wss["level"]
					aa=time.strftime("[%H:%M:%S]\n",time.localtime())

					if "trip" in wss:
						trip=wss["trip"]
						bb=f"[{trip}] {nick}\n{text}"
						cc=f"{aa}{bb}"
						print(cc)
						write.write(f"{cc}\n\n")

					else:
						bb=f"[None] {nick}\n{text}"
						cc=f"{aa}{bb}"
						print(cc)
						if "\u28ff" not in text:
							write.write(f"{cc}\n\n")

		except:
			pass


threads = []

# 不需要手动让bot发送信息和时间线功能可以修改
for func in [run1]:
    threads.append(Thread(target=func))
    threads[-1].start()

for thread in threads:
    thread.join()
