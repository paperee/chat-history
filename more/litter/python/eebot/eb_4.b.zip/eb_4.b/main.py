# -*- coding: UTF-8 -*-

import websocket
import json
import time
import datetime
import random
import sys
import os
import re
import codecs
import threading


# 常用聊天室ws地址：hack.chat 十字街 XChat
ws_hc,ws_cc,ws_xc="wss://hack.chat/chat-ws","wss://ws.crosst.chat:35197","wss://xq.kzw.ink/ws"

# 常用聊天室ws地址：Tchat 冬日小屋 zzChat
ws_tc,ws_sc,ws_zc,ws_cbox="TC的机器人专用通道找麻鸡要","wss://sprchatport.run.goorm.io","wss://zzchat.cf/wss","wss://flr-la0.cbox.ws:4430/?pool=3-3521790-0"

# 常用聊天室名称
hc,cc,xc,tc,sc,zc="hack.chat","十字街","XChat","Tchat","冬日小屋","zzChat"

# 常用频道
ma,ts,xq,cn,pu,lo,yc,ycl,ccc,bot="main","test","xq102210","chinese","public","lounge","your-channel","your-channell","公共聊天室","bot"

# bot识别码
botrip="nmsl"

# 跨服消息列表
tsmit={}

# 挂机列表
afklist={}

# 屏蔽机器人
bots=codecs.open("bots.txt","r","UTF-8-sig").readlines()

# 猜猜这是什么（（
wwws='uwu'


# text: 信息
def send(text):
	return json.dumps({'cmd':'chat','text':str(text)})

def chatas(trip,nick,color,text):
	return json.dumps({"cmd":"chatas","trip":trip,"nick":nick,"color":color,"text":text})


# 表示开始
print("[Started] "+time.strftime("%Y.%m.%d %H:%M:%S",time.localtime()))


def replay(ws,channel,file,mod,v):
	global wwws

	# bot名字
	botname=str(random.randint(1,999))

	try:
		# 连接聊天室
		wwws=websocket.WebSocket()
		wwws.connect(ws_tc)
		ws.send(send(f"[自动回复]\n成功链接TC聊天室[?{channel}](https://chat.thz.cool/?{channel})频道"))
	
	except:
		ws.send(send(f"[自动回复]\n链接TC聊天室[?{channel}](https://chat.thz.cool/?{channel})频道失败"))
		sys.exit(0)

	# 加入聊天室
	wwws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botrip}))
	time.sleep(1)
	wwws.send(json.dumps({'cmd':'changecolor','color':'2D2D2D'}))
	print(f"[replay] {ws_tc}/{channel}")

	content_=[]

	if mod==1:
		try:
			content=codecs.open(f"[video]/{file}","r","UTF-8-sig").readlines()

			for word in content:
				content_.append(word.replace('[',"",1).replace(']'," ",1).strip("\n"))

		except:
			ws.send(send(f"[自动回复]\n找不到{file}"))

	elif mod==2:
		try:
			content=codecs.open(f"[video]/{file}","r","UTF-8-sig").read()
			re_=re.findall(r"\[(\d{2}:\d{2}:\d{2})\]",content)

		except:
			ws.send(send(f"[自动回复]\n找不到{file}"))

		for time_ in re_:
			try:
				split_=content.split(f"[{time_}]",1)
				notrip=split_[0].split("] ",1)[1].split("\n",1)
				content_.append(f"{time_} {notrip[0]} {notrip[1]}".strip("\n"))
				content=split_[1]

			except:
				pass

	wwws.send(chatas('','*','',f"开始{v}倍速播放 {file[:-4]}"))

	for uwu in content_:
		if True:
			msg=uwu.split(" ",mod)
			msg_=content_[content_.index(uwu)-1].split(" ",mod)
			mod_='%H:%M:%S'

			try:
				if uwu==content_[0]:
					time.sleep(1)

				else:
					if mod==1:
						mod_='%M:%S.%f'

					time_=datetime.datetime.strptime(msg[0],mod_)-datetime.datetime.strptime(msg_[0],mod_)
					time.sleep(int(time_.seconds)//v)

				if mod==1:
					wwws.send(chatas('','','',msg[1]))

				elif mod==2:
					wwws.send(chatas('replay',msg[1],'',msg[2]))

			except:
				pass

	try:
		wwws.send(chatas('','*','',f"【完】"))
		wwws.close()
		sys.exit(0)

	except:
		pass


def room1(socket,chatroom,channel):
	global wwws

	# bot名字
	botname=str(random.randint(1,999))

	try:
		# 连接聊天室
		ws=websocket.WebSocket()
		ws.connect(socket)
	
	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	# 加入聊天室
	ws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname,"password":botrip}))
	time.sleep(1)
	ws.send(json.dumps({'cmd':'changecolor','color':'44FF00'}))
	print(f"[Server1] {socket}/{channel}")
	
	def room1_1():

		# 自动叉叉
		uwu=True
		
		# 循环判定
		while True:
		
			# 保存文件的时间
			emit=time.strftime("%H:%M:%S",time.localtime())
			chat=time.strftime("%Y.%m.%d")
		
			try:
				# 接收到的json数据
				wss=json.loads(ws.recv())
		
			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)
		
			if "cmd" in wss:
				cmd=wss["cmd"]
		
				if cmd=="onlineAdd" and uwu==True:
					nick=wss["nick"]
					nick_=nick.lower()
					
					if "xc_" in nick_ or "qiu" in nick_ or "zhang" in nick_ or "blaze" in nick_ or "asdf" in nick_:
						ws.send(send(f"/w mbot kick {nick}"))
		
				elif cmd=="chat":
					nick=wss["nick"]
					text=wss["text"]
					bb=''
		
					if nick!=botname and nick+"\n" not in bots or nick==botname and text[0]=="|":
						if "trip" in wss and wss["trip"].strip()!='':
							trip=wss["trip"]
							bb=f"[{trip}] {nick}\n{text}"

							if text=="|help":
								ws.send(send(f"[自动回复]\n@{botname} <内容> => 留言\n|help => 帮助\n|afk <状态> => 挂机 *TanChat\n|all => 所有录像\n|play <频道> <文件> <模式> <速度> => 播放录像\n|unplay => 停止播放\n|note <日期> => 查看留言 *Mod\n|openxx => 叉叉 *Mod\n|closexx => 关闭叉叉 *Mod"))
			
							elif text=="|all":
								video=os.listdir("[video]")
								video_='\n'.join(video)
								video__=len(video)
								ws.send(send(f"/w {nick} >\n{video_}"))
								ws.send(send(f"[自动回复]\n共有{video__}个录像带"))

							elif "|play" in text[:5]:
								try:
									text_=text.lower().split(' ',4)
									threading.Thread(target=replay,args=(ws,text_[1],text_[2],int(text_[3]),int(text_[4]))).start()

								except:
									ws.send(send("[自动回复]\n录像带缺少参数，必须为：*replay 频道 文件 模式 速度"))
									
							elif text=="|unplay":
								try:
									ws.send(send("[自动回复]\n播放器终止了"))
									wwws.send(chatas('','*','','播放器终止了'))
									wwws.close()

								except:
									ws.send(send("[自动回复]\n没有正在播放的录像带"))

							elif trip in ["eYFDHl","love13","eeeEEm"]:
								if "|note" in text[:6]:
									text_=text[6:].strip()

									if text_=="":
										text_=chat

									try:
										note=codecs.open(f"[notes]/{text_}_notebook.txt","r","UTF-8-sig").read()
										note_=len(note.split(f'@ee'))
										ws.send(send(f"/w {nick} >\n{note}"))
										ws.send(send(f"[自动回复]\n共有{note_}条留言"))
											
									except:
										ws.send(send("[自动回复]\n笔记本是空的"))
										
								elif text=="|openxx":
									uwu=True
									ws.send(send("[自动回复]\n见到XC_开头的昵称就叉出去"))
									
								elif text=="|closexx":
									uwu=False
									ws.send(send("[自动回复]\n自动叉叉关闭了"))
			
						else:
							bb=f"[None] {nick}\n{text}"
			
						try:
							codecs.open(f"[chats]/[{chatroom}]/{chat}_{channel}.txt","a+","UTF-8-sig").write(f"[{emit}]\n{bb}\n\n")
							tsmit["1"]=bb
			
						except:
							pass
							
						if f"@{botname}" in text:
							if text.strip()==f"@{botname}":
								ws.send(send(f"[自动回复]\n如果我没及时回复就是在上学（周一到周五）\n所有@{botname} 或私聊的消息都会单独保存到笔记本\n有什么事就@{botname} 或私聊说吧 我周末会看的 uwu\n如果某天我掉线了 那就是服务器寄了"))
								
							else:
								ws.send(send(f"[自动回复]\n已经把留言塞到笔记本里了"))
								
							codecs.open(f"[notes]/{chat}_notebook.txt","a+","UTF-8-sig").write(f"[{emit}]\n{bb}\n\n")

						elif chatroom==tc:
							if nick in afklist:
								afk=afklist[nick]
								ws.send(chatas('','*','',f"{nick} 现在没在{afk}了"))
								del afklist[nick]

							elif text=="|afklist":
								if len(afklist)==0:
									ws.send(chatas('','*','',f"现在没有人在挂机"))

								else:
									list_=[]

									for nick in afklist:
										afk=afklist[nick]
										list_.append(f"{nick} 现在正在{afk}")

									join_='\n'.join(list_)
									len_=len(list_)
									ws.send(chatas('','*','',f"现在有{len_}人在挂机\n{join_}"))

							elif "|afk" in text[:4]:
								if text=="|afk":
									ws.send(chatas('','*','',f"{nick} 现在正在挂机"))
									afklist[nick]="挂机"

								elif text[4]==' ':
									text_=text[5:]
									ws.send(chatas('','*','',f"{nick} 现在正在{text_}"))
									afklist[nick]=text_

				elif cmd=="info" and wss.get("type")=="whisper":
					if "from" in wss:
						nick=str(wss["from"])
						text=wss["text"]
						text_=text[text.find("：")+1:]

						if nick!=botname and nick+"\n" not in bots:
							bb=f"[{nick}]\n{text_}"
							tsmit["1"]=bb

							if "whispered" not in text_:
								codecs.open(f"[notes]/{chat}_notebook.txt","a+","UTF-8-sig").write(f"[{emit}]\n{bb}\n\n")
	
			time.sleep(0.2)

	def room1_2():
		
		# 循环判定
		while True:
				
			if "2" in tsmit:
				try:
					ws.send(send(tsmit["2"]))
					del tsmit["2"]
					
				except:
					pass
	
			else:
				time.sleep(0.2)
			
	threading.Thread(target=room1_1).start()
	time.sleep(1)
	threading.Thread(target=room1_2).start()


def room2(socket,chatroom,channel):

	# bot名字
	botname=str(random.randint(1,999))

	try:
		# 连接聊天室
		wws=websocket.WebSocket()
		wws.connect(socket)
	
	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)

	# 加入聊天室
	wws.send(json.dumps({"cmd":"join","channel":channel,"nick":botname}))
	time.sleep(1)
	wws.send(json.dumps({'cmd':'changecolor','color':'44FF00'}))
	print(f"[Server2] {socket}/{channel}")
	
	def room2_1():
	
		# 循环判定
		while True:
			try:
				# 接收到的json数据
				wwss=json.loads(wws.recv())
		
			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)
		
			if "cmd" in wwss:
				cmd=wwss["cmd"]
		
				if cmd=="chat":
					nick=wwss["nick"]
					text=wwss["text"]
		
					if nick!=botname and "trip" in wwss and wwss["trip"]=="eYFDHl" and text[0]=="|":
						tsmit["2"]=text[1:]
		
			time.sleep(0.2)

	def room2_2():
		
		# 循环判定
		while True:
			
			if "1" in tsmit:
				try:
					wws.send(send(tsmit["1"]))
					del tsmit["1"]
					
				except:
					pass
				
			else:
				time.sleep(0.2)
			
	threading.Thread(target=room2_1).start()
	time.sleep(1)
	threading.Thread(target=room2_2).start()


# 同时启动两个聊天室
threading.Thread(target=room1,args=(ws_tc,tc,lo)).start()
time.sleep(3)
threading.Thread(target=room2,args=(ws_hc,hc,ycl)).start()
