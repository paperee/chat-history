﻿import websocket
import requests
import json
import time
import random
try:
	import thread
except:
	import _thread as thread

def sendd(text):
	return json.dumps({"cmd":"chat","text":str(text)})
	
class runbox:
	def __init__(self,room,name):
		self.room = room
		self.name = name
		self.online_users = []
	
	def handle(self,json_data):
		self.json_data = json_data
		if "cmd" in self.json_data:
			if self.json_data["cmd"] == "chat":
				self.chat()

			elif self.json_data["cmd"] == "onlineAdd":
				self.onlineadd()

			elif self.json_data["cmd"] == "onlineSet":
				self.onlineset()

			else:
				print("error")
	
	def chat(self):
		chat = time.strftime("%Y-%m-%d")
		room = self.room
		b = chat + " " + room + ".txt"
		with open(b,"a+") as fp:
			a = time.strftime("%H:%M:%S",time.localtime())
			ms = a + " " + self.json_data["nick"] + "\n" + self.json_data["text"] + "\n\n"
			fp.write(ms)

		if self.json_data["text"] in ["命令","order"]:
			time.sleep(0.5)
			ws.send(sendd("基本：帮助/help；农历/day；时间/time；挂机/afk；随机数/r"))
			time.sleep(0.5)
			ws.send(sendd("更多：一言；段子；古诗词；正能量；彩虹屁；毒鸡汤；舔狗日记；土味情话"))

		if self.json_data["text"] in ["帮助","help"]:
			time.sleep(0.5)
			ws.send(sendd("HC指令：https://tieba.baidu.com/p/6833224084"))
			time.sleep(0.5)
			ws.send(sendd("HC百科：https://chumo.sbsbsb.sbs/wiki/"))
			time.sleep(0.5)
			ws.send(sendd("个人主页：https://paperee.tk/"))

		if self.json_data["text"] in ["农历","day"]:
			api = "https://api.muxiaoguo.cn/api/yinlongli"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = a["lunar"] + " " + a["solarTerms"] + " " + a["yearZodiac"] + " " + a["lunarYearName"]
			time.sleep(0.5)
			ws.send(sendd(word))

		if self.json_data["text"] in ["一言","word"]:
			api = "https://v1.hitokoto.cn/"
			response = requests.get(api)
			res = response.json()
			word = "「" + res["hitokoto"] + "」" + "来自 " + res["from"] + " " + res["creator"]
			apii = "https://api.muxiaoguo.cn/api/yiyan"
			responsee = requests.get(apii)
			ress = responsee.json()
			a = ress["data"]
			wordd = "「" + a["constant"] + "」" + "来自 " + a["source"]
			time.sleep(0.5)
			ws.send(sendd(random.choice([word,wordd])))

		if self.json_data["text"] in ["段子","joke"]:
			api = "https://api.muxiaoguo.cn/api/xiaohua"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = "「" + a["content"] + "」" + "标题 " + a["title"]
			time.sleep(0.5)
			ws.send(sendd(word))

		if self.json_data["text"] in ["古诗词","poem"]:
			api = "https://api.muxiaoguo.cn/api/Gushici"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = "「" + a["min_content"] + "」" + "来自 " + a["title"]
			time.sleep(0.5)
			ws.send(sendd(word))

		if self.json_data["text"] in ["正能量"]:
			api = "https://hitokoto.open.beeapi.cn/random"
			response = requests.get(api)
			res = response.json()
			word = "「" + res["data"] + "」"
			apii = "https://api.ixiaowai.cn/api/ylapi.php"
			responsee = requests.get(apii)
			ress = "「" + responsee.text + "」"
			time.sleep(0.5)
			ws.send(sendd(random.choice([word,ress])))

		if self.json_data["text"] in ["彩虹屁"]:
			api = "https://api.muxiaoguo.cn/api/caihongpi"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = "「" + a["comment"] + "」"
			time.sleep(0.5)
			ws.send(sendd(word))

		if self.json_data["text"] in ["毒鸡汤"]:
			api = "https://api.muxiaoguo.cn/api/dujitang"
			response = requests.get(api)
			res = response.json()
			a = res["data"]
			word = "「" + a["comment"] + "」" + "来自 " + a["form"]
			time.sleep(0.5)
			ws.send(sendd(word))

		if self.json_data["text"] in ["舔狗日记"]:
			api = "https://api.ixiaowai.cn/tgrj/index.php"
			response = requests.get(api)
			res = "「" + response.text + "」"
			apii = "https://api.muxiaoguo.cn/api/tiangourj"
			responsee = requests.get(apii)
			ress = responsee.json()
			a = ress["data"]
			word = "「" + a["constant"] + "」"
			time.sleep(0.5)
			ws.send(sendd(random.choice([res,word])))

		if self.json_data["text"] in ["土味情话"]:
			api = "https://api.lovelive.tools/api/SweetNothings/count/Serialization/serializationType"
			response = requests.get(api)
			res = response.json()
			word = res["returnObj"]
			a = random.choice(word)
			b = "「" + a + "」"
			time.sleep(0.5)
			ws.send(sendd(b))

		if self.json_data["text"] in ["afk","挂机"]:
			time.sleep(0.75)
			ws.send(sendd("{} is now afk".format(self.json_data["nick"])))

		if self.json_data["text"] in ["r","随机数"]:
			time.sleep(0.5)
			ws.send(sendd(random.randint(1,6)))

		if self.json_data["text"] in ["time","时间"]:
			time.sleep(0.5)
			ws.send(sendd(time.strftime("%Y-%m-%d %H:%M:%S %A",time.localtime())))
	
	def onlineadd(self):
			time.sleep(0.5)
			ws.send(sendd("hi {}".format(self.json_data["nick"])))
		
	def onlineset(self):
		pass
			
class main:
	def __init__(self,room,name):
		self.runbox = runbox(room,name)
		self.room = self.runbox.room
		self.name = self.runbox.name
		
	def on_message(self,ws,message):
		js_ms = json.loads(message)
		self.runbox.handle(js_ms)
		if js_ms["cmd"] == "onlineSet":
			onlineuser = "Onlineuser:"
			for e in js_ms["nicks"]:
				if e != js_ms["nicks"][-1]:
					onlineuser = onlineuser + e + ","
				else:
					onlineuser = onlineuser + e
		
	def on_error(self,ws,error):
		pass
		
	def on_close(self,ws):
		pass
		
	def on_open(self,ws):
		ws.send(json.dumps({"cmd": "join", "channel": str(self.room), "nick": str(self.name)}))
		ws.send(sendd("/color 44FF00"))
		time.sleep(0.5)
		ws.send(sendd("hi (o°ω°o)"))

if __name__ == "__main__":
	main = main(room="your-channel",name="eebot_2x#纸片君")
	websocket.enableTrace(True)
	ws = websocket.WebSocketApp("wss://hack.chat/chat-ws",on_message=main.on_message,on_error=main.on_error,on_close=main.on_close)
	ws.on_open=main.on_open 
	ws.run_forever()