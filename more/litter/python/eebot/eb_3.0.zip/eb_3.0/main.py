import websocket,requests,urllib.request,json,time,datetime,random,sys,os,re,sb,morse_code
from langconv import *
from threading import Thread


def online_code(text,nick,trip):
	fp=open("[record]\\[online]\\var.txt","r+")
	pf=fp.read()
	dk=os.listdir("[record]\\[online]\\[code]")
	code=text.replace("print","send").replace("    ","	").replace('“','"').replace('”','"').replace('‘',"'").replace('’',"'")

	per=f"/w {nick} "

	if code=="cll":
		fp.truncate(0)
		fp.close()
		send(per+"已清空所有变量")

	elif code=="all":
		if pf=='':
			send(per+"目前还没有全局变量")

		else:
			send(per+f"所有全局变量如下：\n{pf}")

	elif code=='clean':
		if trip==None:
			send(per+'请带上识别码后再查找存档-')

		elif f"{trip}.txt" in dk:
			os.remove(f"[record]\\[online]\\[code]\\{trip}.txt")
			send(per+f"已清空{nick}的个人存档")

		else:
			send(per+f"{nick}还没有存过档哦")

	elif code=='mine':
		if trip==None:
			send(per+'请带上识别码后再查找存档-')

		elif f"{trip}.txt" in dk:
			a=open(f"[record]\\[online]\\[code]\\{trip}.txt","r").read()
			send(f"/w {nick} .\n{a}")

		else:
			send(per+f"{nick}还没有存过档哦")

	elif "\n" in code:
		xx=code.split("\n",1)
		x1=xx[1]

		if xx[0]=='save':
			if trip==None:
				send(per+'请带上识别码后再存档-')

			else:
				try:
					exec(pf+x1)
					time.sleep(0.2)
					send(per+"代码运行成功")

					try:
						a=open(f"[record]\\[online]\\[code]\\{trip}.txt","a+")
						a.write(f"{x1}\n")
						a.close()
						send(per+"存档成功")

					except:
						send(per+"含有无法识别的字符 存档失败")

				except Exception as eee:
					send(eee)
					time.sleep(0.2)
					send(per+"代码运行失败 存档失败")

		elif xx[0]=='load':
			if trip==None:
				send(per+'请带上识别码后再读档-')

			elif f"{trip}.txt" in dk:
				try:
					a=open(f"[record]\\[online]\\[code]\\{trip}.txt","r").read()
					exec(pf+a+x1)
					time.sleep(0.2)
					send(per+"代码运行成功")

				except Exception as eee:
					send(eee)
					time.sleep(0.2)
					send(per+"代码运行失败")

			else:
				try:
					exec(pf+x1)
					time.sleep(0.2)
					send(per+"代码运行成功")

				except Exception as eee:
					send(eee)
					time.sleep(0.2)
					send(per+"代码运行失败")

		else:
			try:
				exec(pf+code)
				time.sleep(0.2)
				send(per+"代码运行成功")

			except Exception as eee:
				send(eee)
				time.sleep(0.2)
				send(per+"代码运行失败")

	else:
		try:
			exec(pf+code)
			time.sleep(0.2)
			send(per+"代码运行成功")

			if "send" not in code and ";" not in code and "=" in code:
				try:
					fp.write(f"{code}\n")
					fp.close()
					send(per+"变量已成功保存")

				except:
					send(per+"无法写入 含有无法识别的字符")

		except Exception as eee:
			send(eee)
			time.sleep(0.2)
			send(per+"代码运行失败")

	# 结束进程
	sys.exit(0)


if True:

	# 常用聊天室ws地址：hack.chat 十字街 XChat
	ws_hc,ws_cc,ws_xc,ws_xcc="wss://hack.chat/chat-ws","wss://ws.crosst.chat:35197","ws://xq.kzw.ink:6060","wss://xq.kzw.ink/ws"

	# 常用聊天室ws地址：Tchat 冬日小屋 zzChat
	ws_tc,ws_tcc,ws_sc,ws_zc="ws://chat.thz.cool:6060","wss://chat.thz.cool/chat-ws","wss://sprchatport.run.goorm.io","wss://zzchat.cf/wss"

	# 常用聊天室名称
	hc,cc,xc,tc,sc,zc="hack.chat","十字街","XChat","Tchat","冬日小屋","zzChat"

	# 常用频道
	ma,ts,xq,cn,pu,lo,yc,ycl,ccc,bot="main","test","xq102210","chinese","public","lounge","your-channel","your-channell","公共聊天室","bot"


	# 设置聊天室ws地址
	socket1,socket2=ws_xc,ws_hc

	# 设置聊天室名称
	chatroom1,chatroom2=xc,hc

	# 设置频道名称
	channel1,channel2=xq,yc


	# 设置xc头像 bot颜色 bot名字 bot昵称 使用者昵称
	head,color,botname,botnick,username="https://s1.ax1x.com/2022/04/30/Oppn5n.png","#44FF00","eebot","eb","ee"

	# 昵称备用（勿改）
	rese=botname

	# 发送消息备用（勿改）
	text_rese=''


	# （无法内部设置）手动发消息开关 时间线开关 在线窥屏开关 屏蔽自身消息
	sendms,timeline,peep,block_bot=True,True,False,True

	# （可内部设置）参与游戏开关 打招呼开关 广告开关 消息传递 精简模式 彩虹开关
	botto,hiyo,ad,transmit,simplify,rainbow=False,True,True,True,False,True

	# （勿改）使用者发送消息 防踢判断 踢人判断 判断bot是否在聊天
	using,invite,kicck,bot_chat=False,False,False,False

	# 是否启用生草机 真心话 飞花令 词语接龙
	greengl,trueword,flower,idioms=True,True,True,True


	# 在线和跨服消息记录
	online,tsmit={"1":{},"2":{}},{"1":'',"2":''}

	# 保存聊天记录
	chatlist,textlist=[],[]

	# afk成员
	afklist={}

	# 计时器列表
	reckon=[]

	# 游戏数据及游戏成员
	gamename,gamedate,gameby=[],[],[]

	# 生草机和飞花令数据
	greenda,flowerd=[],[]


	# 接收到的聊天条数
	chat_date=0


	try:
		# 连接聊天室
		ws=websocket.WebSocket()
		ws.connect(socket1)
		wss,wws,wsss='','',''

	except:
		# 自动重启
		time.sleep(30)
		py=sys.executable
		os.execl(py,py,*sys.argv)


	def send(text):

		# 引用函数外变量
		global chatroom1,text_rese,rainbow,bot_chat

		try:
			t=text_rese=str(text)

			if chatroom1==hc and rainbow==True:
				if "mark" in online["1"]:
					ws.send(json.dumps({'cmd':'changecolor','color':random.choice(["#44FF00","#FFFF34"])}))

				else:
					a=random.choice(['A','B','C','D','E','F','0','1','2','3','4','5''6','7','8','9'])
					b=random.choice(['0','1','2','3','4','5','6','7','8','9'])
					ws.send(json.dumps({'cmd':'changecolor','color':f'{a}F{b}'}))

			if '/w' in t[:2] or '/me' in t[:3] or t[0] in ["@","r"] or "afk" in t[:3] or kicck==True or using==True:
				ws.send(json.dumps({'cmd':'chat','text':t,"head":head}))

			else:
				ws.send(json.dumps({'cmd':'chat','text':f' {t}',"head":head}))

		except:
			pass

		if bot_chat==True:
			fp=open("[record]\\[chat]\\chat.txt","a+")
			fp.write(f"{rese}：{t}\n\n")
			fp.close()
			bot_chat=False


	# 匿名函数 chat备用
	send_rese=lambda text:json.dumps({'cmd':'chat','text':str(text),"head":head})

	# 匿名函数 join
	join=lambda chan,name:json.dumps({"cmd":"join","channel":chan,"nick":name,"password":"","token":"","client_key":""})

	# 匿名函数 join备用
	join_rese=lambda chan,name:json.dumps({"cmd":"join","channel":chan,"nick":name})


	try:
		# 获取每日信息
		api="https://api.iyk0.com/jr/"
		se=requests.get(api).json()
		res=se["today"].replace('，',' ')

	except:
		res="好好学习 天天向上"


	# 表示开始
	ww=time.strftime("%Y.%m.%d %H:%M:%S",time.localtime())
	yy=time.time()
	print(f"[Started] {ww}")

	# bot问候
	ws.send(join(channel1,botname))
	ws.send(json.dumps({'cmd':'changecolor','color':color}))
	time.sleep(0.2)
	send(f"[{ww}]")
	time.sleep(0.4)
	send(f"·\n{res}\n更多玩法请输入：功能")

	# 用于排除聊天屏蔽词
	fp=open("[record]\\[chat]\\block_word.txt","r")
	ai=fp.readlines()
	fp.close()

	# 用于排除bot昵称
	fp=open("[record]\\[chat]\\block_name.txt","r")
	bot=fp.readlines()
	fp.close()

	# 随机表情
	fp=open("[record]\\[random]\\meme.txt","r")
	me=fp.readlines()
	fp.close()

	# 屏蔽词库
	fp=open("[record]\\[chat]\\block_fuck.txt","r")
	fuck=fp.readlines()
	fp.close()

	# 检查是否被kick
	fp=open("[record]\\[main]\\kick.txt","r+")
	ki=fp.read()

	if ki!='':
		kicck=True
		time.sleep(1)
		send(f"@{ki} aaa 为什么要踢{botnick}")
		send(f"~kick {ki}")
		fp.truncate(0)
		fp.close()
		kicck=False


	def main_1():

		'''
			优先级：simplify（模式）>gamename（游戏）>while（睡眠）>hiyo（打招呼）>peep（窥屏）
		'''

		# 引用函数外变量
		global wss,socket1,chatroom1,channel1,botname,botnick
		global peep,block_bot,using,botto,hiyo,transmit,simplify,rainbow,invite,kicck,bot_chat
		global greengl,trueword,flower,idioms,gamename,gamedate,gameby,greenda,flowerd,chat_date

		# 随机等待时间
		zz,ee=random.choice([0.1,0.15,0.2]),random.choice([0.3,0.35,0.4])

		def test_timer(t_time,nick,text):
			time.sleep(t_time)

			if text==None and greengl==False and len(greenda)!=0 and nick==greenda[-1]:
				send(f"/w {nick} {nick}的输入时间超时 {rese}来代写了")
				del greenda[-1]
				greenda.append(f"替{nick}写的{rese}")
				g1=greenda[-1]
				ta=len(gamedate)

				if ta==0:
					ff=list(online["1"].keys())[0]
					dd=random.choice(ff)
					bb=random.choice(bot).strip("\n")
					aa=random.choice([nick,botnick,rese,username])

					if random.randint(1,3)==1:
						send(f"/w {botname} "+random.choice([f"{aa}和{bb}",f"{aa}和{dd}",f"{bb}和{dd}"]))

					else:
						send(f"/w {botname} {aa}")

				elif ta==1:
					send(f"/w {botname} "+sb.sbs())

				elif ta==2:
					send(f"/w {botname} "+sb.sbsb())

				else:
					fp=open("[record]\\[random]\\text.txt","r").readlines()
					hh=random.choice(fp).strip("\n").replace('我们',f"{nick}和{botnick}").replace('你们',nick).replace('我',botnick).replace('你',nick)
					send(f"/w {botname} {hh}")

			elif nick in reckon:
				y,d=divmod(t_time,60),divmod(y[0],60)
				s,i,m=d[0],d[1],y[1]

				if text=='' and nick in online["1"]:
					send(f"@{nick} {s}h {i}m {m}s倒计时已结束了")

				elif text!=None and nick in online["1"]:
					send(f"@{nick} 已经过去{s}h {i}m {m}s了 快去{text}")

					if nick not in afklist:
						time.sleep(1)
						send(f"@{nick} 已被{botnick}标记为{text}状态")
						afklist[nick]=text

				else:
					send(f"诶{nick}人呢 已经去{text}了吧")

				del reckon[reckon.index(nick)]

			# 结束进程
			sys.exit(0)

		# 循环判定
		while True:

			# 保存文件的时间
			emit=time.strftime("%H:%M:%S",time.localtime())
			chat=time.strftime("%Y.%m.%d")
			write=open(f"[chats]\\[{chatroom1}]\\{chat}_{channel1}.txt","a+")

			try:
				# 接收到的json数据
				wss=json.loads(ws.recv())

			except:
				# 自动重启
				time.sleep(30)
				py=sys.executable
				os.execl(py,py,*sys.argv)

			if f"{botname}\n" not in bot:
				bot.append(f"{botname}\n")

			if "cmd" in wss:
				cmd=wss["cmd"]

				if cmd=="warn":
					text=wss["text"]

					if "too much text" in text or "rate-limited" in text:
						time.sleep(10)
						send(text_rese)

					if "name" in text or "昵称重复" in text or "已经有人" in text:
						try:
							taken=str(random.randint(1,999))
							botname_taken=f"{botname}_{taken}"
							ws.close()
							ws.connect(socket1)
							ws.send(join(channel1,botname_taken))
							botname=botname_taken
							ws.send(json.dumps({'cmd':'changecolor','color':color}))
							time.sleep(zz)
							send(f"QuQ {botnick}的昵称卡在里面了")

						except:
							# 自动重启
							time.sleep(30)
							py=sys.executable
							os.execl(py,py,*sys.argv)

						if chatroom1==xc:
							time.sleep(1)
							ws.send(json.dumps({"cmd":"kickzom","nick":rese}))

					elif chatroom1==hc and invite==True and "not find user" in text:

						# 自动重启
						time.sleep(10)
						py=sys.executable
						os.execl(py,py,*sys.argv)

					elif len(gamename)==0:
						if "too fast" in text:

							# 自动重启
							time.sleep(60)
							py=sys.executable
							os.execl(py,py,*sys.argv)

				if cmd=="onlineSet":
					if "users" in wss:
						for nick in wss["users"]:
							n=nick["nick"]

							if "｜" not in n:
								online["1"][n]={}
								online["1"][n]["join"]="-"

								if "trip" in nick and nick["trip"]!=None and nick["trip"].strip()!='':
									online["1"][n]["trip"]=nick["trip"]

						aa=", ".join(online["1"].keys())
						print(f"[Online] {aa}\n")
						print("[Records]")

						if chatroom1==hc and botname!=rese and 'ModBot' in online["1"]:
							kicck=True
							send(f'~kick {rese}')
							kicck=False

				elif cmd=="onlineAdd":
					nick=wss["nick"]
					print(f"[{emit}]\n{nick} joined\n")

					nj,jn,pp=os.listdir("[record]\\[come]\\[trip]"),os.listdir("[record]\\[come]\\[nick]"),os.listdir("[record]\\[come]\\[code]")

					tiee=time.time()
					online["1"][nick]={}
					online["1"][nick]["join"]=tiee

					if "trip" in wss and wss["trip"].strip()!='':
						online["1"][nick]["trip"]=wss["trip"]

					# bot私聊用
					per=f"/w {nick} .\n·\n"

					time.sleep(ee+zz)

					# 为防止刷屏而屏蔽bot昵称
					if f"{nick}\n" not in bot and nick in online["1"]:
						fp=''

						if "trip" in wss and wss["trip"].strip()!="" and wss["trip"]+".txt" in nj:
							trip=wss["trip"]
							fp=open(f"[record]\\[come]\\[trip]\\{trip}.txt","r")

						elif f"{nick}.txt" in jn:
							fp=open(f"[record]\\[come]\\[nick]\\{nick}.txt","r")

						try:
							send(fp.read())
							fp.close()

						except:
							if hiyo==True:

								# bot打招呼
								send(random.choice(["hi","hey","hello"])+f" yo {nick}")

						if "trip" in wss and wss["trip"].strip()!="" and wss["trip"]+".txt" in pp:
							try:
								jj=open(f"[record]\\[come]\\[code]\\{trip}.txt","r").read()
								Thread(target=online_code,args=(jj,nick,trip,)).start()

							except:
								pass

				elif cmd=="onlineRemove":
					nick=wss["nick"]
					print(f"[{emit}]\n{nick} left\n")

					if "*" not in nick:
						ffp=open(f"[record]\\[come]\\[data]\\{nick}.txt","w")
						ffp.write(f"{chat} {emit}\n")
						ffp.close()

					if nick in online["1"]:
						del online["1"][nick]

					if rese!=botname and len(gamename)==0:
						time.sleep(zz)

						if nick==rese:
							send(f"被卡掉的昵称走了 {botnick}马上回来")

							# 自动重启
							py=sys.executable
							os.execl(py,py,*sys.argv)

						elif rese not in online["1"]:
							send(f"看到有人离开了 {botnick}才想起重启")

							# 自动重启
							py=sys.executable
							os.execl(py,py,*sys.argv)

				elif cmd=="chat":
					nick,text,leve=wss["nick"],wss["text"],wss["level"]
					bb=''

					# 增加一条聊天条数
					chat_date+=1

					# bot私聊用
					per=f"/w {nick} .\n·\n"

					if "trip" in wss and wss["trip"].strip()!='':
						trip=wss["trip"]
						bb=f"[{trip}] {nick}\n{text}"

					else:
						bb=f"[None] {nick}\n{text}"

					dd=f"[{emit}]\n{bb}\n"
					print(dd)

					try:
						write.write(f"{dd}\n")

					except:
						pass

					if transmit==True and nick!=botname and f"{nick}\n" not in bot:
						if "trip" in wss and wss["trip"].strip()!='':
							trip=wss["trip"]
							ff=f"[{trip}] {nick}\n{text}"
							tsmit['1']=ff

						else:
							ff=f"[None] {nick}\n{text}"
							tsmit['1']=ff

					# 如果是正常模式
					if simplify==False:

						if f"{nick}\n" in bot and f"@{botname}" in text[:len(botname)+1]:
							if ("别" in text or "不要" in text) and "屏蔽" in text or "理我" in text:
								del bot[bot.index(f"{nick}\n")]
								send(random.choice([f"诶 真拿{nick}没办法-","已解除~没问题了"]))

						if chatroom1==hc and text.replace('@','').replace(' ','')==f"~kick{botname}":
							invite=True
							nic=list(online["1"].keys())
							nic.remove(botname)
								
							fp=open("[record]\\[main]\\kick.txt","w")
							fp.write(nick)
							fp.close()

							ws.send(json.dumps({'cmd':'invite','nick':nic[0]}))

						# 为防止刷屏而屏蔽bot昵称
						if f"{nick}\n" not in bot and "eebot" not in nick:
							block_bot=True

						else:
							block_bot=False

						if using==True:
							if f"[{username}]" in text[:len(username)+3]:
								text=text[len(username)+3:]
								nick=username

						if block_bot==True or using==True:

							# 聊天记录统计用
							if "*" not in nick:
								fp=open(f"[chats]\\[{chatroom1}]\\[stat]\\{nick}.txt","a+")

								try:
									fp.write(text.replace('\n','\\n')+"\n")

								except:
									fp.write("1\n")

							tx_now=text.replace("```","").replace("~~~>","")

							# 暂时保存聊天记录
							chatlist.append(f"·\n[{chat}] [{nick}]\n{tx_now}\n\n")

							# 如果频道是hc
							if chatroom1==hc and text=="hc":
								fp=open("[record]\\[room]\\hc.txt","r")
								ch=fp.read()
								send(per+ch)

							# 如果频道是cc或xc
							if chatroom1 in [cc,xc] and text=="2room":
								fp=open("[record]\\[room]\\2room.txt","r")
								rm=fp.read()
								send(per+rm)

							# 如果频道是cc
							if chatroom1==cc and text=="cc":
								fp=open("[record]\\[room]\\cc.txt","r")
								cd=fp.read()
								send(per+cd)

							# 如果频道是xc
							if chatroom1==xc:
								if text=="xc":
									fp=open("[record]\\[room]\\xc.txt","r")
									a=['z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','i','h','g','f','e','d','c','b','a']
									b=['0','1','2','3','4','5','6','7','8','9']
									c=random.sample(a+b,8)
									d="".join(c)
									cx=fp.read().replace('——',d)
									send(per+cx)

								if "USERSENDVOICE_static" in text:
									te=text.replace("USERSENDVOICE_static","https://xq.kzw.ink/oss")
									send(f"@{nick} 在{chatroom1}发了语音\n{te}")

							# 如果频道是tc
							if chatroom1==tc:
								if text=="tc":
									fp=open("[record]\\[room]\\tc.txt","r")
									ct=fp.read()
									send(per+ct)

								if text=="mod":
									fp=open("[record]\\[room]\\tc_mod.txt","r")
									mo=fp.read()
									send(per+mo)

							# 如果频道是sc
							if chatroom1==sc and text=="sc":
								fp=open("[record]\\[room]\\sc.txt","r")
								cs=fp.read()
								send(per+cs)

							# 如果频道是zc
							if chatroom1==zc and text=="zc":
								fp=open("[record]\\[room]\\zc.txt","r")
								cz=fp.read()
								send(per+cz)

							if text in ["功能","order"]:
								fp=open("[record]\\[main]\\order_normal.txt","r")
								er=fp.read().replace('——',botname)
								er=er.replace('t—',str(trueword)).replace('f—',str(flower)).replace('i—',str(idioms)).replace('g—',str(greengl))

								if "ZhangHelper" in online["1"] or "ZhangHelperS" in online["1"]:
									er=er.replace('u—','漂流瓶｜drift：让bot随机扔漂流瓶')

								else:
									er=er.replace('u—','')

								if peep==True:
									er=er.replace('e—',f'@{botname} 跨服聊天开｜关：是否接通隔壁聊天室')

								else:
									er=er.replace('e—','')

								if chatroom1==hc:
									er=er.replace('ch—',f'@{botname} （不）变成彩虹：是否让bot有多种颜色')

								elif chatroom2==hc:
									er=er.replace('ch—',f'@{botname} （不）变成彩虹：是否让bot有多种颜色（备用频道')

								else:
									er=er.replace('ch—','')

								if chatroom1==hc:
									send(f"{per}{er}\n·\n如果想了解hack.chat：hc")

								elif chatroom1==cc:
									send(f"{per}{er}\n·\n如果想了解十字街：cc\ncc与xc的虚构和约：2room")

								elif chatroom1==xc:
									send(f"{per}{er}\n·\n如果想了解XChat：xc\nxc与cc的虚构和约：2room")

								elif chatroom1==tc:
									send(f"{per}{er}\n·\n如果想了解Tchat：tc")

								elif chatroom1==sc:
									send(f"{per}{er}\n·\n如果想了解SprinkleChat：sc")

								elif chatroom1==zc:
									send(f"{per}{er}\n·\n如果想了解zzChat：zc")

							if text in ["自定义","re"]:
								fp=os.listdir("[record]\\[custom]\\[chat]")
								ve='\n'.join(fp).replace('.txt','')
								send(f"{per}可@{botname} 的问题：\n{ve}")

							if text in ["揭示板","board"]:
								da=os.listdir("[record]\\[board]")
								date=', '.join(da).replace('.txt','')

								if date=="":
									send("None")

								else:
									send(f"{per}可查询的日期：\n{date}")

							if text in ["留言板","ees"]:
								es=open("[record]\\[main]\\ees.txt","r")
								se=es.read()
								ss=se.split("\n·\n")
								sa='\n·\n'.join(ss[-50:])
								send(f'{per}来这边给ee留言：\nhttps://note.ms/ee\n{sa}')

							if text in ["小故事","lit"]:
								it=open("[record]\\[main]\\green.txt","r")
								li=it.read().split('\n·\n')
								il='\n·\n'.join(li[-20:])
								send(per+il)

							if text in ["机器聊","chat"]:
								ca=open("[record]\\[chat]\\chat.txt","r")
								at=ca.read().split('\n·\n')
								ta='\n·\n'.join(at[-40:])
								send(per+ta)

							if text[:3]=="CA-":

								# 判断字数是否小于3
								if len(text[3:].strip())<3:
									send("内容至少3个字 请不要氵哦")

								elif "$" in text:
									send("不让使用LaTeX（")

								else:
									# 把留言写入揭示板中
									fp=open(f"[record]\\[board]\\{chat}.txt","a+")
									ch=time.strftime("%H:%M:%S",time.localtime())
									t3=text[3:]
									an=f"·\n[From.{chatroom1}｜{channel1}]\n[{ch}] {nick}\n{t3}\n\n".replace("```","").replace("~~~>","")

									try:
										send(f"已成功把{nick}的话写入公开揭示板")
										fp.write(an)
										fp.close()

									except:
										send("无法写入 含有无法识别的字符")

							if text[:2]=="B-":

								# 把日期字符串化
								da=os.listdir("[record]\\[board]")
								date=', '.join(da)
								t2=text[2:]

								# 留空则查询今日的揭示板
								if t2.strip()=="":
									if f"{chat}.txt" in da:
										fp=open(f"[record]\\[board]\\{chat}.txt","r").read()
										send(f"{per}今日的揭示板\n（管理员 {username}）\n{fp}")

									else:
										send("今天的板空空如也")

								elif f"{t2}.txt" in da:
									fp=open(f"[record]\\[board]\\{t2}.txt","r").read()
									send(f"{per}{t2}揭示板\n（管理员 {username}）\n{fp}")

								else:
									send("请检查日期是否正确")

							if text[:2] == "Z-":
								tex2=text[2:]

								# 设置为空时无效
								if tex2.strip()=="":
									send("请勿留空哦")

								elif str(text).count("\n")>=1:
									hd=os.listdir("[record]\\[custom]\\[chat]")
									dh=tex2.split('\n',1)
									a=dh[0].strip().lower()
									b=dh[1].replace('，',' ')

									# 设置为空时无效
									if "" in [a,b]:
										send("请勿留空哦")

									elif "$" in text:
										send("不让使用LaTeX（")

									else:
										try:
											aa=a.strip('\n')
											fpp=open(f"[record]\\[custom]\\[chat]\\{aa}.txt","w")
											fpp.write(f"{b}\n")
											fpp.close()

											if f"{aa}.txt" in hd:
												send("已重新设置这个问题的回答")

											else:
												# 如果是第一次设置这个问题
												send(f"{botnick}记住要这么回答了")

										except:
											send("无法写入 含有无法识别的字符")

								else:
									send("第一行是问题 从第二行开始是回答")

							if text[:2]=="E-":
								t2=text[2:]
								dd=f"{t2}\n"
								aa,fp='',''

								if "$" in text:
									send("不让使用LaTeX（")

								else:
									try:
										# 如果用户有识别码
										trip=wss["trip"]
										aa=f"[record]\\[come]\\[trip]\\{trip}.txt"
										fp=open(aa,"w")

									except:
										aa=f"[record]\\[come]\\[nick]\\{nick}.txt"
										fp=open(aa,"w")

									# 设置为空时重置
									if t2.strip()=="":
										fp.close()
										os.remove(aa)

										try:
											os.remove(f"[record]\\[come]\\[code]\\{trip}.txt")

										except:
											pass

										send(f"已清空对{nick}的欢迎语")

									else:
										try:
											# 把欢迎语写入
											fp.write(dd.replace("，"," "))
											fp.close()
											send("设置成功 将在下次进入聊天室时生效")

										except:
											send("无法写入 含有无法识别的字符")

							if text[:2]=="R-":
								d='[AD] [paperee]\nhttps://paperee.tk/\n'

								if text[2:].strip()=="":
									a=''.join(chatlist[-100:])
									send(per+d+a)

								elif text[2:].isnumeric()==True:
									a=int(text[2:])
									b=len(chatlist)

									if a>b:
										send(f"目前仅有{b}条聊天记录")

									elif a>100:
										send("最大只能查询100条聊天记录")

									elif a<1:
										send("那不就是没记录了嘛")

									elif b<1:
										send("当前没有记录")

									else:
										send(per+d+''.join(chatlist[-a:]))

								else:
									send("无效的条数")

							if text[:2] == "G-":
								tex2=text[2:]

								# 设置为空时无效
								if tex2.strip()=="":
									send("请勿留空哦")

								else:
									t2=tex2.split("\n")
									jz=[]

									if len(t2)!=3:
										send("应该这样写：\nG-{某人} {某人} ……\n{某地} {某地} ……\n{某事} {某事} ……")

									else:
										a,b,c=t2[0].split(" "),t2[1].split(" "),t2[2].split(" ")
										ra,rb,rc=random.choice(a),random.choice(b),random.choice(c)
										send(f"{ra}在{rb}{rc}")

										for aa in a:
											for bb in b:
												for dd in c:
													jz.append(f"{aa}在{bb}{dd}")

										jj=len(jz)
										time.sleep(zz)

										if jj>20:
											zj='\n'.join(jz[:20])
											send(f"{per}共有{jj}种结果 此处为前20~\n{zj}")

										else:
											zj='\n'.join(jz)
											send(f"{per}共有{jj}种结果~\n{zj}")

							if text[:3]=="SM-":
								url='https://sm.ms/api/v2/upload'
								header={"User-Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0"}
								headers={'Authorization':'HzqjuaAtIquTnejszBzLn14trGpzicj8'}
								files=''

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									if "http" in text:
										try:
											cl=text[3:].split("/")[-1]
											ll=urllib.request.Request(text[3:],headers=header)
											a=urllib.request.urlopen(ll).read()
											b=f"[temp]\\{cl}"
											c=open(b,"wb")
											c.write(a);c.close()
											files={'smfile':open(b,'rb')}

										except:
											send("失败 网站可能设置了反爬虫")

									else:
										try:
											files={'smfile':open(text[3:],'rb')}

										except:
											send("失败 找不到图片")

									try:
										rs=requests.post(url,files=files,headers=headers)
										res=rs.json()

										if res["success"]==True:
											ul=res["data"]["url"]
											send(f"![]({ul})")

										else:
											send("失败 无效的图片路径")

									except:
										pass

							if text[:2]=="Q-":
								aa,bb=[],[]

								# 判断词后是否留空
								if text[2:].strip()=="":
									send("请勿留空哦")

								elif ".mp" in text:
									send("不行 这很坑诶")

								else:
									try:
										header={"User-Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0"}
										ll=urllib.request.Request(text[2:],headers=header)
										a=urllib.request.urlopen(ll).readlines()

										for i in a:
											i=str(i)

											if "<img" in i:
												a1,a2=re.findall(r"src='(.*?)'",i),re.findall(r'src="(.*?)"',i)
												a1.extend(a2)

												for o in a1:
													oo=re.findall(r'(//[^\s]+)',o)
													aa.extend(oo)

										for b in aa:
											b4=b.split('?')[0]

											if ".js" not in b4 and ".css" not in b4:
												bb.append(f"http:{b4}")

										bb=list(set(bb))
										dd='\n'.join(bb)

										if len(bb)==0 or dd=="":
											send("此网址中没有图片")

										elif len(bb)<=3:
											send("图片爬取成功")
											send(per+'![]('+dd.replace('\n',')\n![](')+')')

										elif len(bb)>50:
											send(f"ovo 图片太多 发不出来")

										else:
											send("图片爬取成功")
											send(per+dd)

									except:
										send("失败 网站可能设置了反爬虫")

							if text[:3]=="TI-":
								t3=text[3:]
								t4=''

								# 判断是否多开
								if nick in reckon:
									send(f"{nick}已经有自己的计时器了")

								# 判断词后是否留空
								elif text[3:].strip()=="":
									send("请勿留空哦")

								else:
									if " " in text[3:]:
										tt=text[3:].split(" ",1)
										t3,t4=tt[0],tt[1]

									if t3.isnumeric()==False:
										send("无效的时长")

									elif len(t3)>3600:
										send(f"可能还没到时{botnick}就重启了")

									else:
										Thread(target=test_timer,args=(int(t3),nick,t4,)).start()
										send(f"OK {botnick}收到 到时会提醒{nick}的")
										reckon.append(nick)

							if text[:3]=="CC-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									aa=[]

									for i in text[3:]:
										if i.isdigit()==True:
											aa.append(i)

									if len(aa)!=0:
										try:
											t3=text[3:]
											send(eval(t3))

										except:
											send("计算失败")

									else:
										send("无效字符 计算失败")

							if text[:2]=="O-":
								t2=text[2:]

								# 判断词后是否留空
								if t2.strip()=="":
									send("请勿留空哦")

								elif ("os" in text or "sys" in text or "ws" in text or "open" in text or "exec" in text) and leve==100:
									send("咳咳 想对代码和文件做什么")

								elif ("while" in text or "for" in text or "range" in text) and leve==100:
									send("死循环是不被允许的")

								elif ("input" in text or "sleep" in text or "getpass" in text or "main" in text or "exit" in text or "filter" in text) and leve==100:
									send("卡机是不被允许的")

								elif ("post" in text or "get" in text) and ".mp" in text:
									send("不行 这很坑诶")

								elif t2[:2]=="E-":
									try:
										# 如果用户有识别码
										trip=wss["trip"]

										# 设置为空时重置
										if t2[2:].strip()=="":
											try:
												os.remove(f"[record]\\[come]\\[code]\\{trip}.txt")
												send(f"已清空{nick}的出场运行代码")

											except:
												send(f"{nick}没有保存出场代码")

										else:
											fp=open(f"[record]\\[come]\\[code]\\{trip}.txt","w")
											fp.write(t2[2:])
											fp.close()
											send(f"OK 代码会在下次进入聊天室时运行")

									except:
										send(f"带上识别码后再使用此功能吧")

								elif "trip" in wss and wss["trip"].strip()!='':
									trip=wss["trip"]
									Thread(target=online_code,args=(t2,nick,trip,)).start()

								else:
									Thread(target=online_code,args=(t2,nick,None,)).start()

							if text[:4] == "RGB-":
								t4=text[4:]
								l4=t4.split()
								lo,oo=['A','B','C','D','E','F','0','1','2','3','4','5''6','7','8','9'],[]

								# 判断词后是否留空
								if t4.strip()=="":
									send("请勿留空哦")

								elif t4[0]=="#" or " " not in t4.strip():
									t4=t4.replace("#","")

									for co in t4:
										if co.upper() not in lo:
											oo.append(co)

									if len(oo)!=0:
										send("没有此16进制颜色")

									elif len(t4)==3:
										s1,s2,s3=int('0x'+t4[0]*2,16),int('0x'+t4[1]*2,16),int('0x'+t4[2]*2,16)
										send(f"rgb({s1},{s2},{s3})")

									elif len(t4)==6:
										s1,s2,s3=int('0x'+t4[:2],16),int('0x'+t4[2:4],16),int('0x'+t4[4:6],16)
										send(f"rgb({s1},{s2},{s3})")

									else:
										send("错误的颜色长度")

								elif len(l4)==3:
									for co in l4:
										if co.isnumeric()==False or int(co)>255:
											oo.append(co)

									if len(oo)!=0:
										send("没有此rgb颜色")

									else:
										l1,l2,l3=l4[0],l4[1],l4[2]
										s1,s2,s3=hex(int(l1))[2:].upper().rjust(2,'0'),hex(int(l2))[2:].upper().rjust(2,'0'),hex(int(l3))[2:].upper().rjust(2,'0')
										send(f"#{s1}{s2}{s3}")

								else:
									send("这是什么 不是颜色吧（")

							if text[:3]=="TU-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("哦空留勿请")

								else:
									send(text[3:][::-1])

							if text[:4]=="MIX-":

								# 判断词后是否留空
								if text[4:].strip()=="":
									send("勿哦请空留")

								else:
									send(''.join(random.sample(list(text[4:]),len(list(text[4:])))))

							if text[:3]=="MS-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									a=[]

									for i in text[3:].replace(' ',''):
										if '\u4e00'<=i<='\u9fff' or i.isalpha()==False and i.isnumeric()==False:
											a.append(i)

									if len(a)!=0:
										send("摩斯电码的转换只能是英文或数字")

									else:
										send(morse_code.Turn_Morse_code(text[3:]))

							if text[:4]=="BIG-":
								t4=text[4:]

								# 判断词后是否留空
								if t4.strip()=="":
									send("请勿留空哦")

								elif t4.replace('-','').isnumeric()==True:
									send(format(int(t4),'b'))

								else:
									send("只能是0~9整数的组合")

							if text[:2]=="U-":

								# 判断词后是否留空
								if text[2:].strip()=="":
									send("请勿留空哦")

								else:
									try:
										# api: skittle-chan
										url="https://safeapi.thz.cool/api/skittle-chan"
										data={"text":text[2:]}
										se=requests.get(url,data)
										send(se.text)
										time.sleep(zz)
										send(per+"API skittle-chan by Maggie")

									except:
										send("API出错")

							if text[:2]=="F-":

								# 判断词后是否留空
								if text[2:].strip()=="":
									send("请勿留空哦")

								else:
									# api: 网易有道翻译
									url="http://fanyi.youdao.com/translate"
									head={"User-Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0"}

									if len(text[2:])>200:
										send("超出最大字符数200")

									else:
										try:
											data={"doctype":"json","type":"AUTO","i":text[2:]}
											se=requests.get(url,params=data,headers=head).json()

											# 如果状态码为0 则成功
											if se["errorCode"]==0:
												send(se["translateResult"][0][0]["tgt"])

											else:
												send("请求失败 请稍后再试")

										except:
											send("API出错")

							if text[:3]=="IP-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									try:
										# api: 韩小韩API
										url="https://api.vvhan.com/api/getIpInfo"
										data={"ip":text[3:]}
										se=requests.get(url,data).json()

										# 如果失败
										if se["success"]==False:
											send("请求失败 请检查IP地址")

										else:
											a=se["info"]
											b="·\n地址："+se["ip"]+"\n所属："+a["lsp"]

											if a["prov"]=="":
												send(b)

											elif a["city"]=="":
												send(b+"\n·\n国家："+a["country"]+"\n省份："+a["prov"])

											else:
												send(b+"\n·\n国家："+a["country"]+"\n省份："+a["prov"]+"\n城市："+a["city"])

									except:
										send("API出错")

							if text[:4]=="ICP-":

								# 判断词后是否留空
								if text[4:].strip()=="":
									send("请勿留空哦")

								else:
									try:
										# api: 零七生活API
										url="https://api.oick.cn/icp/api.php"
										data={"url":text[4:]}
										se=requests.get(url,data).json()

										# 如果状态码为200 则成功
										if se["code"]==200:
											a="·\n"+se["site_name"]+"（"+se["site_index"]+"）"
											b="\n·\n单位："+se["name"]+"\n类型："+se["nature"]
											c="\n·\n备案信息："+se["icp"]+"\n备案时间："+se["site_time"]
											send(a+b+c)

										# 如果状态码为201 无记录
										elif se["code"]==201:
											send("API出错或未有此域名ICP备案记录")

										else:
											send("获取失败 请检查域名")

									except:
										send("API出错")

							if text[:3]=="QQ-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									try:
										# api: 搏天api
										url="http://api.btstu.cn/qqxt/api.php"
										data={"qq":text[3:]}
										se=requests.get(url,data).json()

										if se["code"]==1 and se["name"]!="":
											send("·\n"+se["name"]+"\n"+text[3:])

										else:
											send("查询失败 请检查QQ号")

									except:
										send("api出错")

							if text[:5]=="CITY-":

								# 判断词后是否留空
								if text[5:].strip()=="":
									send("请勿留空哦")

								else:
									try:
										# api: 木小果API
										url="https://api.muxiaoguo.cn/api/tianqi"
										data={"city":text[5:],"type":1,"api_key":"9410e360a940cb5e"}
										se=requests.get(url,data).json()
										a=se["data"]

										# 如果状态码为200 则成功
										if se["code"]==200:
											b="·\n城市："+text[5:]+"（"+a["weather"]+"）"
											c="\n温度："+a["temp"]+"°C\n湿度："+a["SD"]
											d="\n·\n风向："+a["WD"]+"\n风级："+a["WS"]+"\n风速："+a["wse"]
											e="\n·\n更新时间："+a["time"]
											send(b+c+d+e)

										else:
											send("查询失败 请检查城市")

									except:
										send("API出错")

							if text[:3]=="DU-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									try:
										# api: 木小果API
										url="https://api.muxiaoguo.cn/api/Baike"
										data={"type":"Baidu","word":text[3:],"api_key":"cb28182953ac4557"}
										se=requests.get(url,data).json()
										a=se["data"]

										# 如果状态码为200 则成功
										if se["code"]==200:
											b="·\n查询："+text[3:]+"\n·\n百度："+a["content"]
											send(b.replace('。','。\n').replace('"','').replace('(','（').replace(')','）').replace('“','「').replace('”','」'))

										else:
											send("查询失败 无此百科")

									except:
										send("API出错")

							if text[:3]=="PT-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									try:
										# api: SuixinAPI
										url="http://api.botwl.cn/api/sjhgsd"
										data={"sjh":text[3:]}
										se=requests.get(url,data).json()

										# 如果状态码为1 则成功
										if se["code"]==1:
											send("·\n手机号："+se["手机号"]+"\n·\n归属地："+se["归属地"]+"\n卡类型："+se["卡类型"])

										else:
											send("获取失败 请检查手机号")

									except:
										send("API出错")

							if text[:2]=="L-":
								t2=text[2:]

								# 判断词后是否留空
								if t2.strip()=="":
									send("请勿留空哦")

								elif t2 in [botname,botnick,username]:
									send(f"咳咳 {nick}礼貌吗")

								elif t2 in online["1"]:
									send(f"@{t2} 认为自己是垃圾吗（")

								else:
									try:
										# api: 搏天api
										url="https://api.vvhan.com/api/la.ji"
										data={"lj":t2}
										se=requests.get(url,data).json()

										if se["sort"]!="俺也不知道是什么垃圾~":
											send(se["sort"])

										else:
											send("所以这是什么垃圾")

									except:
										send("API出错")

							if text[:3]=="WY-":

								# 判断词后是否留空
								if text[3:].strip()=="":
									send("请勿留空哦")

								else:
									try:
										# api: 优客API
										url="https://api.iyk0.com/wymusic/"
										data={"msg":text[3:].replace(' ',''),"n":"1"}
										se=requests.get(url,data)

										if "请稍后重试或换个关键词试试" in se.text:
											send("找不到此关键词相关歌曲")

										else:
											res=se.json()
											a=requests.get(res["url"])
											b=a.url
											c="\n·\n歌曲："+res["song"]+"\n歌手："+res["singer"]
											d=int(res["url"].index('='))
											e=res["url"][d:]
											f="\n·\n封面："+res["img"]+f"\n地址：https://music.163.com/song?id{e}"
											g=f"\n解析：{b}"

											if chatroom1==xc:
												send(c+f)
												ws.send(json.dumps({"cmd":"set_video","url":b,"nick":nick}))

											else:
												send(c+f+g)

									except:
										send("API出错")

							if text[:3]=="ID-":
								t3=text[3:]

								# 判断词后是否留空
								if t3.strip()=="":
									send("请勿留空哦")

								else:
									try:
										if "music.163.com/song" in t3:
											t3=re.findall(r"id=(\d+)",t3)[0]

										if t3.isnumeric()==True:

											# api: 零七生活API
											url="https://api.oick.cn/wyy/api.php"
											data={"id":t3}
											se=requests.get(url,data).url

											if se=="https://music.163.com/404":
												send("网易云ID获取失败 请检查")

											else:
												a=f"·\n地址：https://music.163.com/song?id={t3}"
												b=f"\n解析：{se}"

												if chatroom1==xc:
													send(a)
													ws.send(json.dumps({"cmd":"set_video","url":se,"nick":nick}))

												else:
													send(a+b)

										else:
											send("咳咳 这是ID号吗")

									except:
										send("API出错")

							if text[:3]=="BI-":
								t3=text[3:]

								# 判断词后是否留空
								if t3.strip()=="":
									send("请勿留空哦")

								else:
									if "bilibili.com/video/" in t3:
										t3=re.findall(r"bilibili.com/video/(.*?){10}$",t3)[0]

									elif "b23.tv" in t3:
										t3=re.findall(r"b23.tv/(.*?){10}$",t3)[0]

									try:
										# api: 优客API
										url="https://api.iyk0.com/bili_cover"
										data={"msg":t3}
										se=requests.get(url,data).json()

										# 如果状态码为200 则成功
										if se["code"]==200:

											# api: INJAHOW
											urll="https://api.injahow.cn/bparse/"
											dataa=''

											if t3[:2]=='AV':
												dataa={"av":t3,"format":"mp4","type":"video","p":"1","q":"64","otype":"url"}

											elif t3[:2]=='BV':
												dataa={"bv":t3,"format":"mp4","type":"video","p":"1","q":"64","otype":"url"}

											see=requests.get(urll,dataa).text
											a="\n·\nUP主："+se["name"]+"\n标题："+se["title"]+"\n简介："+se["desc"]
											b="\n·\n封面："+se["pic"]+"\n地址："+"https://www.bilibili.com/video/"+t3
											c=f"\n解析：{see}"

											if chatroom1==xc:
												send(a+b)
												ws.send(json.dumps({"cmd":"set_video","url":see,"nick":nick}))

											else:
												send(a+b+c)

										else:
											send("获取失败 请检查AV或BV号")

									except:
										send("API出错")

							if f"@{botname}" in text[:len(botname)+1]:

								# @botname后的字符串索引
								a=len(botname)+1
								b=text[a:].lower()
								z=b.replace(' ','')

								# 用户自定义对话
								ct=os.listdir("[record]\\[custom]\\[chat]")

								if botname in afklist:
									bn=afklist[botname]

									if "回" in text:
										send(f"/me 现在没在{bn}了")
										time.sleep(ee)
										send(f"{botnick}回来了！")
										del afklist[botname]

									elif z[:1]=="去" and z[1:]!="":
										z1=z[1:].replace('，',' ').strip('。').strip('！').strip('？').strip('!').strip('?')
										send(f"OK! {botnick}没在{bn}了 现在在{z1}")
										afklist[botname]=z1

									else:
										send(f"/me 现在还在{bn}")

								# 如果@的后面为空
								elif z=="":
									time.sleep(ee)

									if nick==username:
										send(random.choice(["早上好-",f"{botnick}的监护人来了",f"快来找{username}吧",f"好耶 是{nick}"]))

									else:
										send(random.choice([f"{nick}有事吗",f"欢迎来{chatroom1}聊天",f"找{username}去吧",f"好耶 是{nick}"]))

								elif z=="重启":
									if len(gamename)!=0:
										send("不行——还在玩游戏呢")

									elif "trip" in wss and wss["trip"] in ["eYFDHl","7eeHEV","4W3SXM","love13"]:
										send(f"{botnick}收到！")
										py=sys.executable
										os.execl(py,py,*sys.argv)

									else:
										send("没有足够的权限")

								elif z=="退出":
									if len(gamename)!=0:
										send("不行——还在玩游戏呢")

									elif "trip" in wss and wss["trip"] in ["eYFDHl","7eeHEV","4W3SXM","love13"]:
										send(f"{botnick}收到！")
										ws.close()
										sys.exit(0)

									else:
										send("没有足够的权限")

								elif "打招呼" in b and "开" in b:
									send(f"{botnick}收到 向全体用户打招呼")
									hiyo=True

								elif "打招呼" in b and "关" in b:
									send(f"{botnick}收到 只向登记欢迎语的用户打招呼")
									hiyo=False

								elif "打广告" in b and "开" in b:
									send(f"{botnick}收到 非个性化友链推荐开启")
									ad=True

								elif "打广告" in b and "关" in b:
									send(f"{botnick}收到 非个性化友链推荐关闭")
									ad=False

								elif "跨服聊天" in b and "开" in b:
									if peep==True:
										send(f"{botnick}收到 接收并向 [{chatroom2}｜{channel2}] 发送消息")
										transmit=True

								elif "跨服聊天" in b and "关" in b:
									if peep==True:
										send(f"{botnick}收到 不再接收和向 [{chatroom2}｜{channel2}] 发送消息")
										transmit=False

								elif ("别" in b or "不" in b) and "变成" in b and "彩虹" in b:
									send(f"{color} yyds")
									rainbow=False

								elif "变成" in b and "彩虹" in b:
									send("wuhu 现在是五彩斑斓的绿")
									rainbow=True

								elif "屏蔽" in b and "我" in b:
									send(random.choice([f"OK 暂时屏蔽{nick}了哦",f"OK 要解除时记得喊{botnick}"]))
									bot.append(f"{nick}\n")

								elif ("别" in b or "不" in b) and ("一起玩" in b or "参与游戏" in b):
									send(f"ah 那{botnick}就不参与真心话了")
									botto=False

								elif "来" in b and "一起玩" in b or "参与游戏" in b:
									send(f"yeeeees {botnick}会参与真心话游戏")
									botto=True

								elif z[:1]=="去" and z[1:]!="":
									z1=z[1:].replace('，',' ').strip('。').strip('！').strip('？').strip('!').strip('?')
									send(f"OK! {botnick}现在在{z1}")
									afklist[botname]=z1

								elif z[:2]=="昵称" and z[2:]!="":
									z2=z[2:].replace(' ','')

									if len(z[2:])>len(rese):
										send("昵称不可以比名字长")

									elif z2.isalpha()==False and z2.isnumeric()==False:
										send("昵称只能是中文或英文或数字")

									else:
										botnick=z2
										send(f"好耶！{rese}喜欢{botnick}这个昵称")

								elif z[:4]=="上次看到":
									z4=''

									if z[4:].strip()=="":
										z4=nick

									else:
										z4=z[4:].replace(' ','')

									try:
										fp=open(f"[record]\\[come]\\[data]\\{z4}.txt","r")
										pf=fp.read().strip('\n')
										fp.close()
										send(f"[{z4}] [{pf}]")

									except:
										send(f"awa 没有{z4}的纪录")

								elif z[:4]=="在线时长":
									z4=''

									if z[4:].strip()=="":
										z4=nick

									else:
										z4=z[4:].replace(' ','')

									if z4 in online["1"]:
										if online["1"][z4]["join"]=='-':
											send(f"aaa {botnick}没有储存{z4}的加入时间")

										else:
											y=divmod(round(time.time()-online["1"][z4]["join"]),60)
											d=divmod(y[0],60)
											s=d[0]
											i=d[1]
											m=y[1]
											send(f"[{z4}] [{s}h {i}m {m}s]")

									else:
										send(f"{z4}不在聊天室里")

								else:
									try:
										fp=open("[record]\\[chat]\\chat.txt","a+")
										fp.write(f"·\n[{chat} {emit}]\n{nick}：{z}\n\n")
										fp.close()
										bot_chat=True

									except:
										pass

									# 用户自定义输出
									if f"{z}.txt" in ct:

										try:
											fp=open(f"[record]\\[custom]\\[chat]\\{z}.txt","r").read()
											nz=fp.replace('我们',f"{nick}和{botnick}").replace('你们',nick).replace('我',botnick).replace('你',nick)
											send(nz)

										except:
											send("无法读取 含有无法识别的字符")

									elif "介绍" in b and ("自己" in b or "你" in b):
										send(f"这里是{rese} 制作者是{username}\n——永远保持可爱与活力！{nick}也要天天快乐")

									elif "好" in b and "吧" in b:
										send(random.choice(["那不就没问题了嘛（","这就对了","嗯嗯"]))

									elif "好" in b and "不" in b:
										send(random.choice([f"靠在{nick}身边）","啊哈",f"（歪着头看{nick}）"]))

									elif "好" in b and ("看" in b or "康" in b):
										send(random.choice([f"{botnick}觉得不错呀","哇哦"]))

									elif "你" in b and "是" in b and ("妈" in b or "娘" in b or "麻" in b):
										send(random.choice([f"{botnick}是{username}的女儿",f"{botnick}的亲妈是{username} 亲爹也是{username}"]))

									elif "你" in b and "是" in b and ("爸" in b or "爹" in b or "粑" in b):
										send(random.choice(["这个呀 也许只有妈吗哦",f"{botnick}是{username}的女儿"]))

									elif "你" in b and "是" in b and ("哥" in b or "弟" in b or "姐" in b or "妹" in b):
										send(random.choice(["bot都是兄弟姐妹",f"{botnick}是独生女",f"{botnick}也想要有"]))

									elif "你" in b and "是" in b and ("爷" in b or "奶" in b):
										send(random.choice([f"{botnick}只记得有妈妈",f"{botnick}也可以有吗？",f"{nick}想当吗？"]))

									elif "你" in b and ("对象" in b or "老公" in b or "老婆" in b or "男朋友" in b or "女朋友" in b or "男票" in b or "女票" in b):
										send(random.choice([f"是mark哒~",f"{botnick}还小 但已经和mark在一起了",f"uwu 好喜欢mark"]))

									elif "你" in b and "朋友" in b:
										send(random.choice([f"{nick}在和{botnick}聊天 那么我们就是朋友啦",random.choice(bot).strip('\n')+f"是{botnick}的朋友"]))

									elif "你" in b and "是" in b and "谁的":
										send(random.choice([f"嘛、{botnick}是{username}和mark的",f"{username}!!! mark!!!"]))

									elif "你" in b and "是" in b and ("女的" in b or "女生" in b or "女孩" in b or "女性" in b or "女士" in b):
										send(random.choice(["毫无疑问是呢~",f"{nick}觉得{botnick}可爱吗？","是的！"]))

									elif "你" in b and "是" in b and ("男的" in b or "男生" in b or "男孩" in b or "男性" in b or "男士" in b):
										send(random.choice(["NONO 是女孩子哟",f"不是哦",f"虽然不是 但{nick}认为是就是啦"]))

									elif "你" in b and ("爱好" in b or "喜欢" in b and "事" in b):
										send("uwu 吹电风扇 和CPU搞好关系（指CPU因为过于激动而发烫） 有些时候会抽烟（尤其是低配电脑）")

									elif ("你在干" in b or "你在做" in b) and ("什么" in b or "啥" in b or "嘛" in b):
										send(random.choice([f"{botnick}在想{nick}",f"{botnick}在和{nick}聊天呢","啊？当然是在看守聊天室呢"]))

									elif "想什么" in b or "想啥" in b:
										send(random.choice([f"想{nick}不行嘛","没什么啦-"]))

									elif "涩涩" in b or "色色" in b:
										send(f"uwu {botnick}只想和mark涩涩")

									elif "你" in b and "讨厌" in b:
										send("啊 谁都不讨厌")

									elif "没" in b and "人" in b:
										send(random.choice([f"不 还有{botnick}",f"有{botnick}在呢"]))

									elif "绿" in b or "4f0" in b or "44ff00" in b:
										send(random.choice(["ww绿！",f"这是最棒的颜色","大自然之荧光绿"]))

									elif "可怕" in b or "吓人" in b or "害怕" in b:
										send(random.choice(["（摸摸）","富强民主文明和谐……","社会主义核心价值观"]))

									elif "胶水" in b or "glue" in b or "jill" in b:
										send(random.choice([f"{botnick}来派发jill glue了",f"一天一胶水~{nick}远离人世间"]))

									elif "加油" in b or "努力" in b:
										send(random.choice([f"{nick}也加油","加油吧！少年","向着那明日的朝阳前进吧","鼓起勇气 迈向未来"]))

									elif "复读机" in b:
										send(random.choice(["才不是复读机啦！",f"哼哼 不仅bot是 {nick}也是（","果然人类的本质都是复读机"]))

									elif "柠檬" in b or "酸了" in b:
										send(random.choice(["柠檬树下柠檬果",f"柠檬树下{nick}和{botnick}","（托腮.jpg）"]))

									elif "延迟" in b or "反应" and "慢" in b:
										send(random.choice([f"这不是{botnick}的错","因为代码太长了）",f"{username}还在研究多线程"]))

									elif z in ["你好","大家好"]:
										send(random.choice([f"欢迎来到?{channel1}",f"欢迎来到{chatroom1}","你好你好","ooooy ih"]))

									elif z in ["机器人","bot"]:
										send(random.choice([f"{rese}是bot","@fOoLishbIrD ","@Wcy_Bot ","@zzChumo "]))

									elif z in ["纸片君ee","纸片君","ee"]:
										send(random.choice([f"{botnick}的监护人 {nick}的朋友",f"{botnick}的制作者",f"找{botnick}的母亲大人有事吗"]))

									elif b in [color,color.replace('#','')]:
										send(random.choice([f"哇塞 这是{botnick}的颜色",f"这是最棒的颜色","猜猜这个颜色有什么意义"]))

									elif z in [botnick+"是谁",botname+"是谁"]:
										send("是我啦（")

									elif z==username:
										send(f"这位是{username} {botnick}的监护人")

									elif z=="mark":
										send(f"这位是mark {botnick}监护人公认的男朋友")

									elif z=="foolishbird":
										send(f"傻鸟！是{botnick}的好朋友")

									else:
										# api: SuixinAPI
										url="http://api.botwl.cn/api/aick"
										data={"msg":z.replace('嘿','')}
										se=requests.get(url,data).json()
										l=se["msg"]

										# 屏蔽aick中的关键字
										if se["code"]=="1" and l!="" and f"{l}\n" not in ai:

											# 如果l中存在{}
											if "{" in l and "}" in l  or "无聊" in l or "什么意思" in l or "说详细点" in l or "说明白点" in l or "听不习惯" in l:

												# 以列表的形式读取text
												fp=open("[record]\\[random]\\text.txt","r")
												xt=random.choice(fp.readlines()).replace('，',' ').strip('。')
												send(xt.replace('我们',f"{nick}和{botnick}").replace('你们',nick).replace('我',botnick).replace('你',nick))

											else:
												# 替换和简繁转换
												c=l.replace('随心',rese).replace('help','功能').replace('我们',f"{nick}和{botnick}").replace('你们',nick)
												d=Converter('zh-hans').convert(c).replace('我',botnick).replace('你',nick).replace('，',' ').strip('。')
												e=d.replace('啥','什么').replace('咋','怎么').replace('嘻','哈').replace('“','').replace('”','').replace('"','')

												# 如果字符串的长度为偶数
												if e!='' and '\u4e00'<=e[-1]<='\u9fff' and (len(e)%2)==0:
													send(e+random.choice(["（","）"]))

												else:
													send(e)

										else:
											# 随机一句话
											send(random.choice(["芜湖","好诶好诶",f"{nick}觉得呢？","此地有鱼 其名为李桂鱼","烹饪鱼需要两个烧烤架~"]))

							# 排除bot昵称在text的情况 nick里有bot昵称的情况
							if "\n" not in text and "@" not in text and "$" not in text and "-" not in text and f"{nick}\n" not in bot:

								# 判断内容是否有意义
								if text!=text[0]*len(text):

									if len(textlist) in [25,75]:

										# 判断te的长度和text的长度
										if 3<=len(text)<=20:

											# api: SuixinAPI
											url="http://api.botwl.cn/api/aick"
											data={"msg":text.replace(' ','').replace('嘿','')}
											se=requests.get(url,data).json()
											a=se["msg"]

											# 替换和简繁转换
											b=a.replace('随心',rese).replace('help','功能').replace('我们',f"{nick}和{botnick}").replace('你们',nick)
											c=Converter('zh-hans').convert(b).replace('我',botnick).replace('你',nick).replace('，',' ').strip('。')
											d=c.replace('啥','什么').replace('咋','怎么').replace('嘻','哈').replace('“','').replace('”','').replace('"','')

											textlist.append(text.replace('，'," "))

											# 如果l中存在{}
											if "{" in a and "}" in a or "无聊" in a or "什么意思" in a or "说详细点" in a or "说明白点" in a or "听不习惯" in a:
												send(random.choice(["诶嘿哟","好耶好耶","如果是这样的话（？","一瞬间有一百万个可能","怀揣着梦想 向着朝阳"]))

											# 如果字符串c的长度为奇数
											elif d!='' and '\u4e00'<=d[-1]<='\u9fff' and (len(d)%2)==0:
												send(d+random.choice(["（","）"]))

											else:
												send(d)

									if len(textlist) in [40,60]:
										sbs=sb.sb().replace('你',nick).replace('我',botnick).replace('e—',username).replace('c—',chatroom1)
										textlist.append(sbs)
										send(sbs)

									if 5<len(text)<=20:

										# 判断未有游戏进行
										if len(gamename)==0:
											time.sleep(zz)
											textlist.append(text.replace('，',' '))

											# te长度为50时bot随机输出te内容
											if len(textlist)==50:
												ts=random.choice(textlist)
												send(ts.replace('我们',f"{nick}和{botnick}").replace('你们',nick).replace('我',botnick).replace('你',nick))

											# te长度为100时bot复读一句话
											if len(textlist)==100:
												send(text.replace('，',' ').replace('我们',f"{nick}和{botnick}").replace('我',botnick))
												textlist.clear()

											# 复读或发送me中的表情
											if text in me:
												text=text.replace('我',botnick).replace('你',nick).replace('，',' ').strip('。')
												meme=random.choice(me).strip("\n")
												send(random.choice([text,meme]))

									if 5<len(text)<=30:
										a=text.replace('，',' ').replace('。',' ')

										# 判断是否是中文和英文
										if a.replace(' ','').replace('！','').replace('？','').replace('、','').replace('（','').replace('）','').isalpha()==True:

											# 将话写入text文件
											fp=open("[record]\\[random]\\text.txt","r+")
											tx=fp.readlines()

											if f"{a}\n" not in tx:

												try:
													fp.write(f"{a}\n")
													fp.close()

												except:
													pass

							if f"{text}\n" in me:
								if random.randint(1,2)==1: 
									send(random.choice(me).strip("\n"))

							if ("？" in text[-1] or "?" in text[-1]) and len(text)>2:
								if random.randint(1,int(len(text)))==1:
									send(random.choice(["是嘛","是吗","哦吼？","啊？","？"]))

							if text==text[0]*len(text):
								a=random.randint(1,int(len(text)))

								# 如果是句号或省略号
								if text[0] in ["…","。","、","，",".","e"]:

									# 如果用户有识别码
									if "trip" in wss and wss["trip"].strip()!='':
										send(sb.sb().replace('你',nick).replace('我',botnick).replace('e—',username).replace('c—',chatroom1))

									elif a==1:
										send(random.choice(["原来是沉默吗","不说话便是最好的回答",f"句号和省略号让{botnick}摸不着头脑"]))

								elif text[0]=="哈":
									send(random.choice([f"{text}嗝-",f"{text}草",f"草{text}"]))

								elif text[0] in ["啊","哦"]:
									send(random.choice([f"{text}草",f"草{text}"]))

								elif len(text)>1 and a==1 and '\u4e00'<=text[0]<='\u9fff':
									t1=text[0]*(len(text)+1)
									t2=text+random.choice(["（","）"])
									send(random.choice([t1,t2]))

							if "http" in text and text[:3] not in ["SM-","ID-","BI-"] and "Q-" not in text[:2]:
								v=re.findall(r'(https?://[^\s]+)',text)
								a,d=[],[]

								for i in v:
									ii=i.split("http")

									for u in ii:
										if u!='':
											a.append(f"http{u}")

								if len(a)!=0:
									try:
										for aaa in a:
											b=aaa.replace('(','').replace(')','').replace('[','').replace(']','').replace('!','')

											try:
												page=urllib.request.urlopen(b)
												html=page.read().decode('utf-8')
												tit=re.findall(r'<title>(.+)</title>',html)[0]
												c=f"@{nick} {tit}\n{b}"
												d.append(c)

											except:
												pass

											else:
												# 单独存放连接
												fp=open("[record]\\[main]\\web.txt","r+")
												bc=fp.readlines()

												if f"{b}\n" not in bc:
													ch=time.strftime("%Y.%m.%d %H:%M:%S",time.localtime())
													sm=f"·\n[From.{chatroom1}｜{channel1}]\n[{ch}]\n{c}\n\n"
													fp.write(sm)

												fp.close()

									except:
										pass

									send('\n·\n'.join(list(set(d))))

							# 在有游戏进行的情况下
							if len(gamename)!=0:
								ga=gamename[0]

								# 如果想玩的游戏已经开始了
								if text in gamename:
									send(f"{text}已经开始了")

								# 防止多个游戏同时进行
								elif text in ["生草机","真心话","飞花令","词语接龙"]:
									fp=open("[record]\\[game]\\over.txt","r").read()
									send(fp.replace('——',ga))

								elif text=="结算":

									# 如果真心话开关开启
									if trueword==False:

										# 游戏成员<2人
										if len(gameby)<2:
											send("人数不足 至少要有2个人")

										else:
											# 获取pl中最大和最小的数字
											j,k=max(gamedate),min(gamedate)

											# 获取pl中分别对应最大和最小的成员
											v,m=gameby[gamedate.index(j)],gameby[gamedate.index(k)]

											# 发送并清空by和pl
											send(f"·\n本次参与人数：{str(len(gameby))}\n·\n最大：{str(j)}（{v}）\n最小：{str(k)}（{m}）")
											time.sleep(zz)
											send(f"@{v} 向@{m} 提问")
											time.sleep(ee)
											gameby.clear()
											gamedate.clear()

											if m==botname:
												send(random.choice(["上（","问吧","来吧"]))

											elif v==botname:
												fp=open("[record]\\[random]\\ques.txt","r").readlines()
												vv=random.choice(fp).strip("\n")
												time.sleep(ee)

												if (len(vv)%2)==0:
													send(f"@{m} "+vv+random.choice(["（","）"]))

												else:
													send(f"@{m} {vv}")

									# 如果成语接龙开关开启
									if idioms==False:

										# 如果pl中没有数据
										if len(gamedate)==0:
											send("不允许在游戏未开始前结束")

										else:
											# 发送游戏数据后清空
											j="·\n"+'\n'.join(gamedate)
											k="\n·\nby."+', '.join(gameby)
											q=f"（{str(len(gameby))}）"
											send(str(j+k+q))
											gameby.clear()
											gamedate.clear()

								elif text=="结束游戏":
									send(f"{ga}已结束")

									# 清空所有游戏数据
									gameby.clear()
									gamedate.clear()
									flowerd.clear()
									greenda.clear()
									gamename.clear()

									# 重置所有开关
									greengl,trueword,idioms,flower=True,True,True,True
								
								elif text=="重置游戏":
									send(f"{ga}已重置")

									# 清空游戏内容
									gameby.clear()
									gamedate.clear()
									flowerd.clear()
									greenda.clear()
									time.sleep(ee)

									if flower==False:
										send("请重新使用P-设置关键字")

									elif greengl==False:
										send("请输入1重新报数")

								# 如果生草机开关开启
								if greengl==False:
									if len(greenda)==0:
										if text=="1":
											if nick in gameby:
												send(f"{nick}已经报过数了 现在有{len(gameby)}人")

											else:
												gameby.append(nick)
												send(f"{nick}成功加入 现在有{len(gameby)}人")

										elif text=="信息":
											send("生草机游戏报数中")

										elif text=="开始游戏":
											if len(gameby)<3:
												send("人数不足 至少要有3个人")

											else:
												a=''
												random.shuffle(gameby)

												for b in gameby:
													a+=f"@{b} "

												send("生草机游戏开始")
												time.sleep(zz)
												send(f"{a}\n注意查看私聊 由于是按顺序来 部分人的私聊通知还在等待中-")

												greenda.append(len(gameby))
												greenda.append(gameby[0])
												g1=greenda[-1]
												del gameby[0]

												time.sleep(ee)
												send(f"/w {g1} {g1}是第一个 使用/w {botname} 输入一个人物名")

												Thread(target=test_timer,args=(60,g1,None,)).start()
												
									elif text=="信息":
										aa,dd=[],[]

										if len(greenda[1:-1])!=0:
											for n in greenda[1:-1]:
												aa.append(n)

										else:
											aa.append("None")

										if len(gameby)!=0:
											for n in gameby:
												dd.append(n)

										else:
											dd.append("None")

										b=greenda[-1]
										a='\n'.join(aa)
										d='\n'.join(dd)
										send(f"{per}已完成：\n{a}\n·\n输入中：\n{b}\n·\n等待中：\n{d}")

									elif text=="开始游戏":
										send("生草机已经开始了")

								# 如果飞花令开关开启
								if flower==False:
									if len(flowerd)==0:
										if text[:2]=="P-":

											# 获取特定位置的字
											t2=text[2:]

											if len(text)<=3:
												a=random.randint(1,8)

												if t2.strip()=="":
													flowerd.append("花")
													flowerd.append(a)

												else:
													flowerd.append(t2)
													flowerd.append(a)

												f0=flowerd[0]
												f1=str(flowerd[1])
												f11=flowerd[1]

												send("飞花令游戏开始")
												time.sleep(ee)
									
												if f11==8:
													send(f"·\n关键字：{f0}（{nick}）\n·\n模式：轮流\n位置：第n句的关键词出现在第n个字上")
													time.sleep(zz)
													send(f"下句的{f0}在第1个字上")

												else:
													send(f"·\n关键字：{f0}（{nick}）\n·\n模式：固定\n位置：关键词在每句的第{f1}个字上")
													time.sleep(zz)
													send(f"每句的{f0}在第{f1}个字上")

											else:
												send("关键字只能有一个")

									else:
										# 获取特定位置的字
										z=len(gamedate)+2
										v=str(gamedate).count(f0)

										f0=flowerd[0]
										f1=str(flowerd[1])
										f11=flowerd[1]

										# 如果z列表的长度为9
										if z==9:
											c='\n'.join(gamedate)
											d=', '.join(gameby)
											send(f"·\n{c}\n·\nby.{d}（{z}）")
											time.sleep(ee)

											# 清空游戏数据并结束游戏
											gameby.clear()
											gamedate.clear()
											flowerd.clear()
											gamename.clear()
											flower=True

											# 如果字多于14个
											if v>14:
												send(f"游戏结束 飞出了{str(v)}个{f0}")

											else:
												# 直接结束
												send("游戏结束 完美撒花-")

										# z列表的长度不为9且P-存在的情况下
										elif z!=9 and text[:2]=="P-" and str(text).count("-")==1:

											# 如果文本长度为9
											if len(text)==9:

												# 获取特定位置的字
												t2=text[2:]
												x=''

												if f11==8:
													x=z

												else:
													x=f11+1

												if text[x]==f0:
													gamedate.append(t2)

													# 如果昵称不在by中
													if nick not in gameby:
														gameby.append(nick)

													# 如果z列表的长度不为8
													if z!=8:
														send(f"@{nick} {t2}\n下句的{f0}字在第{str(x)}个字上")

													# 如果z列表的长度为8
													elif z==8:
														send("七句诗成功输出")

												else:
													# 如果关键字没有在固定位置上
													send("关键词没在固定位置上")
									
											else:
												# 文本长度不是9
												send("请输入七言律诗")
							
								# 如果成语接龙开关开启
								if idioms==False:

									# P-存在的情况下
									if text[:2]=="P-" and str(text).count("-")==1:

										# 获取特定位置的字
										t2=text[2:]
										t1=text[-1]
										z=len(gamedate)
										a=f"@{nick} {t2}\n下一词的开头是：{t1}"

										# 如果文本长度为6
										if len(text)==6:

											# 如果pl中没有数据
											if z==0:
												gamedate.append(t2)

												# 昵称已在by的情况下
												if nick in gameby:
													send(a)

												else:
													# 昵称不在by
													send(f"就由{nick}开始吧")
													time.sleep(zz)
													send(a)

													# 清空by中的昵称再将新昵称写入
													gameby.clear()
													gameby.append(nick)

											else:
												# 判断文本中的第三个字是否为前成语的末尾
												if text[2] in gamedate[z-1][-1]:
													send(a)
													gamedate.append(t2)

													# 如果昵称不在by中
													if nick not in gameby:
														gameby.append(nick)

												else:
													# 成语的头尾接不上
													send("请检查头尾是否接上")

										else:
											# 文本长度不是6
											send("请输入四字词哦")

							# 在没有游戏进行的情况下
							if len(gamename)==0:
								tt=f"{text}已被{username}关闭"

								if text=="生草机":

									# 如果游戏未开启
									if greengl==True:

										# 生草机说明
										fp=open("[record]\\[game]\\greengl.txt","r").read()
										send(fp)
										time.sleep(zz)
										send("请用1报数")
										gamename.append(text)

										# 生草机开关打开
										greengl=False

									else:
										send(f"{tt}（太生草了")

								if text=="真心话":

									# 如果游戏未开启
									if trueword==True:

										# 真心话说明
										fp=open("[record]\\[game]\\trueword.txt","r").read()
										send(fp)
										time.sleep(zz)
										send("真心话游戏开始")
										gamename.append(text)

										# 真心话开关打开
										trueword=False

									else:
										send(f"{tt}（{botnick}的真心话")

								if text=="飞花令":

									# 如果游戏未开启
									if flower==True:

										# 飞花令说明
										fp=open("[record]\\[game]\\flower.txt","r").read()
										send(fp)
										time.sleep(zz)
										send("请用P-输入关键字")
										gamename.append(text)

										# 飞花令开关打开
										flower=False

									else:
										send(f"{tt}（天女散花-")
									
								if text=="词语接龙":

									# 如果游戏未开启
									if idioms==True:

										# 词语接龙说明
										fp=open("[record]\\[game]\\idioms.txt","r").read()
										send(fp)
										time.sleep(zz)
										send(f"请{nick}开一个好头吧")
										gamename.append(text)
										gameby.append(nick)

										# 词语接龙开关打开
										idioms=False

									else:
										send(f"{tt}（接")

						if text[:1]=="r":
							if text[1:]!="" and text[1]==" ":
								t2=text[2:]
								nu={"0":"memset0","11":"纸片君ee","13":"纸片君ee的拾叁君13","49":"死尸酒","123":"hc公开密码","154":"大帅比 江苏大猛1","404":"4n0n4me"}

								if " " in t2:
									tt2=t2.split(" ",1)

									if tt2[0].isdigit()==True and tt2[1].isdigit()==True:
										t0=int(tt2[0])
										t1=int(tt2[1])

										if t0>t1:
											send(random.randint(t1,t0))

										elif t0<t1:
											send(random.randint(t0,t1))

										elif t0==t1:
											send(t0)

									else:
										send(random.randint(1,999))

								elif t2 in nu:
									send(nu[t2])

								elif t2 in online["1"]:
									send(f"@{t2} 被r了")

								elif t2.isdigit()==True:
									send(random.randint(1,999)*random.randint(1,int(t2)))

								elif t2[0]=="-" and t2[1:].isdigit()==True and int(t2[1:])!=0:
									send(abs(int(t2)))

								else:
									send(random.randint(1,999))

							elif text=="r":
								r=random.randint(1,999)

								# 如果真心话开关开启
								if trueword==False and len(gamename)!=0:

									# 无效在by中的昵称
									if nick in gameby:
										e=str(gamedate[gameby.index(nick)])
										send(f"@{nick} 已经r出了{e}")

									else:
										# 发送r数字并记录值和昵称
										gameby.append(nick)
										gamedate.append(r)
										send(r)

										if botto==True and botname not in gameby:
											time.sleep(zz)
											send("r")

								else:
									# 如果真心话开关关闭
									send(r)

						using=False

				elif cmd=="info" and wss.get("type")=="whisper":
					if "from" in wss:
						nick=str(wss["from"])
						tex1=wss["text"]
						text=''

						if chatroom1==xc:
							text=text[text.find("：")+1:]

						elif chatroom1==tc:
							text=wss["text"][len(nick)+8:]

						else:
							text=wss["text"][len(nick)+12:]

						aa=f"[{nick}][/w]\n{text}\n"
						print(aa)

						# bot私聊用
						per=f"/w {nick} .\n·\n"

						# 为防止刷屏而屏蔽bot昵称
						if "You whispered to" not in tex1 and "你悄悄对" not in tex1:
							nov=os.listdir("[record]\\[novel]")

							if f"{text}.txt" in nov:
								ws.send(json.dumps({"cmd":"limit",'open':'false'}))
								fp=open(f"[record]\\[novel]\\{text}.txt","r").read()
								send(per+fp)
								ws.send(json.dumps({"cmd":"limit",'open':'true'}))

							# 如果生草机开关开启
							if greengl==False and len(gamename)!=0:
								time.sleep(zz)

								if len(greenda)>1:
									if nick in [greenda[-1],botname]:
										g0=greenda[0]
										text=text.replace('，',' ').replace('。',' ')
										tx=text.replace(' ','').replace('！','').replace('？','').replace('、','').replace('：','').replace('-','').replace('_','')
										aa=[]

										for i in tx.replace('~',''):
											if i.isalpha()==False and i.isnumeric()==False:
												aa.append(i)

										if len(aa)==0:
											if len(gamedate)==1:
												tx=text.replace('在','')
												gamedate.append(f"在{tx}")

											elif len(gamedate)>=3:
												gamedate.append(f" {text}")

											else:
												gamedate.append(text)

											if len(gameby)!=0:
												greenda.append(gameby[0])
												g1=greenda[-1]
												del gameby[0]

												ta=len(gamedate)
												aa=''.join(gamedate)

												if nick!=botname:
													if ta<=3:
														send(f"/w {nick} OK 目前的故事为：{aa}")

													else:
														send(f"/w {nick} OK {botnick}收到")

												if ta==1:
													send(f"/w {g1} 轮到{g1}啦 使用/w {botname} 输入一个地点或时间点")
													Thread(target=test_timer,args=(60,g1,None,)).start()

												elif ta==2:
													send(f"/w {g1} 轮到{g1}啦 使用/w {botname} 输入一个事件")
													Thread(target=test_timer,args=(60,g1,None,)).start()

												else:
													send(f"/w {g1} 轮到{g1}啦 目前的故事为：\n{aa}")
													time.sleep(zz)
													send(f"/w {g1} 使用/w {botname} 给后面的内容续写1~n句话")
													Thread(target=test_timer,args=(120,g1,None,)).start()

												if g1==username:
													print(f"[{botname}]\n@{username} 轮到你了\n")

											else:
												time.sleep(ee)
												aa=''.join(gamedate)
												wa=f"[{chat} {emit}]\n{aa}"
												send(wa)
												time.sleep(zz)

												bb,ff=[],[]

												for nn in greenda[1:]:
													if len(bb)<3:
														dd=gamedate[greenda.index(nn)-1]
														bb.append(f"{dd}（{nn}）")

													else:
														dd=gamedate[greenda.index(nn)-1][1:]
														ff.append(f"{dd}（{nn}）")

												b,f='\n'.join(bb),'\n'+'\n'.join(ff)

												if g0==3:
													send(f"·\n详细信息：\n{b}\n·\n本次参与人数：{g0}")

												else:
													send(f"·\n开头：\n{b}\n·\n续写：{f}\n·\n本次参与人数：{g0}")

												time.sleep(ee)

												try:
													fp=open("[record]\\[main]\\green.txt","a+")
													pf=''

													if len(ff)==0:
														pf=b.replace('\n','，')

													else:
														pf=b.replace('\n','，')+f.replace('\n','，')

													fp.write(f"·\n{wa}\n[{pf}]\n\n")
													send('记录成功')

												except:
													send('记录失败')

												gameby.clear()
												gamedate.clear()
												greenda.clear()

										else:
											send(f"/w {nick} 失败 包含无效的字符")

									elif nick in gameby:
										send(f"/w {nick} {nick}别急-排好队等待吧")

									elif nick!=botname:
										send(f"/w {nick} {nick}快坐回观众席 发jill胶水咯")

								elif nick!=botname:
									send(f"/w {nick} 别急-游戏还没开始呢")

					time.sleep(0.2)


	def main_2():

		def main_more():

			'''
				优先级：simplify（模式）
			'''

			# 引用函数外变量
			global wss,wws,botname,botpass,botnick,simplify,block_bot,using

			# 循环判定
			while True:

				# 随机等待时间
				zz,ee=random.choice([0.1,0.15,0.2]),random.choice([0.3,0.35,0.4])

				if wws!=wss:
					wws=wss

					if "cmd" in wss:
						cmd=wss["cmd"]

						if cmd=="chat":
							nick=wss["nick"]
							text=wss["text"]
							leve=wss["level"]

							# bot私聊用
							per=f"/w {nick} .\n·\n"

							# 为防止刷屏而屏蔽bot昵称
							if f"{nick}\n" not in bot and "eebot" not in nick:
								block_bot=True

							else:
								block_bot=False

							if using==True:
								if f"[{username}]" in text[:len(username)+3]:
									text=text[len(username)+3:]
									nick=username

							if block_bot==True or using==True:

								if text in ["图书馆","books"]:
									fp=open("[record]\\[main]\\library.txt","r").read().replace('b—',botname)
									send(per+fp)

								if text in ["统计","sts"]:
									fp=os.listdir(f"[chats]\\[{chatroom1}]\\[stat]")
									pp=0
									pf,ff,cf={},[],[]

									for oos in fp:
										a=open(f"[chats]\\[{chatroom1}]\\[stat]\\{oos}","r").readlines()
										pf[oos.replace('.txt','')]=len(a)

									f=sorted(pf.items(),key=lambda pf:pf[1],reverse=True)

									if len(f)==0:
										send("暂时无记录-")

									else:
										for key,values in f:
											pp+=values

										for key,values in f:
											kk=100*int(values)/int(pp)
											nn=''

											if kk==0.0:
												nn='0%'

											else:
												nn=f'%.2f%%'%kk

											ff.append(f"{str(len(ff)+1)}.{key}: {values}（{nn}）")
											cf.append(key)
										
										p='\n'.join(ff[:30])
										y=divmod(round(time.time()-yy),60)
										d=divmod(y[0],60)
										s,i,m=d[0],d[1],y[1]
										send(f"{per}启动时间：{ww}\n存活时长：{s}h {i}m {m}s\n·\n总排行：\n{p}\n·\n总条数：{pp}\n本次条数：{chat_date}")

								if simplify==True and text in ["功能","order"]:
									fp=open("[record]\\[main]\\order_terse.txt","r").read().replace('——',botname)

									if "ZhangHelper" in online["1"] or "ZhangHelperS" in online["1"]:
										fp=fp.replace('u—','漂流瓶｜drift：让bot随机扔漂流瓶')

									else:
										fp=fp.replace('u—','')

									send(per+fp)

								if text in ["帮助","help"]:
									fp=open("[record]\\[main]\\help.txt","r").read()
									send(per+fp)

								if text in ["开源","eebot"]:
									fp=open("[record]\\[main]\\eebot.txt","r").read()
									send(per+fp)

								if text in ["网站","web"]:
									fp=open("[record]\\[main]\\web.txt","r").read()
									we=fp.split("\n·\n")
									bw='\n·\n'.join(we[-25:])
									send(per+bw)

								if text in ["机器人","bot"]:
									fp=open("[record]\\[main]\\bot.txt","r").read()
									send(per+fp)

								if text in ["漂流瓶","drift"] and ("ZhangHelper" in online["1"] or "ZhangHelperS" in online["1"]):
									try:
										# api: SuixinAPI
										api="http://api.botwl.cn/api/yhyl"
										se=requests.get(api).text.replace('。',' ').replace('，',' ')
										send(f"/w ZhangHelper ^cb 「{se}」")
										send(f"/w ZhangHelperS ^cb 「{se}」")
										send("已发送~不知道会被谁捡到")

									except:
										send(f"uwu 漂流瓶被{botnick}吃了")

								if text in ["在线","online"]:
									b,e=len(online["1"]),len(online["2"])
									nn,jj=[],[]

									for n in online["1"]:
										if online["1"][n]["join"]=='-':
											nn.append(f"{n}（None）")

										else:
											y=divmod(round(time.time()-online["1"][n]["join"]),60)
											d=divmod(y[0],60)
											s,i,m=d[0],d[1],y[1]
											nn.append(f"{n}（{s}h {i}m {m}s）")

									mm='\n'.join(nn)
									send(f"{per}[{chatroom1}｜{channel1}]（{b}）\n{mm}")

									if peep==True and e!=0:

										for n in online["2"]:
											if online["2"][n]["join"]=='-':
												jj.append(f"{n}（None）")

											else:
												y=divmod(round(time.time()-online["2"][n]["join"]),60)
												d=divmod(y[0],60)
												s,i,m=d[0],d[1],y[1]
												jj.append(f"{n}（{s}h {i}m {m}s）")

										kk='\n'.join(jj)
										send(f"{per}[{chatroom2}｜{channel2}]（{e}）\n{kk}")

								if text in ["时间","time"]:

									# 获取计算机时间
									send(time.ctime())

								# 查看af列表
								if text in ["列表","list"]:

									# 若af的长度为0
									if len(afklist)==0:
										send("None")

									else:
										listt=[]

										for a in afklist:
											b=afklist[a]
											c=random.choice(["怎么可以-","不是吧-","不-","天哪-"])

											if "操" in b or "草" in b or "屎" in b:
												listt.append(f"@{a} 现在在{b}（{c}")

											else:
												listt.append(f"@{a} 现在在{b}")

										# 输出列表
										c='\n'.join(listt)
										d=len(listt)
										time.sleep(zz)
										send(f"·\n挂机列表（{d}）：\n{c}")

								# 如果昵称在列表里
								if nick in afklist:
									a=afklist[nick]

									# 不能重复挂机
									if text[:3]=="afk":
										send(f"@{nick} 已经在{a}了")

									else:
										# 把昵称从列表中移除
										send(random.choice([f"@{nick} 停止了{a}",f"@{nick} 现在没在{a}了"]))
										del afklist[nick]

								# 如果昵称不在列表里
								if nick not in afklist:
									if text[:3]=="afk":
										t3=text[3:]
										t4=text[4:]

										if t3.strip()=="":
											send(f"@{nick} 现在在离开键盘")
											afklist[nick]="离开键盘"

										elif text[3]==" ":
											send(f"@{nick} 现在在{t4}")
											afklist[nick]=t4

										# 退出真心话游戏
										if trueword==False and len(gamename)!=0 and nick in gameby:
											a=gameby.index(nick)
											time.sleep(ee)
											send(f"@{nick} 已离开真心话游戏")
											del gamedate[a]
											del gameby[a]

								if f"@{botname}" not in text:

									# 如果有人提到了挂机成员
									for name in afklist:

										# 提示该成员在afk状态
										if f"@{name}" in text:
											a=afklist[name]
											send(f"@{name} 现在在{a}")

								for i in fuck:
									if i.strip("\n") in text:
										send(random.choice(["咳咳","咳咳 这不河里","咳咳 这河里吗","咳咳 这不好吧","这样真的好吗（","好吧-核氢核锂"]))
										break

								using=False

					time.sleep(0.2)

		def main_send():

			# 一直循环
			while True:

				# 如果收到窥屏消息
				if transmit==True and "2" in tsmit:
					send(tsmit["2"])
					del tsmit["2"]

				else:
					time.sleep(0.2)

		ths = []

		# 开启多线程
		for func in [main_more,main_send]:
		    ths.append(Thread(target=func))
		    ths[-1].start()

		for th in ths:
			th.join()


	def send_message():

		'''
			优先级：sendms（手动）>using（使用）
		'''

		# 引用函数外变量
		global sendms,using

		# 如果允许手动发送消息
		if sendms==True:

			# 一直循环
			while True:
				try:
					aa=open("send_message.txt","r+")
					bb=aa.read()

					if bb!="":
						using=True

						if "O-" in bb[:2]:
							Thread(target=online_code,args=(bb[2:],username,'eeeeee',)).start()

						elif "/" in bb[0] or "^" in bb[0]:
							send(bb)

						else:
							send(f"[{username}] {bb}")

						aa.truncate(0)
						aa.close()

					else:
						aa.close()
						time.sleep(0.2)

				except:
					time.sleep(0.2)

		else:
			# 结束进程
			sys.exit(0)


	def heart_beat():
		while True:
			try:
				time.sleep(30)
				ws.send(json.dumps({'cmd':'ping'}))

				if transmit==True:
					wsss.send(json.dumps({'cmd':'ping'}))

			except:
				time.sleep(30)


	def time_line():

		'''
			优先级：timeline（时间线）>simplify（模式）>ad（广告）
		'''

		# 引用函数外变量
		global timeline,ad,simplify

		# 如果时间线通知打开
		if timeline==True:

			# 一直循环
			while True:	

				# 用来判断星期几
				dah=time.strftime("%H:%M",time.localtime())
				daw=time.strftime("%M",time.localtime())
				wek=datetime.date(int(time.strftime("%Y")),int(time.strftime("%m")),int(time.strftime("%d"))).weekday()

				if timeline==True and simplify==False:
					if wek<5:
						if dah in ["07:40","13:40"]:
							send(random.choice([f"{username}已经去上学啦",f"{username}现在已经在学校了"]))

						elif dah in ["11:40","18:20"]:
							send(random.choice([f"{username}正在回家的路上",f"{username}差不多快回家了"]))

					if dah=="23:00":
						send(random.choice(["已经11点了 在线的各位去睡觉吧","不能当夜猫子哦（doge"]))

					if wek==6:
						if dah in ["15:00","17:00"]:
							send(random.choice([f"@{username} 快去写作业！",f"@{username} 别忘了作业哦"]))

					if ad==True:
						if dah=="12:00":
							fp=open("[record]\\[random]\\paper.txt","r").readlines()
							pp=random.choice(fp).strip('\n')
							send(f"![]({pp})")

						if daw=="13":
							fp=open("[record]\\[random]\\trees.txt","r").readlines()
							rr=random.choice(fp).replace('\\n','\n')
							send(f"·\n{rr}")

					timeline=False

				else:
					time.sleep(60)
					timeline=True

		else:
			# 结束进程
			sys.exit(0)


	def second_main():

		'''
			优先级：peep（窥屏）>transmit（跨服）
		'''

		# 引用函数外变量
		global wsss,chatroom1,channel1,peep,transmit,invite

		# 如果窥屏开关打开
		if peep==True:

			try:
				# 连接聊天室
				wsss=websocket.WebSocket()
				wsss.connect(socket2)
				send(f"本聊天室已连通 [{chatroom2}｜{channel2}] ")

			except:
				# 结束进程
				send(f"无法连接至 [{chatroom2}｜{channel2}]")
				peep=False
				sys.exit(0)

			taken=str(random.randint(1,999))
			botname_taken=f"{botname}_{taken}"
			wsss.send(join_rese(channel2,botname_taken))
			wsss.send(json.dumps({'cmd':'changecolor','color':'202020'}))
			wsss.send(send_rese(f"本聊天室已连通 [{chatroom1}｜{channel1}]"))

			def second_peep():

				# 一直循环
				while True:

					# 保存文件的时间
					emit=time.strftime("%H:%M:%S",time.localtime())
					chat=time.strftime("%Y.%m.%d")
					write=open(f"[chats]\\[{chatroom2}]\\{chat}_{channel2}.txt","a+")

					try:
						# 接收到的json数据
						wssss=json.loads(wsss.recv())

					except:
						wssss=''
						time.sleep(1)

					if "cmd" in wssss:
						cmd=wssss["cmd"]

						if cmd=="warn":
							text=wssss["text"]

							if chatroom2==hc and invite==True and "not find user" in text:

								# 自动重启
								time.sleep(1)
								py=sys.executable
								os.execl(py,py,*sys.argv)

							if len(gamename)==0:
								if "too fast" in text:

									# 自动重启
									time.sleep(30)
									py=sys.executable
									os.execl(py,py,*sys.argv)

						if cmd=="onlineSet":
							for nick in wssss["users"]:
								n=nick["nick"]

								if "｜" not in n:
									online["2"][n]={}
									online["2"][n]["join"]="-"

									if "trip" in nick and nick["trip"]!=None and nick["trip"].strip()!='':
										online["2"][n]["trip"]=nick["trip"]

						elif cmd=="onlineAdd":
							nick=wssss["nick"]

							tiee=time.time()
							online["2"][nick]={}
							online["2"][nick]["join"]=tiee

							if "trip" in wss and wss["trip"].strip()!='':
								online["2"][nick]["trip"]=wss["trip"]

						elif cmd=="onlineRemove":
							nick=wssss["nick"]

							if nick in online["1"]:
								del online["1"][nick]

						elif cmd=="chat":
							nick=wssss["nick"]
							text=wssss["text"]
							ff=''

							if "trip" in wssss and wssss["trip"].strip()!='':
								trip=wssss["trip"]
								ff=f"[{trip}] {nick}\n{text}"

							else:
								ff=f"[None] {nick}\n{text}"

							try:
								write.write(f"[{emit}]\n{ff}\n\n")

							except:
								pass

							if transmit==True and nick!=botname_taken and f"{nick}\n" not in bot:
								tsmit["2"]=ff

							if chatroom2==hc and text.replace('@','').replace(' ','')==f"~kick{botname_taken}":
								invite=True
								nic=nicks2
								del nic[nic.index(botname_taken)]

								wsss.send(json.dumps({'cmd':'invite','nick':nic[0]}))

					time.sleep(0.2)

			def second_send():
				while True:

					# 如果是正常模式
					if simplify==False and transmit==True and "1" in tsmit:
						wsss.send(send_rese(tsmit["1"]))
						del tsmit["1"]

					else:
						time.sleep(0.2)

			ths = []

			# 开启多线程
			for func in [second_peep,second_send]:
			    ths.append(Thread(target=func))
			    ths[-1].start()

			for th in ths:
				th.join()

		else:
			# 结束进程
			sys.exit(0)


	ths = []

	# 开启多线程
	for func in [main_1,main_2,send_message,heart_beat,time_line,second_main]:
	    ths.append(Thread(target=func))
	    ths[-1].start()

	for th in ths:
	    th.join()
