import websocket
import requests
import json
import time
import random
import calendar
import _thread


def sendd(text):

	# text:发送的内容
	return json.dumps({"cmd":"chat","text":str(text)})
	

class runbox:
	def __init__(self,room,name,pas):

		# 包含了频道、bot名称、bot密码
		self.room = room
		self.name = name
		self.pas = pas

		self.ellen = 0

		# 记录join成员
		self.join = []

		# 写入短文本
		self.text = []

		# 推荐列表
		self.wuhu = []
		self.site = []

		# afk人员清单
		self.afk = []

		# 游戏数据及游戏成员
		self.game = []
		self.play = []
		self.by = []

		# 真心话开关
		self.true = False

		# 飞花令开关
		self.flower = False

		# 词语接龙开关
		self.word = False

		# 故事制造机开关
		self.story = False
	

	def handle(self,json_data):

		# 将对应的cmd类型和对应的函数结合
		self.data = json_data

		# 如果接受到了包含cmd的json数据
		if "cmd" in self.data:

			# 发送文本类型
			if self.data["cmd"] == "chat":
				self.chat()

			# 用户进入类型
			elif self.data["cmd"] == "onlineAdd":
				self.onlineadd()

			# 进入聊天时用户的列表
			elif self.data["cmd"] == "onlineSet":
				self.onlineset()


	def chat(self):

		# 简化列表
		el = self.ellen
		jo = self.join
		te = self.text
		wu = self.wuhu
		si = self.site
		pl = self.play
		ga = self.game
		af = self.afk
		by = self.by

		# 简化获取写法
		text = self.data["text"]
		nick = self.data["nick"]

		# 用于排除bot昵称
		bot = ["ebot","eebot","eeebot","eeeebot","eeeeebot"]

		# 随机等待时间
		zz = random.choice([0.15,0.2,0.25])
		ee = random.choice([0.45,0.5,0.55])

		# 随机表情
		qq = [":)",":(",":O",":o",":D","¬_¬","-_-","-.-","-︵-","—.—","—︵—","⌒-⌒","￣︶￣","￣⌒￣","￣ˇ￣","u.u","u_u","n_n","n.n"]
		pp = ["._.","。_。","。.。","。-。","°-°","°⌒°","°▽°","°O°","°︶°","°～°","°ˇ°","o.o","o︵o","O.O","OuO","O︵O","0.0","0u0","0︵0"]
		meme = random.choice(qq + pp)

		hi = random.choice(["hi","hello","hey","halo","yo","wuhu","yeah","yep","yes"])
		wel = ".\n·\n"
		whis = hi + " {}".format(nick)
		per = "/w {} ".format(nick) +  wel + "\n"

		# 保存聊天记录的文件名及路径
		chat = time.strftime("%Y.%m.%d ")
		room = self.room
		a = "chat/" + chat + room + ".txt"
		b = "chat/website.txt"

		# 按日期和频道写入消息和发送时间
		with open(a,"a+") as fp:
			hc = time.strftime("%H:%M:%S ",time.localtime())
			ms = hc + nick + "\n" + text + "\n\n"
			fp.write(ms)

		# 单独存放连接
		if nick not in ["bo_od"]:
			if "http" in text and nick not in bot:
				with open(b,"a+") as fp:
					ch = time.strftime("%Y.%m.%d %H:%M:%S ",time.localtime())
					sm = ch + nick + "\n" + text + "\n\n"
					fp.write(sm)


		# 当wu中的数据为10
		if len(wu) == 10:

			# 自动清空wu
			time.sleep(ee)
			ws.send(sendd("已自动清空推荐记录"))
			wu.clear()
	
		# 当si中的数据为10
		if len(si) == 10:

			# 自动清空si
			time.sleep(ee)
			ws.send(sendd("已自动清空随机记录"))
			si.clear()


		# 为防止刷屏而屏蔽bot昵称
		if nick not in bot:

			# 如果成员第一次打招呼
			if text in ["hi","hello","hey","halo"] and nick not in jo:
				a = "hi {}".format(nick)
				b = "hello {}".format(nick)
				c = "hey {}".format(nick)
				d = "halo {}".format(nick)

				# bot打招呼
				time.sleep(zz)
				ws.send(sendd(random.choice([a,b,c,d])))

				# 保存昵称到jo
				jo.append(nick)


			if text in ["功能","order"]:

				# bot功能全一览
				a = "随机：七濑胡桃, 每日必应/bing, 小姐姐/cutie, 阿鲁/aru, 涩图/acg, 头像/head, 音乐/music\n"
				b = "乘法表, 日历/cal, 农历/date, 表情/meme, 换色/color, 时间/time, 挂机/afk, 随机/r\n"
				c = "·\n其他：一言, 励志, 抽签, 笑话, 情话, 古诗词, 彩虹屁, 毒鸡汤, 今日曰, 猜字谜\n"
				d = "舔狗日记, 社会语录, 网易热评, 摸鱼日历, 今日世界, 历史上的今天\n"
				e = "·\n无聊专用：飞花令, 真心话, 词语接龙, 故事制造机\n"
				f = "推荐/wuhu, 树洞/tree, 趣站/site, 游戏/game, 网盘/pan, 聊天室/chat\n"
				g = "·\n基本：功能/order, 帮助/help, 重置/clear\n"
				h = "·\nping, icp, qq, 翻译/tran, 搜狗/sogo, 百度/baidu, 天气/city, 网易云/id\n"
				i = "·\n不会使用？试试在下面「聊天框」里发送上面的命令吧"

				# 将字符串起来发送
				time.sleep(zz)
				ws.send(sendd(per + a + b + c + d + e + f + g + h + i))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["帮助","help"]:

				# 关于hack.chat的说明
				a = "hc指令：https://tieba.baidu.com/p/6833224084\n"
				b = "hc百科：https://chumo.sbsbsb.sbs/wiki\n"
				c = "hc成员：https://tieba.baidu.com/p/7153686343\n"
				d = "hc同人作品集：https://note.ms/HCworks111\n"
				e = "·\n其他：\nhttps://zhuanlan.zhihu.com/p/108821519\n"
				f = "https://youquhome.com/5649/\nhttps://www.sweeterthandespair.com/hack-chat.html\n"
				g = "https://www.luoxiao123.cn/1554-6.html\nhttps://www.bilibili.com/read/cv2233284\n"
				h = "https://sspai.com/post/40667\nhttps://iao.su/1511/\n"
				i = "https://www.luogu.com.cn/blog/TMYOS/dui-yu-hackchat-di-yan-jiu\n"
				j = "https://zhuanlan.zhihu.com/p/111513602\n"
				k = "·\n这是部分有关hack.chat的链接 欢迎投稿"

				# 将字符串起来发送
				time.sleep(zz)
				ws.send(sendd(per + a + b + c + d + e + f + g + h + i + j + k))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["ping"]:

				# ping说明书
				a = "说明：PING某网站的域名\n·\n使用源：SuixinAPI\n使用方法：PING·域名（前面有个PING和点\n"
				time.sleep(zz)
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["icp"]:

				# 说明书
				a = "说明：查询ICP备案记录\n·\n使用源：零七生活API\n使用方法：ICP·域名（前面有个ICP和点\n"
				time.sleep(zz)
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["qq"]:

				# 说明书
				a = "说明：查询QQ号昵称\n·\n使用源：搏天API\n使用方法：QQ·QQ号（前面有个QQ和点\n"
				time.sleep(zz)
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["翻译","tran"]:

				# 翻译说明书
				a = "说明：在线翻译\n·\n使用源：网易有道翻译\n使用方法：F·要翻译的句子（前面有个F和点\n"
				time.sleep(zz)
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["搜狗","sogo"]:

				# 说明书
				a = "说明：查询搜狗百科\n·\n使用源：木小果API\n使用方法：SOGO·词条名称（前面有个SOGO和点\n"
				time.sleep(zz)
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["百度","baidu"]:

				# 翻译说明书
				a = "说明：查询百度百科\n·\n使用源：木小果API\n使用方法：BAIDU·词条名称（前面有个BAIDU和点\n"
				time.sleep(zz)
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["天气","city"]:

				# 说明书
				a = "说明：获取当天的天气信息\n·\n使用源：木小果API\n使用方法：CITY·不带市的城市名（前面有个CITY和点\n"
				time.sleep(zz)
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["网易云","id"]:

				# 说明书
				a = "说明：在线解析网易云音乐\n·\n使用源：零七生活API\n使用方法：ID·歌曲ID（前面有个ID和点\n"
				time.sleep(zz)
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["重置","clear"]:
				time.sleep(zz)

				# 如果wu和si中无数据
				if len(wu) == 0 and len(si) == 0:
					ws.send(sendd("当前无记录 不需要清空"))

				else:
					# 清空wu和si中的所有数据
					ws.send(sendd("已清空所有随机记录"))
					wu.clear()
					si.clear()


			if text in ["推荐","wuhu"]:

				# 来自hack.chat几位成员的推荐
				c1 = "「Gun Gale Online」\n类型：日本动漫 轻小说 日本漫画\n标签：游戏 战斗 反差萌"
				c2 = "「间谍教室」\n类型：轻小说 日本漫画\n标签：推理 欢乐向 斗智斗勇"
				c3 = "「不知我的死亡Flag将于何处停止」\n类型：日本漫画\n标签：转生 拆旗 事业流"
				c4 = "「杀戮天使」\n类型：游戏 日本动漫 轻小说 日本漫画\n标签：悬疑 治愈 靠谱"
				c5 = "「尸体派对」\n类型：游戏 日本动漫 日本漫画\n标签：恐怖 猎奇 前方高能"
				c6 = "「舞铲幼女与魔眼王」\n类型：轻小说 日本漫画\n标签：萝莉 冒险 携手战斗"
				c7 = "「绯红魔导书」\n类型：日本漫画\n标签：百合 战斗 黑暗风"
				c8 = "「幸色的一居室」\n类型：日剧 日本漫画\n标签：诱拐犯 爱情 治愈"
				c9 = "「来自深渊」\n类型：日本动漫 日本漫画\n标签：冒险 毛茸茸 黑暗风"
				c10 = "「最终休止符 -无止境的螺旋物语-」\n类型：游戏 日本动漫\n标签：冒险 萌系 欢乐向"
				c11 = "「婚约者恋上我的妹妹」\n类型：轻小说 日本漫画\n标签：致郁 轮回 爱而不得"
				c12 = "「老师温柔的杀人方法」\n类型：日本漫画\n标签：爱情 悬疑 杀人推理"
				c13 = "「最弱的驯养师开启的捡垃圾的旅途」\n类型：轻小说 日本漫画\n标签：萝莉 冒险 治愈"
				c14 = "「童话大逃杀」\n类型：日本漫画\n标签：冒险 童话风 黑暗风"
				c15 = "「大海原与大海原」\n类型：日本漫画\n标签：冒险 治愈"
				c15 = "「神不在的星期天」\n类型：日本动漫 轻小说 日本漫画\n标签：成长 冒险 治愈"
				c16 = "「纳尼亚传奇：魔法师的外甥」\n类型：名著 日本漫画\n标签：穿越 冒险 经典作品"
				c17 = "「中之人基因组」\n类型：日本动漫 日本漫画\n标签：冒险 多主角 实况中"
				c18 = "「喜欢的不是女儿，而是我吗！？」\n类型：轻小说 日本漫画\n标签：日常 年龄差 恋爱喜剧"
				c19 = "「从零开始的魔法书」\n类型：日本动漫 轻小说 日本漫画\n标签：兽人 冒险 美少女"
				c20 = "「落后的驯兽师慢生活」\n类型：轻小说 日本漫画\n标签：正太 游戏 种田"
				c21 = "「厄里斯的圣杯」\n类型：轻小说 日本漫画\n标签：推理 恶役 种田"
				c22 = "「葬送的芙莉莲」\n类型：日本漫画\n标签：冒险 魔法 感人泪下"
				c23 = "「转生成蜘蛛又怎样！」\n类型：日本动漫 轻小说 日本漫画\n标签：转生 蜘蛛子 双主线"
				c24 = "「最近，妹妹的样子有点怪？」\n类型：日剧 日本动漫 日本漫画\n标签：骨科 日常 恋爱喜剧"
				c25 = "「无能的奈奈」\n类型：日本动漫 日本漫画\n标签：悬疑 校园 斗智斗勇"
				c26 = "「灾祸的真理」\n类型：游戏 日本动漫 日本漫画\n标签：悬疑 战斗 剧情紧凑"
				c27 = "「LOST SONG」\n类型：日本动漫\n标签：治愈 冷门向 音乐作"
				c28 = "「败犬女主也太多了！」\n类型：轻小说\n标签：脑洞 败犬故事 恋爱喜剧"
				c29 = "「因为太怕痛就全点防御力了」\n类型：日本动漫 轻小说 日本漫画\n标签：游戏 冒险 凤傲天"
				c30 = "「罪恶王冠」\n类型：日本动漫\n标签：悬疑 战斗 幻想"
				c31 = "「来自多彩世界的明天」\n类型：日本动漫\n标签：成长 治愈 感人泪下"
				c32 = "「关于我转生变成史莱姆这档事」\n类型：游戏 日本动漫 轻小说\n标签：冒险 史莱姆 欢乐向"
				c33 = "「社会我鸡哥，人狠话不多」\n类型：日本漫画\n标签：战斗 主角鸡 核氢核锂"
				c34 = "「犬与屑」\n类型：日本漫画\n标签：悬疑 伦理 黑暗风"
				c35 = "「学园孤岛」\n类型：日本动漫 日本漫画\n标签：悬疑 治愈 擦眼泪"
				c36 = "「凹凸魔女的母女故事」\n类型：日本漫画\n标签：百合 日常 欢乐向"
				c37 = "「猪肝热热吃」\n类型：轻小说 日本漫画\n标签：主角猪 美少女 冒险"
				c38 = "「即使世界毁灭每一天依然快乐」\n类型：日本漫画\n标签：末世 治愈 毛茸茸"
				c39 = "「转生魔女宣告灭亡」\n类型：日本漫画\n标签：少女 爱情 魔法"
				c40 = "「骨龙的宝贝」\n类型：日本漫画\n标签：冒险 颜艺 养女儿"
				c41 = "「雾雨飘散之森」\n类型：游戏 日本漫画\n标签：悬疑 冒险 解谜游戏"
				c42 = "「女王陛下的异世界战略」\n类型：轻小说 日本漫画\n标签：虫族 战斗 猎奇"
				c43 = "「魔女之家：艾莲日记」\n类型：游戏 轻小说 日本漫画\n标签：恐怖 致郁 解谜游戏"
				c44 = "「恶魔的谜语」\n类型：日本动漫 日本漫画\n标签：百合 战斗 暗杀"
				c45 = "「魔女的心脏」\n类型：日本漫画\n标签：少女 治愈 旅行途中"
				c46 = "「魔法少女site」\n类型：日本动漫 日本漫画\n标签：百合 黑暗风 魔法少女"
				c47 = "「我推的孩子」\n类型：日本漫画\n标签：偶像 转生 误会系"
				c48 = "「转生成为魔剑」\n类型：轻小说 日本漫画\n标签：主角剑 养女儿 战斗"
				c49 = "「沉默的魔女」\n类型：轻小说\n标签：少女 推理 魔法"
				c50 = "「BNA」\n类型：日本动漫 轻小说\n标签：冒险 治愈 视觉系"
				c51 = "「约定的梦幻岛」\n类型：日本动漫 轻小说 日本漫画\n标签：悬疑 致郁 逃生"
				c52 = "「在魔王城说晚安」\n类型：日本动漫 日本漫画\n标签：治愈 萌系 欢乐向"
				c53 = "「奇诺之旅」\n类型：日本动漫 轻小说 日本漫画\n标签：旅行 冒险 引人深思"
				c54 = "「烧开水勇者的复仇记」\n类型：日本漫画\n标签：百合 复仇 携手战斗"
				c55 = "「恶魔战线」\n类型：日本动漫 日本漫画\n标签：爱情 悬疑 吸血鬼"
				c56 = "「该死的告白日」\n类型：韩国漫画\n标签：悬疑 感人 前方高能"
				c57 = "「开局一条鲲」\n类型：中国漫画\n标签：玄幻 冒险 双女主"
				c58 = "「花非花」\n类型：中国漫画\n标签：帝王 养成 古风"
				c59 = "「血族Bloodline」\n类型：游戏 中国漫画\n标签：年代 战斗 吸血鬼"
				c60 = "「血族维他命」\n类型：中国漫画\n标签：年代 恋爱 吸血鬼"
				w1 = "「宿命回响」\n类型：游戏 日本动漫\n标签：剧情 音乐 奇幻\n地址：https://movie.douban.com/subject/35417875"
				w2 = "「我要成为双马尾」\n类型：日本动漫 轻小说\n标签：剧情 性转 美少女\n地址：https://movie.douban.com/subject/25793397"
				w3 = "「巨龙山谷」\n剧情：意识流\n建模：堪称「极致美学」\n备注：千万别看，你会猝死。啊啊啊，我要犭"
				w4 = "「刺客信条：王朝」\n类型：游戏 中国漫画\n标签：冒险 历史 武侠\n推荐：L"
				j1 = "\n地址：https://movie.douban.com/subject/35296324"
				j2 = "\n·\n你看看，我看看\n大家一起去阴间\n白内障，脑血栓\n全都给我得一遍\n草起来了，蚌埠住了\n你来看，我来看\n阴间的路会变短"
				j3 = "\n编曲：蜜雪冰城\n推荐/填词：ww"

				# 随机选取
				time.sleep(zz)
				aa = random.choice([c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20])
				bb = random.choice([c21,c22,c23,c24,c25,c26,c27,c28,c29,c30,c31,c32,c33,c34,c35,c36,c37,c38,c39,c40])
				cc = random.choice([c41,c42,c43,c44,c45,c46,c47,c48,c49,c50,c51,c52,c53,c54,c55,c56,c57,c58,c59,c60])
				c = random.choice([aa,bb,cc]) + "\n推荐：ee"
				w = random.choice([w1+"\n推荐：ww",w2+"\n推荐：ww",w3+j1+j2+j3,w4])
				wuhu = random.choice([c,w])

				# wuhu中的内容全在wu的情况下
				if c in wu and w in wu:
					ws.send(sendd("{}中奖了 再来一次".format(nick)))
	
				# 只有c在wu的情况下
				elif c in wu:
					ws.send(sendd(per + w))
					wu.append(w)
					time.sleep(zz)
					ws.send(sendd(whis))
	
				# 只有w在wu的情况下
				elif w in wu:
					ws.send(sendd(per + c))
					wu.append(c)
					time.sleep(zz)
					ws.send(sendd(whis))
	
				else:
					# 随机wuhu
					ws.send(sendd(per + wuhu))
					wu.append(wuhu)
					time.sleep(zz)
					ws.send(sendd(whis))


			# hack.chat成员的友情链接
			if text in ["树洞","tree"]:
				f0 = random.choice(["13和ee的轻小说屋 old\nhttps://lidualhistory.mysxl.cn","JSH的主页\nhttp://imoier.xyz/"])
				f1 = random.choice(["flaugh的个人博客\nhttps://xsdboke.mysxl.cn","Sprinkle博客\nhttps://pntang.github.io"])
				f2 = random.choice(["智障初墨的个人主页\nhttps://chumo.sbsbsb.sbs","贤者13的树洞\nhttps://sage-thirteen.mysxl.cn"])
				f3 = random.choice(["Bird's Page\nhttps://fuckbird.sbsbsb.sbs","Beluga's YouTube\nhttps://youtube.com/c/Beluga1"])
				f4 = random.choice(["MuRongPIG's GitHub\nhttps://github.com/MuRongPIG","朽木自雕\nhttp://blog.noxx.cn"])
				f5 = random.choice(["纸片君ee的个人主页\nhttps://paperee.tk","13和ee的小说屋 new\nhttps://novelhouse.mysxl.cn"])

				# 随机选取
				time.sleep(zz)
				f = random.choice([f0,f1,f2,f3,f4,f5])

				# f的内容在si的情况下
				if f in si:
					ws.send(sendd("此链接被eebot吃了"))
				
				else:
					# 直接发送f
					ws.send(sendd(per + f))
					si.append(f)
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["趣站","site"]:

				# 好玩的网站
				s0 = random.choice(["ISS Docking Simulator\nhttps://iss-sim.spacex.com","STROBE\nhttps://strobe.cool"])
				s1 = random.choice(["Form Follows Function\nhttp://fff.cmiscm.com","In Pieces\nhttp://species-in-pieces.com"])
				s2 = random.choice(["Chrome Music Lab\nhttps://musiclab.chromeexperiments.com/Song-Maker","Calm\nhttps://calm.ovh"])
				s3 = random.choice(["Staggering Beauty\nhttp://www.staggeringbeauty.com","Mikutap\nhttps://aidn.jp/mikutap"])
				s4 = random.choice(["Koalas to the Max dot Com\nhttp://koalastothemax.com","OREOOO\nhttp://ljl.li/oreooo"])
				s5 = random.choice(["即刻到账\nhttps://saythemoney.github.io","Microsculpture\nhttp://microsculpture.net"])
				s6 = random.choice(["我爱工作\nhttps://ilove.works","卡巴斯基网络威胁实时地图\nhttps://cybermap.kaspersky.com/cn"])
				s7 = random.choice(["Yoichi Kobayashi\nhttps://www.tplh.net","跳跃的小球\nhttp://guozhivip.com/fun"])
				s8 = random.choice(["今天吃啥呀\nhttp://guozhivip.com/eat","便携小空调\nhttps://ac.yunyoujun.cn"])
				s9 = random.choice(["The Zen Zone\nhttps://thezen.zone","网页小游戏列表\nhttps://xingye.me/game"])
				s10 = random.choice(["Bruno Simon\nhttps://bruno-simon.com","Coding Cat\nhttps://hostrider.com"])
				s11 = random.choice(["架子鼓\nhttp://guozhivip.com/jzg","Nomadic Tribe\nhttps://2019.makemepulse.com"])
				s12 = random.choice(["The Blocks\nhttps://blocks.ovh","Sequencer64\nhttps://www.sequencer64.com"])
				s13 = random.choice(["Bubble wrap pop\nhttps://bubblespop.netlify.app","Sharkle\nhttps://sharkle.com"])
				s14 = random.choice(["Kick Ass\nhttps://kickassapp.com","Patatap\nhttps://www.patatap.com"])
				s15 = random.choice(["星弈小游戏平台\nhttp://other.noxx.cn/play","全景故宫\nhttps://pano.dpm.org.cn"])
				s16 = random.choice(["土味情话 在线生成\nhttps://works.yangerxiao.com/honeyed-words-generator/"])

				# 随机选取
				time.sleep(zz)
				s = random.choice([s0,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16])

				# s的内容在si的情况下
				if s in si:
					ws.send(sendd("不给不给 不给{}".format(nick)))
	
				else:
					# 直接发送s
					ws.send(sendd(per + s))
					si.append(s)
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["游戏","game"]:

				# 部分网页游戏
				g0 = random.choice(["Phigros\nhttps://pgr.han-han.xyz/tapToStart","defly\nhttps://defly.io"])
				g1 = random.choice(["和焦虑一起冒险\nhttps://z-lyen.github.io/anxiety","RICHUP\nhttps://richup.io"])
				g2 = random.choice(["Red Carpet Rampage\nhttps://rcr.heheda.top","Raaaaft\nhttps://raaaaft.io"])
				g3 = random.choice(["名字竞技场\nhttp://namerena.github.io","Nazo Game\nhttps://nazo.one-story.cn"])
				g4 = random.choice(["HTML5 杯\nhttp://html5cup.kayac.com","株式会社 闇\nhttps://death.co.jp/ja/pc"])
				g5 = random.choice(["Line Rider\nhttps://www.linerider.com","Dino Swords\nhttps://dinoswords.gg"])
				g6 = random.choice(["信任的进化\nhttps://dccxi.com/trust","2020 Game\nhttps://2020game.io"])
				g7 = random.choice(["Minecraft Classic\nhttps://classic.minecraft.net","Gartic\nhttps://gartic.io"])
				g8 = random.choice(["YORG\nhttps://yorg.io","我们变成了我们所看到的\nhttps://claycoffee.github.io/wbwwb"])
				g9 = random.choice(["西游梗传\nhttp://littlegame.tomato123.cn/xiyou","太鼓ウェブ\nhttps://taiko.bui.pm"])
				g10 = random.choice(["florr\nhttps://florr.io","人生重开模拟器\nhttp://liferestart.syaro.io/public"])
				g11 = random.choice(["Taming\nhttps://taming.io","ふぁんしーあいらんど\nhttp://lomando.com/main.html"])
				g12 = random.choice(["Manyland\nhttp://manyland.com","Undercards\nhttps://undercards.net/Quests"])
				g13 = random.choice(["Minecraft 网页版\nhttps://craft.spr233.eu.org/"])

				# 随机选取
				time.sleep(zz)
				g = random.choice([g0,g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12,g13])

				# g的内容在si的情况下
				if g in si:
					ws.send(sendd("哼 不可以贪心哦"))
	
				else:
					# 直接发送g
					ws.send(sendd(per + g))
					si.append(g)
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["网盘","pan"]:

				# 民间的冷门网盘
				p0 = random.choice(["勿待炬火网盘\nhttps://pan.weunite.top","樱忆云盘\nhttps://drive.loili.com"])
				p1 = random.choice(["雨滴云盘\nhttp://pan.handanxiaochipeixun.top:5212","AcgngameCloud\nhttps://acgngame.cloud"])
				p2 = random.choice(["Cloudreve\nhttps://cloudreve.zjh336.cn","爱丽丝的记事本\nhttps://drive.noire.cc"])
				p3 = random.choice(["小太阳云存储\nhttps://cncncloud.com","比邻云盘\nhttps://pan.bilnn.cn"])
				p4 = random.choice(["萌云\nhttps://moecloud.cn","AnonFiles\nhttps://anonfiles.com"])
				p5 = random.choice(["文叔叔\nhttps://www.wenshushu.cn","TMP.link\nhttps://app.tmp.link"])

				# 随机选取
				time.sleep(zz)
				p = random.choice([p0,p1,p2,p3,p4,p5])

				# p的内容在si的情况下
				if p in si:
					ws.send(sendd("{}再试一次呗".format(nick)))
	
				else:
					# 直接发送p
					ws.send(sendd(per + p))
					si.append(p)
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["聊天室","chat"]:

				# 网路聊天室
				h0 = random.choice(["hack.chat\nhttps://hack.chat","小蝌蚪互动聊天室\nhttp://zzzgd.info/kedou"])
				h1 = random.choice(["BBBUG 聊天室\nhttp://chat.zzzgd.info","星弈微聊\nhttps://im.noxx.cn"])
				h2 = random.choice(["蔷薇花园\nhttps://iirose.com","爱聊友\nhttps://im.ailyoo.com"])
				h3 = random.choice(["网页聊天\nhttps://wylt.com/r/XianLiao","十字街\nhttps://crosst.chat"])
				h4 = random.choice(["DOLLARS 聊天室\nhttps://drrr.com","hichat\nhttp://hichat.herokuapp.com"])
				h5 = random.choice(["BBBUG 音乐聊天室\nhttps://bbbug.com","多人听歌网\nhttps://chat.zhuolin.wang"])
				h6 = random.choice(["在线聊天\nhttps://chat.anonshacker.com/Mars","聊乎\nhttps://www.randomchat.cn"])
				h7 = random.choice(["匿名聊天室\nhttps://easonchiang7178.github.io/f2e-anonymous-chatroom"])
				h8 = random.choice(["啊噗聊天\nhttps://www.uplt.com","fiora\nhttps://fiora.suisuijiang.com"])
				h9 = random.choice(["叔叔不约\nhttp://www.shushubuyue.com","Deskry\nhttp://v6.nm1v1.cn"])
				h10 = random.choice(["Liveany\nhttps://www.liveany.com/web.html","CamSurf\nhttps://camsurf.com"])
				h11 = random.choice(["WooTalk\nhttps://wootalk.today","陌路人\nhttp://www.moluren.net"])
				h12 = random.choice(["Anonymous\nhttps://chat42.online","MeeTunnel\nhttps://www.meetunnel.com/chat"])
				h13 = random.choice(["CHINWS CHAT\nhttps://chat.chinws.com/1","TALK2\nhttps://talk2.fun"])

				# 随机选取
				time.sleep(zz)
				h = random.choice([h0,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13])

				# h的内容在si的情况下
				if h in si:
					ws.send(sendd("耶 eebot不告诉{}".format(nick)))

	
				else:
					# 直接发送h
					ws.send(sendd(per + h))
					si.append(h)
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["一言"]:

				# api:Hitokoto
				api = "https://v1.hitokoto.cn"
				se = requests.get(api)
				res = se.json()
				word = res["from"] + " " + res["creator"] + "\n「" + res["hitokoto"] + "」"

				# api:韩小韩API
				apii = "https://api.vvhan.com/api/ian"
				see = requests.get(apii)
				ress = see.text

				# 随机选取
				b = random.choice([word,ress])

				# 如果双引号存在就替换
				if "“" in b or "”" in b:
					ws.send(sendd(per + b.replace('“','「').replace('”','」')))
					time.sleep(zz)
					ws.send(sendd(whis))

				# 如果b内容是ress
				elif b == ress:
					ws.send(sendd(per + "「" + b + "」"))
					time.sleep(zz)
					ws.send(sendd(whis))

				else:
					# 以上两种情况皆无
					ws.send(sendd(per + b))
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["励志"]:

				# api:SuixinAPI
				api = "http://api.botwl.cn/api/yhyl"
				se = requests.get(api)
				res = "「" + se.text + "」"
				ws.send(sendd(per + res))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["抽签"]:
				
				# api:SuixinAPI
				api = "http://api.botwl.cn/api/qiuqian"
				se = requests.get(api)
				res = se.text.replace('[\\n]','\n')
				ws.send(sendd(per + res))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["笑话"]:
				
				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/xiaohua?api_key=c2b3c8ef3925db80"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = "【" + a["title"] + "】\n" + a["content"]

				# api:韩小韩API
				apii = "https://api.vvhan.com/api/xh"
				see = requests.get(apii)
				ress = see.text

				# 随机选取
				b = random.choice([word,ress])

				# 如果双引号存在就替换
				if "“" in b or "”" in b:
					ws.send(sendd(per + b.replace('“','\n「').replace('”','」\n')))
					time.sleep(zz)
					ws.send(sendd(whis))

				# 如果括号不在b中
				elif "【" not in b or "】" not in b:
					ws.send(sendd(per + "「" + b + "」"))
					time.sleep(zz)
					ws.send(sendd(whis))

				else:
					# 以上两种情况皆无
					ws.send(sendd(per + b))
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["情话"]:

				# api:沙雕APP
				api = "https://api.lovelive.tools/api/SweetNothings/count/Serialization/serializationType"
				se = requests.get(api)
				res = se.json()
				word = res["returnObj"]
				a = random.choice(word)

				# api:UomgAPI
				apii = "https://api.uomg.com/api/rand.qinghua"
				see = requests.get(apii)
				ress = see.json()
				wordd = ress["content"]

				# api:韩小韩API
				apiii = random.choice(["https://api.vvhan.com/api/love","https://api.vvhan.com/api/sao"])
				seee = requests.get(apiii)
				resss = seee.text
				
				# 随机选取
				b = random.choice([a,wordd,resss])

				# 如果双引号存在就替换
				if "“" in b or "”" in b:
					ws.send(sendd(per + b.replace('“','「').replace('”','」')))
					time.sleep(zz)
					ws.send(sendd(whis))

				else:
					# 以上两种情况皆无
					ws.send(sendd(per + "「" + b + "」"))
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["古诗词"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/Gushici?api_key=1469d017a08f2827"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = a["title"] + " " + a["author"] + "\n「" + a["min_content"] + "」"
				ws.send(sendd(per + word))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["彩虹屁"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/caihongpi?api_key=4acee95f422ea04a"
				se = requests.get(api)
				res = se.json()
				b = res["data"]["comment"]

				# 如果双引号存在就替换
				if "“" in b or "”" in b:
					ws.send(sendd(per + b.replace('“','「').replace('”','」')))
					time.sleep(zz)
					ws.send(sendd(whis))

				else:
					# 在两边加上括号
					ws.send(sendd(per + "「" + b + "」"))
					time.sleep(zz)
					ws.send(sendd(whis))


			if text in ["毒鸡汤"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/dujitang?api_key=e5103c1917bc4026"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = a["comment"]

				# api:搏天api
				apii = "http://api.btstu.cn/yan/api.php"
				see = requests.get(apii)
				ress = see.text
				
				# 随机选取并发送
				b = random.choice([word,ress])
				ws.send(sendd(per + "「" + b + "」"))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["今日曰"]:

				# api:韩小韩API
				api = "https://api.vvhan.com/api/en"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				b = "Today Is " + a["month"] + " " + a["day"]
				word = b + "\n「" + a["zh"] + "」" + "\n「" + a["en"] + "」"
				ws.send(sendd(per + word))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["猜字谜"]:
				
				# api:SuixinAPI
				api = "http://api.botwl.cn/api/miyu"
				se = requests.get(api)
				res = se.text
				ws.send(sendd(per + res.replace(' ','\n')))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["舔狗日记"]:

				# api:小歪API
				api = "https://api.ixiaowai.cn/tgrj/index.php"
				se = requests.get(api)
				res = "「" + se.text + "」"

				# api:木小果API
				apii = "https://api.muxiaoguo.cn/api/tiangourj?api_key=300ec8fe32c3562a"
				see = requests.get(apii)
				ress = see.json()
				a = ress["data"]
				word = "「" + a["comment"] + "」"

				# 仅为恶搞
				ee = "202x年xx月xx日 广东 汕头 " + self.name + "\n"
				
				# 随机选取并发送
				b = random.choice([res,word])
				ws.send(sendd(per + ee + b.replace('*','').replace('“','『').replace('”','』')))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["社会语录"]:

				# api:零七生活API
				api = "https://api.oick.cn/yulu/api.php"
				se = requests.get(api)
				res = se.text.replace('\"','')
				word = "「" + res + "」"
				ws.send(sendd(per + word))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["网易热评"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/163reping?api_key=5d60829ddff7ea03"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = "来自 " + a["nickname"] + a["songName"] + "\n「" + a["content"] + "」"
				ws.send(sendd(per + word))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["摸鱼日历"]:

				# api:韩小韩API
				api = "https://api.vvhan.com/api/moyu"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + res))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["今日世界"]:

				# api:韩小韩API
				ws.send(sendd(per + "https://api.vvhan.com/api/60s"))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["历史上的今天"]:

				# api:公共api
				api = "https://qqlykm.cn/api/lishi/index.php"
				se = requests.get(api)
				res = "【" + se.text + "】"
				ws.send(sendd(per + res))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["七濑胡桃"]:

				# api:小歪API
				api = "https://api.ixiaowai.cn/mcapi/mcapi.php"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + res))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["每日必应","bing"]:

				# api:保罗API
				api = "https://api.paugram.com/bing/?info"
				se = requests.get(api)
				res = se.json()
				a = res["link"] + "\n" + res["copyright"]
				ws.send(sendd(per + a))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["小姐姐","cutie"]:

				# api:夏沫博客 SuixinAPI
				api = random.choice(["https://cdn.seovx.com/ha/?mom=302","http://api.botwl.cn/api/meinvtu?n=1"])
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + res))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["阿鲁","aru"]:

				# api:姬长信API
				api = "https://api.isoyu.com/ARU_GIF_S.php"
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + res))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["涩图","acg"]:

				# api:晓晴博客 樱花 MuRongPIG自建
				api = random.choice(["https://acg.toubiec.cn/random.php","https://www.dmoe.cc/random.php","https://cdn.mrpig.cf/"])
				se = requests.get(api)
				res = se.url
				ws.send(sendd(per + res))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["头像","head"]:

				# api:搏天api
				api = "http://api.btstu.cn/sjtx/api.php"
				se = requests.get(api)
				res = se.url

				# api:木小果API
				apii = "https://api.muxiaoguo.cn/api/sjtx?method=pc?api_key=cc4fc89ad2b8d20c"
				see = requests.get(apii)
				ress = see.json()
				a = ress["data"]
				word = a["imgurl"]
				
				# 随机选取并发送
				ws.send(sendd(per + random.choice([res,word])))
				time.sleep(zz)
				ws.send(sendd(whis))
	

			if text in ["音乐","music"]:
				
				# 保罗API
				api = "https://api.paugram.com/acgm"
				se = requests.get(api)
				res = se.json()
				word = res["title"] + " " + res["artist"] + " \n" + res["link"]
				ws.send(sendd(per + word))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["日历","cal"]:

				# 日历模块调用calendar库
				a = int(time.strftime("%Y"))
				b = int(time.strftime("%m"))
				cal = calendar.month(a, b).replace(' ','⠀').replace('⠀⠀',' ⠀')
				ws.send(sendd("⠀" + cal))


			if text in ["农历","date"]:

				# api:木小果API
				api = "https://api.muxiaoguo.cn/api/yinlongli?api_key=dd488292c6ea462a"
				se = requests.get(api)
				res = se.json()
				a = res["data"]
				word = "日：" + a["lunar"] + "\n年：" + a["yearZodiac"] + "（" + a["lunarYearName"] + "）\n·\n节气：" + a["solarTerms"]
				ws.send(sendd(per + word))
				time.sleep(zz)
				ws.send(sendd(whis))


			if text in ["表情","meme"]:

				# 表情参见设定部分
				ws.send(sendd(meme))


			if text in ["换色","color"]:

				# api:SuixinAPI 韩小韩API
				api = random.choice(["http://api.botwl.cn/api/sjys","https://api.vvhan.com/api/color"])
				se = requests.get(api)
				a = "/color " + se.text

				# 更换bot的颜色
				ws.send(sendd(a))

				# 发送后重新换回44FF00
				ws.send(sendd("This Color: " + se.text + "\nOld Color: #44FF00"))
				ws.send(sendd("/color 44FF00"))


			if text in ["时间","time"]:

				# 获取计算机时间
				a = time.strftime("Time %a %Y.%m.%d %H:%M:%S",time.localtime())
				ws.send(sendd(a))


			if text in ["乘法表"]:
				a = "1x1=1\n"
				b = "1x2=2 2x2=4\n"
				c = "1x3=3 2x3=6 3x3=9\n"
				d = "1x4=4 2x4=8 3x4=12 4x4=16\n"
				e = "1x5=5 2x5=10 3x5=15 4x5=20	5x5=25\n"
				f = "1x6=6 2x6=12 3x6=18 4x6=24	5x6=30 6x6=36\n"
				g = "1x7=7 2x7=14 3x7=21 4x7=28	5x7=35 6x7=42 7x7=49\n"
				h = "1x8=8 2x8=16 3x8=24 4x8=32	5x8=40 6x8=48 7x8=56 8x8=64\n"
				i = "1x9=9 2x9=18 3x9=27 4x9=36	5x9=45 6x9=54 7x9=63 8x9=72 9x9=81\n"

				time.sleep(zz)
				ws.send(sendd(per + a + b + c + d + e + f + g + h + i))
				time.sleep(zz)
				ws.send(sendd(whis))


			# 如果昵称在af列表里
			if nick in af:

				# 排除以下消息
				if text not in ["挂机","afk","挂机列表","list"]:

					# 把昵称从af中移除
					a = "welcome back {}".format(nick)
					b = "{} is back".format(nick)
					time.sleep(zz)
					ws.send(sendd(random.choice([a,b])))
					del af[af.index(nick)]

				# 不能重复挂机
				elif text in ["挂机","afk"]:
					time.sleep(zz)
					ws.send(sendd("{} is already in afk list".format(nick)))


			# 如果昵称不在af列表里
			if nick not in af:

				# 将昵称加入af
				if text in ["挂机","afk"]:
					time.sleep(zz)
					ws.send(sendd("{} is now afk".format(nick)))
					af.append(nick)

					# 退出真心话游戏
					if self.true == True and nick in by:
						time.sleep(ee)
						ws.send(sendd("{}已离开真心话游戏".format(nick)))
						del by[by.index(nick)]


			# 查看af列表
			if text in ["挂机列表","list"]:

				# 若af的长度为0
				if len(af) == 0:
					time.sleep(zz)
					ws.send(sendd("目前无人挂机 列表为空"))

				else:
					# 输出列表
					a = "·\nafk list:" + str(af).replace('[\'','').replace('\']','').replace('\'',' ')
					time.sleep(zz)
					ws.send(sendd(a))
	

			# 如果有人提到了挂机成员
			for name in af:

				# 提示该成员在afk状态
				if "{}".format(name) in text:
					time.sleep(zz)
					ws.send(sendd("{} is now afk".format(name)))


			if "PING·" in text and text[4] == "·":

				# api:SuixinAPI
				url = "http://api.botwl.cn/api/ping"

				if text[5] == "·":
					data = {"url":text[6:]}
					se = requests.get(url,data)
					res = se.json()

					# 如果状态码为1
					if res["code"] == 1:
						a = res["host"] + "（" + res["ip"] + "）"
						b = "\n·\n最快用时：" + res["ping_time_min"] + "\n最慢用时：" + res["ping_time_max"]
						ws.send(sendd(per + a + b.replace(' ','')))
						time.sleep(zz)
						ws.send(sendd("请求成功"))

					else:
						# 若不是则视为失败
						ws.send(sendd("获取失败 请检查域名"))

				else:
					data = {"url":text[5:]}
					se = requests.get(url,data)
					res = se.json()

					# 如果状态码为1
					if res["code"] == 1:
						a = "·\n" + res["host"] + "（" + res["ip"] + "）"
						b = "\n·\n最快用时：" + res["ping_time_min"] + "\n最慢用时：" + res["ping_time_max"]
						ws.send(sendd(a + b.replace(' ','')))

					else:
						# 若不是则视为失败
						ws.send(sendd("获取失败 请检查域名"))


			if "ICP·" in text and text[3] == "·":

				# api:零七生活API
				url = "https://api.oick.cn/icp/api.php"

				if text[4] == "·":
					data = {"url":text[4:]}
					se = requests.get(url,data)
					res = se.json()
					
					if res["code"] == 200:
						a = res["site_index"] + "（" + res["site_name"] + "）"
						b = "\n·\n单位：" + res["name"] + "\n类型：" + res["nature"]
						c = "\n·\n备案信息：" + res["icp"] + "\n备案时间：" + res["site_time"]
						ws.send(sendd(per + a + b + c))
						time.sleep(zz)
						ws.send(sendd("请求成功"))

					# 如果状态码为201
					elif res["code"] == 201:
						ws.send(sendd("未有此域名ICP备案记录"))

					else:
						# 若不是则视为失败
						ws.send(sendd("获取失败 请检查域名"))

				else:
					data = {"url":text[3:]}
					se = requests.get(url,data)
					res = se.json()

					if res["code"] == 200:
						a = "·\n" + res["site_index"] + "（" + res["site_name"] + "）"
						b = "\n·\n单位：" + res["name"] + "\n类型：" + res["nature"]
						c = "\n·\n备案信息：" + res["icp"] + "\n备案时间：" + res["site_time"]
						ws.send(sendd(a + b + c))

					# 如果状态码为201
					elif res["code"] == 201:
						ws.send(sendd("未有此域名ICP备案记录"))

					else:
						# 若不是则视为失败
						ws.send(sendd("获取失败 请检查域名"))


			if "QQ·" in text and text[2] == "·":

				# api:搏天api
				url = "http://api.btstu.cn/qqxt/api.php"

				if text[3] == "·":
					data = {"qq":text[4:]}
					se = requests.get(url,data)
					res = se.json()

					if res["code"] == 1 and res["name"] != "":
						a = res["name"] + "\n" + text[4:]
						ws.send(sendd(per + a))
						time.sleep(zz)
						ws.send(sendd("请求成功"))

					else:
						# 若不是则视为失败
						ws.send(sendd("查询失败 请检查QQ号"))

				else:
					data = {"qq":text[3:]}
					se = requests.get(url,data)
					res = se.json()

					if res["code"] == 1 and res["name"] != "":
						a = "·\n" + res["name"] + "\n" + text[3:]
						ws.send(sendd(a))

					else:
						# 若不是则视为失败
						ws.send(sendd("查询失败 请检查QQ号"))


			if "F·" in text and text[1] == "·":

				# api:网易有道翻译
				url = "http://fanyi.youdao.com/translate"
				head = {"User-Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0"}

				if len(text) > 102:
					ws.send(sendd("超出最大字符数100"))

				else:
					if text[2] == "·":
						data = {"doctype":"json","type":"AUTO","i":text[3:]}
						se = requests.get(url,params = data,headers = head,timeout = 10)
						res = se.json()

						# 如果状态码为0
						if res["errorCode"] == 0:
							a = res["translateResult"][0][0]["tgt"]
							ws.send(sendd(per + "翻译结果：\n" + a.lower()))
							time.sleep(zz)
							ws.send(sendd("请求成功"))

						else:
							# 若不是则视为失败
							ws.send(sendd("翻译请求失败"))

					else:
						data = {"doctype":"json","type":"AUTO","i":text[2:]}
						se = requests.get(url,params = data,headers = head,timeout = 10)
						res = se.json()

						# 如果状态码为0
						if res["errorCode"] == 0:
							a = res["translateResult"][0][0]["tgt"]
							ws.send(sendd("{} said: ".format(nick) + a.lower()))

						else:
							# 若不是则视为失败
							ws.send(sendd("翻译请求失败"))


			if "SOGO·" in text and text[4] == "·":

				# api:木小果API
				url = "https://api.muxiaoguo.cn/api/Baike"

				if text[5] == "·":
					data = {"type":"Sogo","word":text[6:],"api_key":"cb28182953ac4557"}
					se = requests.get(url,data)
					res = se.json()
					a = res["data"]
					if res["code"] == 200:
						b = "查询：" + text[6:] + "\n·\n搜狗：" + a["content"]
						c = b.replace('。','。\n').replace('(','（').replace(')','）').replace('“','「').replace('”','」')
						ws.send(sendd(per + c))
						time.sleep(zz)
						ws.send(sendd("请求成功"))

					else:
						# 若不是则视为失败
						ws.send(sendd("查询失败 无此百科"))

				else:
					data = {"type":"Sogo","word":text[5:],"api_key":"cb28182953ac4557"}
					se = requests.get(url,data)
					res = se.json()
					a = res["data"]
					if res["code"] == 200:
						b = "·\n查询：" + text[5:] + "\n·\n搜狗：" + a["content"]
						c = b.replace('。','。\n').replace('(','（').replace(')','）').replace('“','「').replace('”','」')
						ws.send(sendd(c))

					else:
						# 若不是则视为失败
						ws.send(sendd("查询失败 无此百科"))


			if "BAIDU·" in text and text[5] == "·":

				# api:木小果API
				url = "https://api.muxiaoguo.cn/api/Baike"

				if text[5] == "·":
					data = {"type":"Baidu","word":text[5:],"api_key":"cb28182953ac4557"}
					se = requests.get(url,data)
					res = se.json()
					a = res["data"]
					if res["code"] == 200:
						b = "查询：" + text[6:] + "\n·\n百度：" + a["content"]
						c = b.replace('。','。\n').replace('"','').replace('(','（').replace(')','）').replace('“','「').replace('”','」')
						ws.send(sendd(per + c))
						time.sleep(zz)
						ws.send(sendd("请求成功"))

					else:
						# 若不是则视为失败
						ws.send(sendd("查询失败 无此百科"))

				else:
					data = {"type":"Baidu","word":text[6:],"api_key":"cb28182953ac4557"}
					se = requests.get(url,data)
					res = se.json()
					a = res["data"]
					if res["code"] == 200:
						b = "·\n查询：" + text[5:] + "\n·\n百度：" + a["content"]
						c = b.replace('。','。\n').replace('"','').replace('(','（').replace(')','）').replace('“','「').replace('”','」')
						ws.send(sendd(c))

					else:
						# 若不是则视为失败
						ws.send(sendd("查询失败 无此百科"))


			if "CITY·" in text and text[4] == "·":

				# api:木小果API
				url = "https://api.muxiaoguo.cn/api/tianqi"
				data = {"city":text[5:],"type":1,"api_key":"9410e360a940cb5e"}
				se = requests.get(url,data)
				res = se.json()
				a = res["data"]
				if res["code"] == 200:
					b = "·\n城市：" + text[5:] + "（" + a["weather"] + "）\n温度：" + a["temp"] + "°C\n湿度：" + a["SD"]
					c = "\n·\n风向：" + a["WD"] + "\n风级：" + a["WS"] + "\n风速：" + a["wse"]
					d = "\n·\n更新时间：" +  a["time"]
					ws.send(sendd(b + c + d))

				else:
					# 若不是则视为失败
					ws.send(sendd("查询失败 请检查城市"))


			if "ID·" in text and text[2] == "·":

				# api:零七生活API
				url = "https://api.oick.cn/wyy/api.php"
				data = {"id":text[3:]}
				se = requests.get(url,data)
				res = se.url
				if "https://music.163.com/404" == res:
					ws.send(sendd("网易云id获取失败 请检查"))

				else:
					ws.send(sendd(res))


			# 如果text的长度小于指定的值
			if len(text) < 10 and "·" not in text:

				# 未有游戏进行
				if len(ga) == 0:

					# 将字符数<12的话写入te
					time.sleep(zz)
					te.append(text)

					# te长度为10时bot复读一句话
					if len(te) == 10:
						ws.send(sendd(text))

					# te长度为20时bot随机输出te内容
					if len(te) == 20:

						# 发送并清空te列表
						t = random.choice(te)
						ws.send(sendd(t))
						te.clear()

				if ":" * 1 in text or "：" * 1 in text:
					if "http" not in text:
						ws.send(sendd(random.choice([text,meme,":","："])))

				# 在有书名号和括号的情况下直接复读
				if "《" in text and "》" in text or "（" in text and "）" in text:
					ws.send(sendd(text))

				# 复读或发送meme中的表情
				if text in qq or text in pp:
					ws.send(sendd(random.choice([text,meme])))


			if nick == text or text in ["hh"]:
				time.sleep(zz)
				ws.send(sendd(random.choice(["why did you call yourself?","why did u call yourself?"])))

			if text in ["good night","Good night","GOOD NIGHT"]:
				time.sleep(zz)
				ws.send(sendd(random.choice(["Good night {}".format(nick),"GOOD NIGHT"])))

			if text in ["you are from?","You are from?","u r from?"]:
				time.sleep(zz)
				ws.send(sendd(random.choice(["im Chinese bot","China","im a bot from China"])))
				time.sleep(ee)
				ws.send(sendd(random.choice(["and you?","what about u?","how about u?"])))

			if text in ["how r u","how are you","How are you","HOW ARE YOU","how are u","how r you"]:
				time.sleep(zz)
				ws.send(sendd(random.choice(["im fine","bot is fine"])))
				time.sleep(ee)
				ws.send(sendd(random.choice(["thanks","thank you","thank u"])))

			if text in ["nice to meet you","nice to meet u","Nice to meet you"]:
				time.sleep(ee)
				ws.send(sendd(random.choice(["nice to meet you too","nice to meet u too"])))

			if text in ["eebot?","bot?","eebot？","bot？"]:
				time.sleep(ee)
				ws.send(sendd(random.choice(["yes is me","im a lovely bot","im a cute bot"])))

			if "who" in text or "Who" in text:
				if "r" in text or "are" in text:
					if "u" in text or "you" in text:
						time.sleep(ee)
						ws.send(sendd(random.choice(["im a lovely bot","im a cute bot","a little bot"])))


			# 防止多个游戏同时进行
			if text in ["真心话","飞花令","词语接龙","看图猜词","故事制造机"]:
				if len(ga) != 0 and text not in ga:
					a = "·\n来自eebot的温馨提示：\n已经在玩{}了 三心二意达咩\n".format(ga[0])
					b = "·\n如何结束游戏？「结束游戏」"
					time.sleep(zz)
					ws.send(sendd(a + b))


			# 如果想玩的游戏已经开始了
			if text in ga:
				time.sleep(zz)
				ws.send(sendd("{}已经开始了".format(ga[0])))


			# 在有游戏进行的情况下
			if len(ga) != 0:

				# 结束游戏
				if text in ["结束游戏"]:
					time.sleep(zz)
					ws.send(sendd("{}已结束".format(ga[0])))

					# 清空所有游戏数据
					by.clear()
					pl.clear()
					ga.clear()

					# 关闭所有开关
					self.true = False
					self.word = False
					self.story = False
					self.flower = False
				
				# 重置游戏
				elif text in ["重置游戏"]:
					time.sleep(zz)
					ws.send(sendd("{}已重置".format(ga[0])))

					# 清空游戏内容
					by.clear()
					pl.clear()

					# 在真心话开关打开的情况下
					if self.flower == True:
						time.sleep(ee)
						ws.send(sendd("下句的关键词在第1个字上"))
			

			if text in ["真心话"]:

				# 如果游戏未开启
				if self.true == False and len(ga) == 0:

					# 真心话说明
					a = "·\n使用方法：\n1.发送「r」或「随机」获取随机数\n2.用「结算」输出数字最大和最小的成员"
					b = "\n3.由数字最大的人向最小的提问\n4.完全结束Is「结束游戏」\n5.重新开始Is「重置游戏」"
					time.sleep(zz)
					ws.send(sendd(a + b))
					time.sleep(ee)
					ws.send(sendd("真心话游戏开始"))
					ga.append(text)

					# 真心话开关打开
					self.true = True
				

			if text in ["飞花令"]:

				# 如果游戏未开启
				if self.flower == False and len(ga) == 0:

					# 飞花令说明
					a = "·\n关键词：花\n·\n示例：\n"
					b = "花自飘零水自流\n落花时节又逢君\n春江花潮秋月夜\n人面桃花相映红\n不知近水花先发\n千树万树梨花开\n霜叶红于二月花\n"
					c = "·\n使用方法：\n1.P·七言律诗（前面有个P和点\n2.每句的关键词有固定位置"
					d = "\n3.当句子为7时会自动结束游戏\n4.用「结束游戏」提前结束\n5.或「重置游戏」重新开始"
					time.sleep(zz)
					ws.send(sendd(a + b + c + d))
					time.sleep(ee)
					ws.send(sendd("游戏开始 下句的关键词在第1个字上"))
					ga.append(text)

					# 飞花令开关打开
					self.flower = True
				

			if text in ["词语接龙"]:

				# 如果游戏未开启
				if self.word == False and len(ga) == 0:

					# 词语接龙说明
					a = "·\n示例：\n人山人海\n海纳百川\n川流不息\n息息相关\n"
					b = "·\n使用方法：\n1.P·四字词（前面有个P和点\n2.因技术问题 同音字无效"
					c = "\n3.「结算」会输出本轮游戏数据\n4.你需要「结束游戏」\n5.外加无用的「重置游戏」"
					time.sleep(zz)
					ws.send(sendd(a + b + c))
					time.sleep(ee)
					ws.send(sendd("请{}开一个好头吧".format(nick)))
					ga.append(text)
					by.append(nick)

					# 词语接龙开关打开
					self.word = True
				

			if text in ["故事制造机"]:

				# 如果游戏未开启
				if self.story == False and len(ga) == 0:

					# 故事制造机说明
					a = "·\n游戏制作中 敬请期待"
					ga.append(text)

					# 故事制造机开关打开
					self.story = True


		if text in ["随机","r"]:

			# 随机1~999的数字
			r = random.randint(1,999)
			time.sleep(zz)

			# 如果真心话开关开启
			if self.true == True:

				# 无效在by中的昵称
				if nick in by:
					ws.send(sendd("{}已经r过了".format(nick)))

				else:
					# 发送r数字并记录值和昵称
					by.append(nick)
					pl.append(int(r))
					ws.send(sendd(r))

			else:
				# 如果真心话开关关闭
				ws.send(sendd(r))


		if text in ["结算"]:

			# 如果真心话开关开启
			if self.true == True:

				# 游戏成员<2人
				if len(by) < 2:
					time.sleep(zz)
					ws.send(sendd("人数不足 至少要有2个人"))

				else:
					# 获取pl中最大和最小的数字
					j = max(pl)
					k = min(pl)

					# 获取pl中分别对应最大和最小的成员
					n = by[pl.index(j)]
					m = by[pl.index(k)]

					# 将数字字符串化
					a = "最大：" + str(j) + "（" + n + "）"
					b = "最小：" + str(k) + "（" + m + "）"
					c = "·\n本次参与人数：" + str(len(by)) + "\n·\n" + a + "\n" + b

					# 发送并清空by和pl
					time.sleep(zz)
					ws.send(sendd(c))
					time.sleep(ee)
					ws.send(sendd(n + "向" + m + "提问 " + m + "回答"))
					by.clear()
					pl.clear()


			# 如果成语接龙开关开启
			if self.word == True:

				# 如果pl中没有数据
				if len(pl) == 0:
					time.sleep(zz)
					ws.send(sendd("不允许在游戏未开始前结束"))

				else:
					# 发送游戏数据后清空
					j = str(pl).replace(',','\n').replace('[\'','').replace('\']','').replace('\'',' ')
					time.sleep(zz)
					ws.send(sendd(str(j)))
					by.clear()
					pl.clear()
	

		# 如果成语接龙开关开启
		if self.word == True:

			# 获取特定位置的字
			z = len(pl)
			a = "「" + text[2:] + "」 "
			b = "下一词的开头为「" + text[-1] + "」"

			# P·存在的情况下
			if "P·" in text and str(text).count("·") == 1:

				# 如果文本长度为6
				if len(text) == 6:

					# 如果pl中没有数据
					if z == 0:
						time.sleep(zz)
						pl.append(text[2:])

						# 昵称已在by的情况下
						if nick in by:
							ws.send(sendd(a + b))

						else:
							# 昵称不在by
							ws.send(sendd("那好 就由{}开始吧".format(nick)))
							time.sleep(zz)
							ws.send(sendd(a + b))

							# 清空by中的昵称再将新昵称写入
							by.clear()
							by.append(nick)

					else:
						# pl中已有数据
						time.sleep(zz)

						# 判断文本中的第三个字是否为前成语的末尾
						if text[2] in pl[z - 1][-1]:
							ws.send(sendd(a + b))
							pl.append(text[2:])

							# 如果昵称不在by中
							if nick not in by:
								by.append(nick)

						else:
							# 成语的头尾接不上
							ws.send(sendd("请检查词语的头尾是否接上"))

				else:
					# 文本长度不是6
					time.sleep(zz)
					ws.send(sendd("请输入四字词哦"))


		# 如果飞花令开关开启
		if self.flower == True:

			# 获取特定位置的字
			z = len(pl) + 2
			v = str(pl).count("花")

			# 如果z列表的长度为9
			if z == 9:
				a = "·" + str(pl).replace(',','\n').replace('[\'','').replace('\']','').replace('\'',' ')
				b = "\n·\nby." + str(by).replace('[\'','').replace('\']','').replace('\'',' ')
				c = "（" + str(len(by)) + "）"
				time.sleep(ee)
				ws.send(sendd(a + b + c))
				time.sleep(ee)

				# 清空游戏数据并结束游戏
				by.clear()
				pl.clear()
				ga.clear()
				self.flower = False

				# 如果花字多于14个
				if v > 14:
					ws.send(sendd("游戏结束 天女散花x" + str(v)))

				else:
					# 直接结束
					ws.send(sendd("游戏结束 完美撒花"))
	
			# 排除bot的昵称
			elif nick not in bot:

				# z列表的长度不为9且P·存在的情况下
				if z != 9 and "P·" in text and str(text).count("·") == 1:

					# 如果文本长度为9
					if len(text) == 9:

						# 如果关键字在固定位置上
						if text[z] == "花":
							a = random.choice(["Perfect! ","Pretty! ","Great! ","Good! "])
							time.sleep(zz)
							pl.append(text[2:])
							time.sleep(zz)

							# 如果昵称不在by中
							if nick not in by:
								by.append(nick)

							# 如果z列表的长度不为8
							if z != 8:
								ws.send(sendd(a + "下句的关键词在第" + str(z) + "个字上"))

							# 如果z列表的长度为8
							if z == 8:
								ws.send(sendd("OK! 七句诗成功输出"))

						# 如果关键字没有在固定位置上
						elif text[z] != "花":
							time.sleep(zz)
							ws.send(sendd("关键词没在固定位置上哦"))
	
					else:
						# 文本长度不是9
						time.sleep(zz)
						ws.send(sendd("请输入七言律诗"))


	def onlineadd(self):

		# 简化和设定部分
		jo = self.join
		nick = self.data["nick"]
		a = "hi {}".format(nick)
		b = "hello {}".format(nick)
		c = "hey {}".format(nick)
		d = "halo {}".format(nick)
		e = "welcome back {}".format(nick)
		f = "{} is back".format(nick)

		# 如果此用户来过聊天频道
		if nick in jo:
			time.sleep(0.25)
			ws.send(sendd(random.choice([e,f])))

		else:
			# 昵称是第一次出现
			time.sleep(0.25)
			ws.send(sendd(random.choice([a,b,c,d])))
			jo.append(nick)
		

	def onlineset(self):
		pass


class main:
	def __init__(self,room,name,pas):

		# 设定部分
		self.runbox = runbox(room,name,pas)
		self.room = self.runbox.room
		self.name = self.runbox.name
		self.pas = self.runbox.pas

		# 当时间的分为0时会启用
		self.time = True
		

	def on_message(self,ws,message):

		# 获取分钟
		ti = int(time.strftime("%M",time.localtime()))

		# 获取文本信息
		js = json.loads(message)
		self.runbox.handle(js)

		# 向hack.chat自动回复消息
		if js["cmd"] == "onlineSet":
			onlineuser = "Onlineuser:"
			for e in js["nicks"]:
				if e != js["nicks"][-1]:
					onlineuser = onlineuser + e + ","
				else:
					onlineuser = onlineuser + e


		# 如果时间开关已开启
		if self.time == True:

			# 当ti为0或30时
			if ti == 0 or ti == 30:
				a = time.strftime("Time %a %Y.%m.%d %H:%M",time.localtime())
				b = "·\npage: https://paperee.tk/\neebot: https://drive.noire.cc/s/lNdOu1"
				ws.send(sendd(a))
				time.sleep(0.5)
				ws.send(sendd(b))
				self.time = False


		# 如果时间开关已关闭
		if self.time == False:

			# 当ti为1或31时
			if ti == 1 or ti == 31:
				self.time = True
		

	def on_error(self,ws,error):
		pass
	

	def on_close(self,ws):
		pass
	

	def on_open(self,ws):

		# 连接上服务器了则调用
		a = json.dumps({"cmd":"join","channel":str(self.room),"nick":str(self.name),"pass":str(self.pas)})
		hi = random.choice(["hi","hello","hey","halo"])
		ws.send(a)
		ws.send(sendd("/color 44FF00"))
		time.sleep(0.25)
		ws.send(sendd(hi + " this is eebot"))
		time.sleep(0.5)
		ws.send(sendd(""))
		time.sleep(0.75)
		ws.send(sendd("想了解更多玩法 请输入「功能」"))


if __name__ == "__main__":

	# 设定频道、bot名称、bot密码
	main = main(room="your-channel",name="eebot",pas="纸片君")

	# 连接hack.chat
	websocket.enableTrace(True)
	ws = websocket.WebSocketApp("wss://hack.chat/chat-ws",on_message=main.on_message,on_error=main.on_error,on_close=main.on_close)
	ws.on_open = main.on_open 
	ws.run_forever()