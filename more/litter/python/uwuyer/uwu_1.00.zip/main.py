﻿import sys
import time
import codecs
import tkinter


tk=tkinter.Tk()
tk["bg"]="white"

test=codecs.open('game_text.eb','r',"UTF-8-sig").read().replace('\r','').split('\n\n\n\n')
index=0

try:
	save=codecs.open("game_save.eb","r","UTF-8-sig").read()
	index=int(save)-1

except:
	pass

def save(event=None):
	codecs.open("game_save.eb","w","UTF-8-sig").write(str(index))


label=tkinter.Label(tk,font=('consolas',22),wraplength='500',height=12,anchor="center",fg='#7D5A30',bg='white')
save=tkinter.Button(tk,font=('consolas',16),text="save",bg="white",command=save,activebackground="white",activeforeground="black",fg="#7D5A30",bd=0)


def typewriter(speed,text,counter=1):
	label.config(text=text[:counter])

	if counter<len(text):
		if text[counter-2]=='。':
			time.sleep(0.2)

		tk.after(speed,lambda:typewriter(speed,text,counter+1))


def uwu(event=None):
	global index

	label.forget()
	save.forget()
	index+=1

	time.sleep(0.4)

	if index>=len(test):
		tk.destroy()
		sys.exit()

	text=test[index]
	x=True

	if text[0]=="&":
		x=False
		part=text.split('\n',1)
		text=part[1]
		label["font"]=('Consolas',part[0][1:])

	else:
		label["font"]=('Consolas',16)

	typewriter(20,text)
	label.pack(padx=18,pady=18)

	if x==True:
		save.pack()


label['text']=test[0]
label.pack(padx=18,pady=18)

tk.bind("<Button-3>",uwu)
tk.bind("<space>",uwu)

tk.title('Grrd-麻鸡的拯救计划 ver.0.01')
tk.geometry('544x416')
tk.resizable(0,0)
tk.mainloop()