import sys
import time
import tkinter
import threading
import winsound


tk=tkinter.Tk()
tk["bg"]="white"

test=open('uwu.txt','r').read().split('\n\n\n\n')
index=0

label=tkinter.Label(tk,font=('Consolas',22),wraplength='500',height='14',anchor="center",fg='#7D5A30',bg='white')


def typewriter(speed,text,counter=1):
	label.config(text=text[:counter])

	if counter<len(text):
		if text[counter-2]=='。':
			time.sleep(0.2)

		tk.after(speed,lambda:typewriter(speed,text,counter+1))


def uwu(event=None):
	global index

	label.forget()
	index+=1

	time.sleep(0.4)

	if index>=len(test):
		tk.destroy()
		sys.exit()

	text=test[index]

	if text[:2]=="\\&":
		part=text.split('\n',1)
		text=part[1]
		label["font"]=('Consolas',part[0][2:])

	else:
		label["font"]=('Consolas',16)

	typewriter(20,text)
	label.pack(padx=18,pady=18)


'''
def awa(event=None):
	global index
	
	label.forget()
	index-=1

	if index<=0:
		index=1

	typewriter(30,test[index-1])
	label.pack(padx=18,pady=18)
'''
'''
def music(file):
	winsound.PlaySound(file,winsound.SND_FILENAME)
	sys.exit()
'''
	
label['text']=test[index]
label.pack(padx=18,pady=18)

# tk.bind("<space>",uwu)
# tk.bind("<Return>",uwu)
tk.bind("<Button-1>",uwu)
# tk.bind("<Button-3>",awa)

# threading.Thread(target=music,args=('awa.wav',)).start()

tk.title('Grrd-麻鸡的拯救计划 ver.0.01')
tk.geometry('544x416')
tk.resizable(0,0)
tk.mainloop()