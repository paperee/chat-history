﻿import sys
import time
import codecs
import tkinter
import tkinter.messagebox
from functools import partial


tk=tkinter.Tk()
tk["bg"]="white"

file="game_text.eb"
index=[file,0]

buttons=[]


try:
	save_=codecs.open("Data/game_save.eb","r","UTF-8-sig").read().split('\n',1)

	if save_.strip()!='':
		file=save_[0]
		index[0]=file
		index[1]=int(save_[1])-1
		print(f"[Load]{index}")

except:
	pass


test=codecs.open(f'Data/{file}','r',"UTF-8-sig").read().replace('\r','').split('\n\n\n\n')


def awa_save(event=None):
	global index

	if index[1]<1:
		index[1]=1

	codecs.open("Data/game_save.eb","w","UTF-8-sig").write(f"{index[0]}\n{str(index[1])}")
	tkinter.messagebox.showinfo(title='Save',message='Success uwu')
	print(f"[Save]{index}")


msg=tkinter.Button(tk,font=('consolas',24),height=14,activebackground="white",activeforeground="#7D5A30",fg='#7D5A30',bg='white',bd=0)
save=tkinter.Button(tk,font=('consolas',18),command=awa_save,activebackground="white",activeforeground="black",fg="#7D5A30",bg="white",bd=0)


def typewriter(speed,text,counter=1):
	msg.config(text=text[:counter])

	if counter<len(text):
		if text[counter-2]=='。':
			time.sleep(0.2)

		tk.after(speed,lambda:typewriter(speed,text,counter+1))


def option(file_,event=None):
	global test,index

	try:
		test=codecs.open(f'Data/{file_}','r',"UTF-8-sig").read().replace('\r','').split('\n\n\n\n')
		index=[file_,0]
		uwu_msg()

	except:
		pass


def uwu_msg(event=None):
	global index

	msg.forget()
	save.forget()

	for button_ in buttons:
		button_.forget()

	index[1]+=1
	print(index)

	time.sleep(0.4)

	if index[1]>=len(test):
		tk.destroy()
		sys.exit()

	text=test[index[1]]

	# 字体大小
	if text[0]=="&":
		part=text.split('\n',1)
		text=part[1].strip('\n')
		msg["font"]=('Consolas',part[0][1:])

	else:
		msg["font"]=('Consolas',18)

	# 结局功能
	if "【" in text and "】" in text:
		codecs.open("Data/game_save.eb","w","UTF-8-sig").write('')

	# 选项功能
	if "|" in text:
		text_=text[1:].split("|")
		tk.unbind("<space>")

		for option_ in text_:
			text__=option_.split(' ',1)
			option__=tkinter.Button(tk,font=('consolas',18),height=2,text=text__[1].strip('\n'),command=partial(option,text__[0]),bg="white",activebackground="white",activeforeground="black",fg="#7D5A30",bd=0)
			option__.pack(pady=40)
			buttons.append(option__)

	else:
		typewriter(20,text)
		msg.pack(padx=20,pady=20)


msg['text']=test[0]
msg['command']=uwu_msg
msg.pack(padx=20,pady=20)

tk.title('Grrd-麻鸡的拯救计划 ver.0.01')
tk.geometry('640x480')
tk.iconbitmap('Graphics/fish.ico')
tk.bind("<Button-3>",awa_save)
tk.resizable(0,0)
tk.mainloop()
