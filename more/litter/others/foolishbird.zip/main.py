import turtle


turtle.setup(544,416)
turtle.speed(1)
turtle.pencolor("gray")
turtle.fillcolor("white")


def awa():
    # 主体
    turtle.pensize(5)
    
    turtle.penup()
    turtle.goto(-140,100)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(160)
    turtle.circle(40,90)
    turtle.forward(160)
    turtle.circle(40,90)
    turtle.forward(20)
    turtle.circle(40,90)
    turtle.forward(120)
    turtle.setheading(90)
    turtle.forward(100)
    turtle.circle(40,180)
    turtle.setheading(200)
    turtle.forward(30)
    turtle.setheading(350)
    turtle.forward(29)
    
    
    turtle.penup()
    turtle.goto(-120,110)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(10)

    
    turtle.penup()
    turtle.goto(80,-5)
    
    turtle.pendown()
    turtle.setheading(20)
    turtle.forward(100)
    turtle.setheading(240)
    turtle.forward(50)
    turtle.setheading(-10)
    turtle.forward(50)
    turtle.setheading(10)
    turtle.forward(-100)

    
    turtle.penup()
    turtle.goto(-50,-45)
    
    turtle.pendown()
    turtle.setheading(320)
    turtle.circle(110,60)
    turtle.circle(40,60)

    
    turtle.penup()
    turtle.goto(-90,-100)
    
    turtle.pendown()
    turtle.setheading(300)
    turtle.circle(-60,50)

    
    turtle.penup()
    turtle.goto(50,-100)
    
    turtle.pendown()
    turtle.setheading(300)
    turtle.circle(-60,50)


    # 字母
    '''
    turtle.pensize(3)

    turtle.penup()
    turtle.goto(-50,30)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(20)

    
    turtle.penup()
    turtle.goto(-50,30)
    
    turtle.pendown()
    turtle.setheading(360)
    turtle.forward(10)

    
    turtle.penup()
    turtle.goto(-50,20)
    
    turtle.pendown()
    turtle.setheading(360)
    turtle.forward(10)

    
    turtle.penup()
    turtle.goto(-30,10)
    
    turtle.pendown()
    turtle.circle(5,360)

    
    turtle.penup()
    turtle.goto(-15,10)
    
    turtle.pendown()
    turtle.circle(5,360)

    
    turtle.penup()
    turtle.goto(0,30)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(16)
    turtle.circle(3,90)

    
    turtle.penup()
    turtle.goto(10,20)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(10)

    
    turtle.penup()
    turtle.goto(10,25)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(1)

    
    turtle.penup()
    turtle.goto(24,26)
    
    turtle.pendown()
    turtle.setheading(160)
    turtle.circle(4,200)

    
    turtle.penup()
    turtle.goto(18,12)
    
    turtle.pendown()
    turtle.setheading(-42)
    turtle.circle(4,200)

    
    turtle.penup()
    turtle.goto(34,30)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(20)

    
    turtle.penup()
    turtle.goto(43,18)
    
    turtle.pendown()
    turtle.setheading(90)
    turtle.circle(4,180)

    
    turtle.penup()
    turtle.goto(43,18)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(8)

    
    turtle.penup()
    turtle.goto(50,70)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(30)

    
    turtle.penup()
    turtle.goto(55,65)
    
    turtle.pendown()
    turtle.setheading(90)
    turtle.circle(5,180)

    
    turtle.penup()
    turtle.goto(30,120)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(25)
    turtle.setheading(0)
    turtle.forward(15)

    
    turtle.penup()
    turtle.goto(50,105)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(10)

    
    turtle.penup()
    turtle.goto(50,110)
    
    turtle.pendown()
    turtle.setheading(-90)
    turtle.forward(1)

    
    turtle.penup()
    turtle.goto(60,110)
    
    turtle.pendown()
    turtle.setheading(90)
    turtle.forward(5)

    
    turtle.penup()
    turtle.goto(80,110)
    
    turtle.pendown()
    turtle.setheading(160)
    turtle.circle(4,200)

    
    turtle.penup()
    turtle.goto(74,96)
    
    turtle.pendown()
    turtle.setheading(-42)
    turtle.circle(4,200)
    '''

    
    turtle.penup()
    turtle.goto(0,0)
    turtle.end_fill()


turtle.onclick(awa(),btn=1,add=None)
