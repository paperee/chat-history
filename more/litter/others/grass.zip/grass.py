# -*- coding: UTF-8 -*-
# pip3 install googletrans==4.0.0-rc1

from googletrans import Translator
from random import randint,choice
from time import sleep

ZHR=Translator()

def tele(text):
	lang=choice(["en","ja","ko","de","eo"])
	return ZHR.translate(ZHR.translate(text,dest=lang).text,dest="zh-cn").text

def goog(text):
	for _ in range(randint(2,4)):
		text=tele(text)
		
		_uvu=randint(1,len(text))
		uvu_=choice(["，","\n"])
		text=text[:_uvu]+uvu_+text[_uvu:]
		
		sleep(randint(3,9)/10)

	return tele(text).replace("\n","")

try:
	print(goog("内容"))

except:
	print("Time out……")