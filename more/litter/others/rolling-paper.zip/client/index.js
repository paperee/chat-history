/*
    【移动时】
    判断接触图块->查询触碰条件
*/
const data={
    "parts":["为明天前往远方"],
    "roles":{
        "ee":[
            [["一张亮绿色的纸片","无","再生纸","未知"],"ee"], // [[说明,性别,种族,年龄],图片前缀名]
            ["DNA"], // 默认随身物品
        ],
    },
    "items":{
        "DNA":[
            [["可让携带者表现出人类外貌的DNA片段"],null], // [[说明],图片名]
            [["切换",[()=>null]]], //[[菜单名,[JS]]]
        ],
        "怀表":[
            [["查看醒来经过的时长以及目前的时间"],null],
            [["查看",[()=>null]]]
        ],
    },
    "now":{
        "page":"#home", // 页面
        "part":0, // 章节(JS文件)
        "map":null, // 地图
        "role":["ee",null,null], // [角色名]
        "pos":{"role":null,"map":null}, // [角色,地图]
        "block":[null,0], // 剧本
        "var":{"toZHR":0}, // 变量
        "gear":{}, // 设置
        "mouse":[null,null], // [左键事件,右键事件]
        "time":0, // 游戏时长
        "timer":[], // 定时器
        "items":[], // 物品
        "badges":[], // 成就
    }
}
const maker={
    "#role":(list)=>{
        const now=data["now"]
        list.forEach((value,i)=>value?now["role"][i]=value:null)
        uwu("#role>div img")[0].src="../roles/"+now["role"].join("_")+".png"
    },
    "#back":(value)=>{
        const ee=awa("img")
        ee.src=`../${value[0][0]||'wins'}/${value[0][1]}.${value[0][2]||'png'}`
        css(ee,["opacity","z-index"],value[1])
        uwu("#back")[0].appendChild(ee)
    },
    "#tiles":(value,i)=>{
        const ee=awa("img")
        ee.src=`../${value[0][0]||'tiles'}/${value[0][1]}.${value[0][2]||'png'}`
        ee.classList.add(value[1][3])
        const ee_=awa("div")
        ee_.value=value[0][1]
        ee_.index=i
        ee_.appendChild(ee)
        css(ee_,["bottom","left","opacity","z-index"],value[1])
        uwu("#tiles")[0].appendChild(ee_)
    },
}
const player={
    msg:(list)=>{
        boxFadeIn(list[1])
        uwu("#content")[0].innerHTML=""
        if (list[2][0]) {
            const ee=awa("i")
            ee.id="nick"
            ee.textContent=list[2][0]
            uwu("#content")[0].appendChild(awa("p").appendChild(ee))
        }
        const ee_=awa("div")
        ee_.id="text"
        ee_.innerHTML=markdown(true).render(list[2][1])
        ee_.style["height"]=list[2][0]?"16.2vh":"21.6vh"
        uwu("#content")[0].appendChild(ee_)
        list[3].forEach((value)=>value())
        turnMouse(0,()=>next())
    },
    js:(list)=>{
        list[1].forEach((value)=>value())
        next()
    },
    option:(list)=>{
        boxFadeIn(list[1])
        uwu("#content")[0].innerHTML=""
        list[3].forEach((value,i)=>{
            if (!judge(list[2][i])) return
            const ee=awa("div")
            ee.innerHTML=markdown(true).render(value)
            ee.classList.add("pointer")
            ee.classList.add("option")
            ee.addEventListener("click",(event)=>list[4][i].forEach((value)=>value()))
            uwu("#content")[0].appendChild(ee)
        })
        turnMouse(0)
    }
}
const markdown=(html)=>new Remarkable("full",{
    html:html,
    breaks:true,
    linkify:true,
    typographer:true,
    quotes:`""''`,
    linkTarget:'_blank" rel="noopener noreferrer',
})
const plus=(name,value)=>data["now"]["var"][name]+=value
const get=(name)=>data["now"]["var"][name]
const print=(text)=>console.log(text)
const uwu=(ee)=>document.querySelectorAll(ee)
const awa=(ee)=>document.createElement(ee)
const style=(ee)=>window.getComputedStyle(ee)
const css=(ee,names,values)=>names.forEach((name,i)=>ee.style[name]=values[i])
const scale=(mul)=>{
    uwu("#role>div")[0].style["zoom"]=mul
    uwu("#map>div").forEach((value)=>value.style["zoom"]=mul)
    uwu("#map")[0].style["height"]=vh(parseFloat(style(uwu("#map")[0])["height"])*mul)+"vh"
}
const toggle=(ee)=>ee.style["display"]=style(ee)["display"]?"":"none"
const fade=(ee,opacity,time)=>{
    const temp=style(ee)["transition"]
    css(ee,["opacity","transition"],[opacity,"opacity "+time/1000+"s ease-in-out"])
    if (opacity==1) return ee.style["display"]="block"
    setTimeout(()=>ee.style["display"]=parseInt(style(ee)["opacity"])?"block":"none",time)
}
const fit=(ee)=>uwu(ee).forEach((ee_)=>ee_.style["zoom"]=uwu("#paper")[0].offsetHeight/2700) // 自适应
const fitAll=()=>{
    fit("#role>div img")
    fit("#tiles>div img")
}
const px=(vh_)=>vh_/100*window.innerHeight
const vh=(px_)=>px_/window.innerHeight*100
const offset=(ee)=>ee.getBoundingClientRect()
const judge=(list)=>{
    const items=list[0].every((value)=>data["now"]["items"].includes(value))
    const values=Object.keys(list[1]).every((value)=>{
        if (!isNaN(list[1][value])) return get(value)==list[1][value]
        return list[1][value][0]<=get(value)<=list[1][value][1]
    })
    return items&&values
}
const stopwatch=(ee,ee_)=>{
    ee.textContent=Math.floor(data["now"]["time"]/60)
    ee_.textContent=data["now"]["time"]%60
}
const adjust=(goto,value=0.8)=>{
    setTimeout(()=>{
        const paperH=uwu("#paper")[0].offsetHeight*value
        const winH=window.innerHeight
        uwu(".win").forEach((ee)=>css(ee,["height","top"],[vh(paperH)+"vh",vh(goto*winH/2-goto*paperH/2)-goto*5+"vh"]))
    },600)
}
const turnMouse=(key,event=0)=>data["now"]["mouse"][key]=event // 切换鼠标事件
const turnPage=(id)=>{ // 切换游戏界面
    data["now"]["page"]=id
    uwu("#player>div").forEach((ee)=>fade(ee,0,1000))
    setTimeout(()=>fade(uwu(id)[0],1,1400),800)
}
const turnPart=(goto)=>{ // 切换章节
    const index=data["now"]["part"]+=goto
    uwu("#part")[0].src="parts/"+data["parts"][index]+".js"
    uwu("#part")[0].onload=()=>{
        turnMap(data_["default"]["map"])
        setTimeout(()=>fade(uwu("#loading")[0],0,1600),1400)
    }
}
const turnMap=(map)=>{ // 切换地图
    const map_=data_["maps"][map]
    css(uwu("#map")[0],map_["css"][0],map_["css"][1])
    adjust(1)
    Object.keys(map_["scenes"]).forEach((id)=>{
        if (map_["scenes"][id].length==0) return
        uwu(id)[0].innerHTML=""
        map_["scenes"][id].forEach((value,i)=>maker[id](value,i))
    })
    setTimeout(()=>map_["events"]["auto"].forEach((events)=>events[0][0]?events[1].forEach((event)=>event()):null),600)   
}
const turnRole=(list)=>{ // 切换角色
    data["now"]["items"]=data["roles"][list[0]][1]
    maker["#role"](list)
}
const turnPos=(id,goto)=>{ // 切换位置
    data["now"]["pos"][id]=goto
    uwu(id)[0].style["transform"]=`translateX(${goto}vh)`
}
const turnBlock=(para,line=0)=>{ // 切换剧本
    data["now"]["block"]=[para,line]
    next(line)
}
const next=(skip=1,mode=1)=>{ // 跳跃行
    const index=data["now"]["block"][1]+=skip
    const block=data["now"]["block"]
    const drama=data_["blocks"][block[0]]
    if (index>=drama.length) return turnMouse(0,(x,y)=>roll(x,y))&&boxFadeOut()
    if (!judge(drama[block[1]][1][0])) return next(skip)
    setTimeout(()=>player[drama[block[1]][0]](drama[block[1]][1]),100)
}
const boxFadeOut=()=>{
    setTimeout(()=>css(uwu("#textbox")[0],["display","opacity","transform"],["normal","0","translateX(8vw)"]),100)
    setTimeout(()=>uwu("#textbox")[0].style["display"]="none",800)
}
const boxFadeIn=(list=0)=>{ // 文本容器
    const ee=uwu("#textbox")[0]
    setTimeout(()=>css(ee,["background-image","transform","top","opacity"],[`url("../wins/textbox_${list[0]}.png")`,"translateX(0)",vh(list[1]*window.innerHeight/2-list[1]*ee.offsetHeight/2)+"vh","1"]),100)
}
const open=()=>{ // 打开绘本
    setTimeout(()=>turnPage("#game"),400)
    setTimeout(()=>turnPart(0),600)
    data["now"]["timer"].push(setInterval(()=>data["now"]["time"]+=1,1000))
}
const load=()=>{} // 读档
const save=()=>{} // 存档
const bgm=(loop,file)=>{} // 背景音乐播放
const se=(loop,file)=>{} // 音效播放
const mood=(bubble)=>{} // 心情气泡
const move=(x,y=0)=>{
    const ee=uwu("#map")[0]
    roll(offset(ee).left+ee.offsetWidth*x)
}
const roll=(x,y=0)=>{ // 地图卷动
    const paper=uwu("#paper")[0]
    const paperL=offset(paper).left // 小窗左侧
    const paperR=offset(paper).right // 小窗右侧
    const map=uwu("#map")[0]
    const mapL=offset(map).left // 地图左侧
    const mapR=offset(map).right // 地图右侧
    const role=uwu("#role")[0]
    const roleW=role.offsetWidth/2 // 角色半宽
    const roleC=roleW+offset(role).left // 角色中心
    const winW=window.innerWidth/2 // 窗口宽度
    const range=x-roleC // 地图与角色的总路程
    const area=roleC+range-winW // 正负指示整体位移的方向
    const factor=(range>=0&&roleC+range>=winW)||(range<0&&roleC+range<=winW) // 判断角色移动总路程后是否越过中线
    turnPos("#role",vh((factor?winW:x)-paperL-roleW)) // 使角色移动

    // 如果角色未越过中线 则跳出
    if (!factor) return

    // 如果角色越过中线 则地图卷动
    // 判断卷动后地图边缘是否超过小窗
    if ((range>=0&&mapR-area<=paperR)||(range<0&&mapL-area>=paperL)) {
        const limit=range>=0?mapR-paperR:mapL-paperL // 判断地图的重合侧
        turnPos("#map",vh(-paperL+mapL-limit)) // 使地图边缘与小窗边缘重合
        turnPos("#role",vh(x-paperL-limit-roleW)) // 使角色移动剩下的路程
    }
    else turnPos("#map",vh(-paperL+mapL-area)) // 使地图卷动剩下的路程
}
window.onload=()=>{
    uwu(".click").forEach((ee)=>{
        ee.addEventListener("click",(event)=>{
            const mouse=data["now"]["mouse"]
            mouse[0]?mouse[0](event.clientX,event.clientY):null
        })
        ee.addEventListener("contextmenu",(event)=>{
            //print("uwu")
        })
    })
    open()
    document.addEventListener("mousemove",(event)=>{
        const winW=window.innerWidth/2
        const winH=window.innerHeight/2
        const x=event.clientX-winW
        const y=event.clientY-winH
        const page=data["now"]["page"]
        const temp=`translate(${x/10000}vw,${y/4000}vh)`
        if (page=="#game") {
            const role=uwu("#role")[0]
            maker["#role"]([null,event.clientX<=offset(role).left+role.offsetWidth/2?"left":"right",null])
            uwu("#tiles>div img").forEach((ee)=>ee.style["transform"]=`translateX(${-x/(1000-parseInt(ee.classList[0]))}vw)`)
            uwu("#role>div")[0].style["transform"]=`translateX(${-x/1000}vw)`
        }
        uwu(page)[0].style["transform"]=temp
        uwu("#frame")[0].style["transform"]=temp
    })
    window.addEventListener("resize",()=>fitAll())
    setInterval(()=>fitAll(),1000)
}