#/usr/bin/python3

print("游戏：鱼的报复计划")
print("制作：钓鱼的Qwer 纸片君ee")
print("特别鸣谢：Mr_Zhang 黑茶 4n0n4me MelonFish")
input("按下任意键开始")
print("你的好友小张送给你一条鱼，他问你怎么处置。")
print("1.吃了 2.放生 3.养起来 4.留着下次吃")
choose=int(input("请选择："))

if choose==1:
	print("你打算什么时候吃？")
	print("1.今天 2.明天")
	choose=int(input("请选择："))

	if choose==1:
		input("小张一溜烟跑不见了。")
		print("你打算怎么吃？")
		print("1.生吃 2.炖汤 3.烧烤 4.晒干")
		choose=int(input("请选择："))

		if choose==1:
			input("你啊呜一口吞下鱼。")
			input("gu……guru？")
			input("guru？！")
			input("你再也无法说人话了……")
			input("你只能发出类似鱼吐泡泡的声音。")
			print("达成结局：鱼的同化")

		elif choose==2:
			input("你将家里最后的三克油倒入汤中。")
			input("guruguru……")
			input("这是鱼汤沸腾的声音。")
			input("啊，汤和肉都非常鲜美。")
			print("达成结局：美味的汤")

		elif choose==3:
			input("你架好破烂的烧烤架，准备享受这片刻的美味。")
			input("点燃的朽木成了最后一束光。")
			input("纸包鱼，嘎嘎脆，香喷喷。")
			input("达成结局：烤的好吃")

		elif choose==4:
			input("你想吃小鱼干了。")
			input("你把鱼摆在家门口阳光最充足的地方。")
			input("可是几天后，那里只剩一张干巴的鱼皮。")
			input("达成结局：鱼的失踪")

	elif choose==2:
		input("你很穷，今天一顿饭已经吃饱了。")
		input("晚上，你在挑灯夜读。")
		input("北冥有鱼，其名为……？")
		input("你背了三小时还没把这句话背下来。")
		input("你睡着了，做了一个很长的梦。")
		input("你梦见鱼化成鲲飞走。")
		input("早上起来，你发现鱼真没了。")
		input("原来在厨房，鱼已经死了。")
		print("达成结局：晚了一步")
		
elif choose==2:
	input("你打算把它放生。")
	input("小张阻止了你，你生气地让你不要管。")
	input("但他说那是他好不容易钓来的。")
	input("小张让你吃了那条鱼。")
	input("1.还是吃吧 2.还给小张 3.执意放生 4.")
	choose=int(input("请选择："))

	if choose==1:
		input("你仔细想了想，最终决定吃了它。")
		input("晚上，你跟小张分享了美食。")
		print("达成结局：真香")

	elif choose==2:
		input("面对那么可爱的鱼你不敢下嘴，你决定还给小张。")
		input("小张见你这样，只能抱着鱼走了。")
		input("晚上，小张家传来阵阵鱼香。")
		print("达成结局：真馋")
		
elif choose==3:
	input("你心想着，这还是条鱼宝宝。")
	input("但你家只有唯一一个纸箱。")
	input("你把鱼养在纸箱里，但漏水了。")
		
elif choose==4:

input("游戏结束")