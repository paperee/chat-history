---
tags: [blog]
title: Discord 焕发活力
created: '2023-08-18T04:01:17.057Z'
modified: '2023-08-18T05:35:44.949Z'
---

# Discord 焕发活力
**作者：PAPEREE｜日期：2023-08-18**

## 关于改变称谓的问题
目前，我的文章出现的昵称居多，在此处列个对照表（含之前文章的昵称）
- 鱼/Fish：MelonFish
- 张/ZHR：MrZhang365
- 麻鸡：Maggie
- 初墨：zzChumo
- 404：4n0n4me
- 22c：yu22c

其他昵称长啥样就长啥样（被打

## 正文
早在半年前，我们的Discord频道就建立了。详见聊天室新闻：[官方 Discord 建立！来水吧](https://chatnews.thz.cool/?p=102)。如今，聊天室新闻里贴出的[邀请链接](https://discord.com/invite/UzdZCBXvsH)依然可用。如果你感兴趣，可以点击上面的链接加入我们。

在昨天之前，空无一人的Chatrooms Club沉睡多月。昨天，Maggie希望和我们一起听歌，便重启了Discord，把我们邀请回去。

过程中，Maggie打开了语音，开心地吹他的溜溜笛。~~404还纳闷为什么视频里有橡皮鸭的声音~~。

ZHR也进了语音频道，加入了我们的一起看。结果，大概过了半小时，当我们问到他时，他居然才表示自己看不到YouTube的视频，是进来“滥竽充数”的。~~好一个诈骗~~。

DPG也进来，不过在“反复横跳”好几次后就退出了。

最离谱的是晚上，Maggie、初墨和我三人轮流播放术区。在众人的怂恿下，初墨打开了语音，又打开了摄像头，~~露出了他的真实面目~~。最后，还给我们拍了一张他房间的3D照片。

## 上图
![](https://filebed.paperee.guru/templates/ee/happy_.png)
![](https://filebed.paperee.guru/templates/ee/happy_1.png)
![](https://filebed.paperee.guru/templates/ee/happy_2.png)
咳咳，本来还截了一张初墨~~搞事~~开摄像头的图，~~怕被揍所以不发了~~。
