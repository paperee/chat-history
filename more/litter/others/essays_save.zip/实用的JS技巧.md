---
tags: [blog]
title: 实用的 JS 技巧
created: '2023-07-30T02:10:43.685Z'
modified: '2023-08-12T14:42:16.630Z'
---

# 实用的 JS 技巧
**作者：PAPEREE｜日期：2023-07-30**

## 输入框高度自适应
### Javascript 版本
```
$("#id")[0].oninput=function() {
    this.style.height=0
  	this.style.height=this.scrollHeight+"px"
}
```

### JQuery 版本
```
$("#id").on("input",function() {
    $(this).css("height",0)
    $(this).css("height",$(this)[0].scrollHeight+"px")
})
```

我首次见到这么简单实现高度自适应的方法，然后从 HC 代码里扒下来改了改（

## 自动分页
### JQuery 版本
```
let all=9 // 全部元素的数量
let one=4 // 每页的显示最大数量
let temp=0 // 已经计算完的数量

for (let i=0;i<Math.ceil(all/one);i++) {
    let div=$("<div>").appendTo($("#id")) // 新增容器作为新的一页
    let temp_=temp

    for (temp;temp<Math.min(temp_+one,all);temp++) {
        $("<div>").appendTo(div) // 添加元素进本页
    }
}
```

网上那些乱七八糟的插件是什么鬼，还不如自己写一个（
