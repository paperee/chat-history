---
tags: [blog]
title: 测试 MD 和 HTML
created: '2023-08-09T03:39:58.939Z'
modified: '2023-08-12T15:25:11.687Z'
---

# 测试 MD 和 HTML

<b id="door">请你找到这个世界的<span>门</span></b>

哼哼哼<f1>啊啊</f1><f2>啊啊</f2><f3>啊啊啊啊</f3>

这里是<f1>纸片君ee</f1>，请叫我<f3>ee</f3>。

| 序号 | ee | eebot |
|-------|-------|-------|
|  P1  |  你好  |  你好你好 uwu  |
|  P2  |  喜欢吃什么  |  当然是麻鸡啦  |
|  P3  |  麻鸡是什么  |  Maggie  |

<details open>
<summary>纸片君（ee）</summary>
反空中网和总统特工小队1号喜欢躺在云覆盖的鱼背上
虽然纸片君ee也想取满二十四个字但不知道该怎么办
在光中云上打开404网页的纸包住了涂上初墨酱的鱼
</details>

_______uwu________
____uwu~uwu~uwu____
_^uwu^uwu~uwu~uwu^uwu^__
________|_|__________
________|_|\_\_<f0>uwuTree</f0>_\_

> 2022是有史以来最魔幻的一年吧） ——666 2022/8/20

```
你干嘛~哎哟~~
PS：这个页面里有彩蛋
```

<script>
    $(document).ready(function() {
        $("span:contains('门')").on("click",function() {
            $("#door").text("哇 我真的……永远不会放弃你~")
        })
    })
</script>
