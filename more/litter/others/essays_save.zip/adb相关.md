---
tags: [centos]
title: 使用 adb
created: '2023-08-21T07:59:38.835Z'
modified: '2023-08-21T08:27:45.141Z'
---

# 使用 adb
## 准备步骤
### 手机允许 USB 调试
https://zhuanlan.zhihu.com/p/610133064
（此处为MIUI，其他系统就自己去找找吧）

使用数据线连接手机和电脑

### 电脑下载工具包
https://dl.google.com/android/repository/platform-tools_r30.0.5-windows.zip
（此处为Windows，其他系统就自己去找找吧）

- 进入`platform-tools_r30.0.5-windows\platform-tools`目录。
- 在窗口地址栏中输入`cmd`打开终端。
- 在cmd中输入`adb devices`连接设备。

## 卸载系统应用
- 查看应用包名：长按APP -> 应用信息 -> 关于 -> 应用包名
- 在cmd中输入`adb shell pm uninstall --user 0 <应用包名>`
