# CSS下划线
**作者：PAPEREE｜日期：2024-02-07**

## 少有的教程
有没有人发现，ee博客的画风十分甚至二十分独特（
没错，**黑白水墨屏**，~~过度花哨的~~多且密集的**文字装饰**。
比较令人眼前一~~黑~~亮的，大概得非下划线莫属。
毕竟ee为了区分不同的元素，又不想对文字本身的颜色下手（~~小声BB~~

<style>
.uwu {
    text-underline-offset:0;
    text-decoration-thickness:0!important;
}
.uwu_,.uwu__:hover {
    text-underline-offset:-9px;
    text-decoration-thickness:9px!important;
}
.uvu,.uvu_ {
    text-underline-offset:-18px;
    text-decoration-thickness:18px!important;
}
.uwu__ {
    text-underline-offset:0;
    text-decoration-thickness:2px!important;
    transition:0.14s ease-in-out all;
}
.uvu__ {
    text-decoration-thickness:18px!important;
    text-decoration-color:#333!important;
}
.uvu__:active {
    text-decoration:none;
}
.uxu {
    text-decoration:overline!important;
}
.uxu_ {
    text-decoration:underline overline!important;
}
.uwu_,.uwu__,.uvu,.uvu_ {
    text-decoration-color:#4F0!important;
}
.uwu,.uwu_,.uwu__,.uvu {
    text-decoration:underline;
}
.uvu_,.uvu__ {
    text-decoration:line-through;
}
</style>

## 下划线种类
- `text-decoration:underline solid;`
<span class="uwu">这是普通的下划线</span>

- `text-decoration:underline double;`
<span class="uwu" style="text-decoration-style:double;">这是DPG（双重身）下划线</span>

- `text-decoration:underline dashed;`
<span class="uwu" style="text-decoration-style:dashed;">这是虚的下划线（雾</span>

- `text-decoration:underline dotted;`
<span class="uwu" style="text-decoration-style:dotted;">这是点状的下划线</span>

- `text-decoration:underline wavy;`
<span class="uwu" style="text-decoration-style:wavy;">这是大波浪<s>薯片</s>下划线</span>

### 特殊下划线
- `text-decoration-line:grammar-error`
<span class="uwu" style="text-decoration-line:grammar-error;">这是普通报错的波浪线（雾</span>

- `text-decoration-line:spelling-error`
<span class="uwu" style="text-decoration-line:spelling-error;">这是危险报错的波浪线（雾</span>

这两种线出现在`Google`浏览器的F12控制台里，我不清楚是否被所有主流浏览器支持。
值得一提的是，在下文中下划线`underline`所有属性，在它们身上通通不适用。

## 细节的更改
种类满意了，但下划线的摆放、宽度、颜色依旧不容乐观咋办？万能的CSS当然拥有修改的属性。

### 更改位置
使用方法：`text-underline-position:<位置>;`
**位置拥有如下值**：
- `auto`｜自动计算下划线是放在字母基线上还是下。
- `under`｜强制使下划线位于字母基线下，确保下标不会被下划线阻挡（来自bing）。
- `left`和`right`｜在竖直排版下分别位于文字左右，在水平排版模式下与`under`相同。

### 更改偏移量
请加上前提属性（其他位置未尝试）：`text-underline-position:under;`
使用方法：`text-underline-offset:<偏移量>`（正上负下）
- <span class="uwu" style="text-underline-offset:1px!important;">这是位置最舒服的下划线（1px</span>
- <span class="uwu" style="text-underline-offset:-8px!important;">这是想当划线的下划线（-8px（雾</span>
- <span class="uwu" style="text-underline-offset:-20px!important;">这是想当上划线的下划线（-20px（雾</span>
- <span class="uwu" style="text-underline-offset:30px!important;">这是想逃跑的下划线（30px（雾</span>

<br>

### 更改宽度
使用方法：`text-decoration-thickness:<宽度>;`
- <span class="uwu" style="text-decoration-thickness:2px!important;">这是宽度最舒服的下划线（2px</span>
- <span class="uwu" style="text-decoration-thickness:5px!important;">这是有点宽的下划线（5px</span>
- <span class="uwu" style="text-decoration-thickness:30px!important;">这是有亿点宽的下划线（30px（雾</span>

<br>

### 更改颜色
虽说不想给博客涂上五彩斑斓的颜色，但也不得不给黑和白改浓度（被打
使用方法：`text-decoration-color:<颜色>;`
- <span class="uwu" style="text-decoration-color:#4F0;">这是ee最喜欢的下划线（#44FF00（雾</span>

## 高级用法
### 下划线背景板
如果**暂且没有**使用下划线的**需求**，还可以结合以上三者，将其代替`background`使用。
```
.underline {
    text-underline-position:under;
    text-underline-offset:-9px;
    text-decoration:underline;
    text-decoration-thickness:9px;
    text-decoration-color:#44FF00;
}
```
**效果如此**｜<span class="uwu_">这是想当荧光笔的下划线（雾</span>

### 加点动画？
```
.underline {
    text-underline-position:under;
    text-decoration:underline;
    text-decoration-thickness:2px;
    text-decoration-color:#44FF00;
    transition:0.14s ease-in-out all; /* 可以先学下过渡属性的使用 */
}
.underline:hover {
    text-underline-offset:-9px;
    text-decoration-thickness:9px;
}
```
**效果如此**｜<span class="uwu__ pointer">将鼠标移动到此处</span>

## 更多的线条
那么这期教程——到此结束……等等别走！
我在研究下划线的同时，还发现了上划线、划线与下划线的**区别**。

### 关于上划线
上划线`overline`的待遇可比下划线差多了。
下划线所有`text-underline`开头的属性，上划线都没有，~~划线：我不也没有~~。
~~谁让上划线压根不通用，而且下划线就能做出上划线效果~~。
与划线**相同**，上划线也可以调宽度，不管宽度如何，上划线底部永远在文字上方。
**效果如此**｜<span class="uwu uxu">这是普通的上划线</span>

<f1>与下划线组合一下？</f1>
```
.up-and-down {
    font-weight:bold; /* 这个无所谓 只是让旁边的竖杠和线的宽度一样 */
    text-decoration:underline overline;
    text-decoration-thickness:2px;
}
```
**效果如此**｜<b><span class="uwu uxu_" style="text-decoration-thickness:2px!important;">|等等 是不是有点太奇怪了？|</span></b>（左右两边是竖杠`|`

### 关于划线
划线与下划线最大的区别，在于**图层**。
下划线置于文字下层，而划线`line-through`置于文字上层。

**下划线**｜<span class="uvu">下划线在文字后面</span>
**划线**｜<span class="uvu_">划线在文字前面</span>（内容：划线在文字前面（雾

另外，划线没有`text-underline-offset`属性，不管宽度如何，永远都会居中。

<f1>让我们来利用划线的特性！</f1>
如果**暂且没有**使用划线的**需求**，你还可以这么霍霍这层**遮障**：
```
.line-through {
    text-decoration:line-through;
    text-decoration-thickness:18px;
    text-decoration-color:#333;
    user-select:none; /* 毕竟点两下就选中很不爽是吧（逃 */
}
.line-through:active {
    text-decoration:none;
}
```
**效果如此**｜<span class="uvu__ unselect pointer">永远不会放弃你~</span>（长按文本查看真相