# RPGMarker 游戏推荐
**为了寻回初一的那份热爱**

## △○□× 合集
- [1BitHeart](http://www.mwo48.com/mw/1bitheart/index.html)
- [1BeatHeart](http://www.mwo48.com/mw/1beatheart/index.html)
- [Alice Mare](https://www.freem.ne.jp/win/game/5859)
- [LiEat -嘘喰いドラゴンと朱色の吸血鬼-](https://www.freem.ne.jp/win/game/7242)
- [LiEat2 -嘘喰いドラゴンと紺碧色の夢喰い-](https://www.freem.ne.jp/win/game/7243)
- [LiEat3 －嘘喰いドラゴンと黄金色の怪盗－](https://www.freem.ne.jp/win/game/7244)

## 海底囚人 合集
- [Mogeko Castle](http://funamusea.com/story/mogeko_castle/)
- [大海原と大海原](http://funamusea.com/story/wadanohara/)
- [灰色庭園](http://funamusea.com/story/gray_garden/)

## 经典恐解四作
- [Ib](http://kouri.kuchinawa.com/game_01.html)｜恐怖美术馆
- [魔女の家](https://majonoie.karou.jp/)｜魔女之家
- [Mad Father](http://novice2.web.fc2.com/game/mad/index.html)｜狂父
- [ゆめにっき](http://www3.nns.ne.jp/~tk-mto/kikiyamaHP.html)｜梦日记