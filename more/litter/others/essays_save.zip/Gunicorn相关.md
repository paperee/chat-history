---
tags: [centos]
title: Gunicorn 相关
created: '2023-08-12T14:06:48.264Z'
modified: '2023-08-12T15:05:10.336Z'
---

# Gunicorn 相关
## 参数说明
### 绑定地址和端口
- `-b`或`--bind`：指定绑定的地址和端口，例如：`-b 0.0.0.0:8000`。
- `--unix /path/to/socket.sock`：使用 Unix 套接字文件来进行绑定。

### 设置进程和线程
- `--worker-class`：指定工作进程的类型，例如：
  - `sync`：默认同步工作进程，每个工作进程处理一个请求。
  - `eventlet`：使用 Eventlet 库实现的协程工作进程。
  - `gevent`：使用 Gevent 库实现的协程工作进程。
  - `meinheld`：使用 Meinheld 库实现的异步工作进程。
- `-w`或`--workers`：指定工作进程的数量，例如：`-w 4`，默认为 1。
- `--threads`：每个工作进程处理请求的线程数，例如：`--threads 2`。

### 自动重载
- `--reload`：在代码修改后自动重载应用程序。

### 超时设置
- `-t`或`--timeout`：指定超时时间，单位为秒，默认为30。
- `--graceful-timeout`：优雅关闭的超时时间，默认为30。

### 日志设置
- `--log-level`：指定日志级别，例如：`debug`、`info`、`warning`、`error`、`critical`。
- `--access-logfile`：访问日志文件的路径，例如：`access.log`。
- `--error-logfile`：错误日志文件的路径，例如：`error.log`。

### 进程守护
- `-D`或`--daemon`：以守护进程模式运行，默认为 False。

## 开始使用
### 创建 config.py 文件
```
# config.py

bind="0.0.0.0:1234"
reload=True
daemon=True
workers=4
worker_connections=1000
backlog=2048
pidfile="gunicorn.pid"
accesslog="access.log"
errorlog="gunicorn.log"
```

### 运行方法
```
gunicorn --config=config.py <文件名>:<实例>
```

**参数说明**
- 文件名：不带拓展名。
- 实例：如果`app=Flask()`就填`app`。
