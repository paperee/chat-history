﻿      document.addEventListener('visibilitychange', function () {
        if (document.visibilityState == 'hidden') {
          normal_title = document.title;
          document.title = "嗝-快戳我 (ಡωಡ)";
        } else document.title = normal_title;
      });
      function a() {
        document.getElementById("b").style.display = "block";
      }
      function b() {
        document.getElementById("c").style.display = "block";
        document.getElementById("h").style.display = "block";
        document.getElementById("k").style.display = "block";
        document.getElementById("l").style.display = "block";
        document.getElementById("bb").style.display = "block";
        document.getElementById("cc").style.display = "block";
        document.getElementById("m").style.display = "none";
        document.getElementById("o").style.display = "none";
        document.getElementById("n").style.display = "none";
        document.getElementById("p").style.display = "none";
        document.getElementById("q").style.display = "none";
        document.getElementById("r").style.display = "none";
        document.getElementById("aaa").style.display = "block";
        document.getElementById("ddd").style.display = "block";
      }
      function c() {
        document.getElementById("d").style.display = "block";
      }
      function d() {
        document.getElementById("e").style.display = "block";
      }
      function e() {
        document.getElementById("f").style.display = "block";
      }
      function g() {
        document.getElementById("i").style.display = "block";
      }
      function h() {
        document.getElementById("j").style.display = "block";
      }
      function i() {
        document.getElementById("b").style.display = "none";
        document.getElementById("d").style.display = "none";
        document.getElementById("e").style.display = "none";
        document.getElementById("f").style.display = "none";
        document.getElementById("i").style.display = "none";
        document.getElementById("j").style.display = "none";
        document.getElementById("c").style.display = "none";
        document.getElementById("h").style.display = "none";
        document.getElementById("k").style.display = "none";
        document.getElementById("l").style.display = "none";
        document.getElementById("n").style.display = "none";
        document.getElementById("p").style.display = "none";
        document.getElementById("r").style.display = "none";
        document.getElementById("s").style.display = "none";
        document.getElementById("aa").style.display = "none";
        document.getElementById("m").style.display = "block";
        document.getElementById("o").style.display = "block";
        document.getElementById("dd").style.display = "none";
        document.getElementById("ee").style.display = "none";
        document.getElementById("ff").style.display = "none";
        document.getElementById("gg").style.display = "none";
        document.getElementById("hh").style.display = "none";
        document.getElementById("ii").style.display = "none";
        document.getElementById("bb").style.display = "none";
        document.getElementById("cc").style.display = "none";
        document.getElementById("aaa").style.display = "none";
        document.getElementById("ddd").style.display = "none";
        document.getElementById("bbb").style.display = "none";
        document.getElementById("ccc").style.display = "none";
        document.getElementById("ab").style.display = "none";
        document.getElementById("ac").style.display = "none";
        document.getElementById("ad").style.display = "none";
        document.getElementById("ae").style.display = "none";
        document.getElementById("eee").style.display = "none";
      }
      function j() {
        document.getElementById("b").style.display = "none";
        document.getElementById("d").style.display = "none";
        document.getElementById("e").style.display = "none";
        document.getElementById("f").style.display = "none";
        document.getElementById("i").style.display = "none";
        document.getElementById("j").style.display = "none";
        document.getElementById("c").style.display = "none";
        document.getElementById("h").style.display = "none";
        document.getElementById("k").style.display = "none";
        document.getElementById("l").style.display = "none";
        document.getElementById("m").style.display = "none";
        document.getElementById("o").style.display = "none";
        document.getElementById("q").style.display = "none";
        document.getElementById("s").style.display = "none";
        document.getElementById("aa").style.display = "none";
        document.getElementById("n").style.display = "block";
        document.getElementById("p").style.display = "block";
        document.getElementById("dd").style.display = "none";
        document.getElementById("ee").style.display = "none";
        document.getElementById("ff").style.display = "none";
        document.getElementById("gg").style.display = "none";
        document.getElementById("hh").style.display = "none";
        document.getElementById("ii").style.display = "none";
        document.getElementById("bb").style.display = "none";
        document.getElementById("cc").style.display = "none";
        document.getElementById("aaa").style.display = "none";
        document.getElementById("ddd").style.display = "none";
        document.getElementById("bbb").style.display = "none";
        document.getElementById("ccc").style.display = "none";
      }
      function k() {
        document.getElementById("q").style.display = "block";
      }
      function l() {
        document.getElementById("r").style.display = "block";
      }
      function m() {
        document.getElementById("s").style.display = "block";
      }
      function aa() {
        document.getElementById("aa").style.display = "block";
      }
      function bb() {
        document.getElementById("dd").style.display = "block";
      }
      function cc() {
        document.getElementById("ee").style.display = "block";
      }
      function dd() {
        document.getElementById("ff").style.display = "block";
      }
      function ee() {
        document.getElementById("gg").style.display = "block";
      }
      function ff() {
        document.getElementById("hh").style.display = "block";
      }
      function gg() {
        document.getElementById("ii").style.display = "block";
      }
      function aaa() {
        document.getElementById("bbb").style.display = "block";
      }
      function bbb() {
        document.getElementById("ccc").style.display = "block";
      }
      function ccc() {
        document.getElementById("ddd").style.display = "block";
        document.getElementById("eee").style.display = "none";
      }
      function ddd() {
        document.getElementById("eee").style.display = "block";
        document.getElementById("ddd").style.display = "none";
      }