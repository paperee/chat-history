# -*- coding: UTF-8 -*-

awa=("没洞的破洞裤",44)
uwu=input(f"hiyo 无需劳动力的服装店开张了\n\n开店新品是{awa[0]}\n1个{awa[1]}块 你要来几个\n\n[输入购买数量]\n数量：")

if uwu.isdigit():
    input(f"\n好的 那请支付{int(uwu)*awa[1]}块\n\n[按任意键支付]")
    
else:
    print("啊不 请输入数字")