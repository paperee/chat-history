# -*- coding: UTF-8 -*-

awa="没洞的破洞裤 44\n十三分裤 514\n纸张做的纸袜 57\n达濠侨中全套校服 0\n你的绿帽子 365\n青蛙玩偶服 58\n不沾水棉裤 37\n奥特曼的紧身裤 446\n容量3000G的瑜伽裤 59\n鸽鸽的背带裤 1036\n淡黄长裙 122\n超短的长裤 41\n仙人掌手套 57\n卤蛋图案连帽卫衣 18\n插满风车的草帽 114\n白色背心 28\n天宇同款校服 99\n卤蛋味袜子 18\n反重力迷你裙 2\nQ版蜘蛛侠套装 23\n巴啦啦小魔仙全套服装 250\n纯白色吊带裙 28\nMC南瓜头套 64\n杀马特假发 1919\n小蓝花连衣裙 810\n麻鸡头套 404\nSCP机械服装 5000\n初音公式服 16\n黑客面罩 75"

ouo=[(uvu.split()[0],int(uvu.split()[1])) for uvu in awa.split("\n")]
ouo_="\n".join([f"{ouo.index(uvu)}. {uvu[0]} {uvu[1]}块" for uvu in ouo])

try:
    uwu=input(f"hiyo 无需劳动力的服装店开张了\n\n【商品列表】\n{ouo_}\n\n[输入编号挑选商品]\n编号：")
    uwu_=input(f"\nOK 你想买{ouo[int(uwu)][0]}\n\n[输入购买数量]\n数量：")
    input(f"\n好的 那请支付{int(uwu_)*ouo[int(uwu)][1]}块\n\n[按任意键支付]")

except:
    print("啊不 请输入有效的信息")