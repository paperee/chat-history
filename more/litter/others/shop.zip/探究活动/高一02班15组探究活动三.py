# -*- coding: UTF-8 -*-

awa="没洞的破洞裤 44\n十三分裤 514\n纸张做的纸袜 57\n达濠侨中全套校服 0\n你的绿帽子 365\n青蛙玩偶服 58\n不沾水棉裤 37\n奥特曼的紧身裤 446\n容量3000G的瑜伽裤 59\n鸽鸽的背带裤 1036\n淡黄长裙 122\n超短的长裤 41\n仙人掌手套 57\n卤蛋图案连帽卫衣 18\n插满风车的草帽 114\n白色背心 28\n天宇同款校服 99\n卤蛋味袜子 18\n反重力迷你裙 2\nQ版蜘蛛侠套装 23\n巴啦啦小魔仙全套服装 250\n纯白色吊带裙 28\nMC南瓜头套 64\n杀马特假发 1919\n小蓝花连衣裙 810\n麻鸡头套 404\nSCP机械服装 5000\n初音公式服 16\n黑客面罩 75"

ouo=[(uvu.split()[0],int(uvu.split()[1])) for uvu in awa.split("\n")]
ouo_="\n".join([f"{ouo.index(uvu)}. {uvu[0]} {uvu[1]}块" for uvu in ouo])

cart={}

print(f"hiyo 无需劳动力的服装店开张了")

def in_cart():
    return "\n".join([f"{list(cart.keys()).index(uvu)}. {ouo[uvu][0]}x{cart[uvu]}" for uvu in cart]) or "空空如也……"

while True:
    try:
        aua=input(f"\n【可用操作】\n0. 挑选商品\n1. 移除商品\n2. 结账离开\n\n[输入编号操作]\n编号：")

        if aua=="0":
            uwu=int(input(f"\n【商品列表】\n{ouo_}\n\n[输入编号挑选商品]\n编号："))
            uwu_=int(input(f"\nOK 你想买{ouo[uwu][0]}\n\n[输入购买数量]\n数量："))
            cart[uwu]=uwu_+cart[uwu] if cart.get(uwu) else uwu_
            print(f"\n成功将{ouo[uwu][0]}加入购物车\n\n【你的购物车】\n{in_cart()}")

        elif aua=="1":
            uwu=int(input(f"\n【你的购物车】\n{in_cart()}\n\n[输入编号移除商品]\n编号："))
            good=list(cart.keys())[uwu]
            print(f"\n成功移除了{ouo[good][0]}x{cart.pop(good)}\n\n【你的购物车】\n{in_cart()}")

        elif aua=="2":
            break

    except:
        print("\n啊不 请输入有效的信息")

input(f"\n【你的购物车】\n{in_cart()}\n\n好的 那请支付{sum([ouo[uvu][1]*cart[uvu] for uvu in cart])}块\n\n[按任意键支付]" if cart else "\n你什么都没买……\n好吧 欢迎下次光临\n\n[按任意键退出]")
