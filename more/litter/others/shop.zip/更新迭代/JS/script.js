var words=
`没洞的破洞裤 44
十三分裤 514
纸张做的纸袜 57
达濠侨中全套校服 0
你的绿帽子 365
青蛙玩偶服 58
不沾水棉裤 37
奥特曼的紧身裤 446
容量3000G的瑜伽裤 59
鸽鸽的背带裤 1036
淡黄长裙 122
超短的长裤 41
仙人掌手套 57
卤蛋图案连帽卫衣 18
插满风车的草帽 114
白色背心 28
天宇同款校服 99
卤蛋味袜子 18
反重力迷你裙 2
Q版蜘蛛侠套装 23
巴啦啦小魔仙套装 250
纯白色吊带裙 28
MC南瓜头套 64
杀马特假发 1919
小蓝花连衣裙 810
麻鸡头套 404
SCP机械服装 5000
初音公式服 16
黑客面罩 75`

$(document).on("input","input[type='number']",function() {
	$(this).val($(this).val().replace(/[^\d]/g,"").replace(/^(\d+\.?\d{0,0}).*$/,"$1").substring(0,3));
}).ready(()=>{
	function shuffle(arr) {
	    let len=arr.length;
	    while (len>0) {
	        const index=Math.floor(Math.random()*len);
	        const temp=arr[len-1];
	        arr[len-1]=arr[index];
	        arr[index]=temp;
	        len--;
	    }
	    return arr;
	}
	
	// 草 我个Python写魔怔了是吧
	function print(text) {
		console.log(text);
	}
	var cart={
		uwu:{},
	    get:function(key,value) {
		    if (this.uwu.hasOwnProperty(key)) {
		      return this.uwu[key];
		    } else {
		      return value;
		    }
	    }
	}
	var list=[];
	var shelf=$.map(shuffle(words.split("\n")),(value,index)=>{
		const temp=value.split(" ");
		list.push([temp[0],temp[1]]);

	    // 创建文件信息的div元素
		var goods=$("<tr>").addClass("goods").hide();
		$("<td>").text(temp[0]).appendTo(goods);
		$("<td>").text(temp[1]+"R").appendTo(goods);
		$("<td>").append($("<a>").text("[+]").attr("id",index).on("click",()=>add(index,parseInt($(`#add${index}`).val())||1))).append($("<input>").attr("id",`add${index}`).attr("type","number").attr("placeholder","数量")).appendTo(goods);

	    // 将文件信息的div元素添加到页面=>逐个展开
	    $("#shelf tbody").delay(index*50).queue(function() {
	        $(this).append(goods).dequeue();
	        goods.fadeIn("fast");
	    })
	})
	function reload() {
		let price=0;
		$("#name").empty();
		$.each(cart.uwu,(key,value)=>{
			$("#name").append($("<span>").text(`${list[key][0]}x${value} `).attr("id",`good${key}`).append($("<a>").text("[-]").on("click",()=>remove(key))).append($("<br>")));
			price+=list[key][1]*value;
		})
		price=`${price}R`;
		$("#price").text(price);
	}
	function add(index,num) {
		cart.uwu[index]=cart.get(index,false)?cart.uwu[index]+num:num;
		reload();
	}
	function remove(key) {
		delete cart.uwu[key];
		reload();
	}
	$("#OK").on("click",()=>{
		if ($.isEmptyObject(cart.uwu)) {
			$("#name").text("什么都没有买到……");
		} else {
			cart.uwu={};
			reload();
			$("#name").text("支付成功 欢迎下次光临");
		}
	})
})